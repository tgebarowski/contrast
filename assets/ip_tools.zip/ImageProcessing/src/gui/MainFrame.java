package gui;

import gui.dialogs.HistogramFrame;
import gui.dialogs.SliderFrame;
import gui.dialogs.SpectrumFrame;
import gui.listeners.GaussianFilterActionListener;
import gui.listeners.MeanFilterActionListener;
import gui.listeners.MedianFilterActionListener;
import gui.listeners.RandomNoiseActionListener;
import gui.listeners.RotateActionListener;
import gui.listeners.SaltPepperActionListener;
import gui.listeners.SaturationActionListener;
import gui.widgets.ImagePanel;
import ip.ColorBalance;
import ip.FrequencyAnalyzer;
import ip.HistogramEqualization;
import ip.Rotation;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;

import misc.ImageChooserFilter;
import misc.ImageData;

import org.apache.log4j.Logger;

/**
 * Application Main Window
 * @author Tomasz Gebarowski
 *
 */
public class MainFrame extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(MainFrame.class);
	private static final JFileChooser fileChooser = new JFileChooser();
	
	private JMenuBar menuBar;
	private JMenu menuFile;
	private JMenu menuImage;
	private JMenu menuTransform;
	private JMenu menuRotate;
	private JMenu menuFilters;
	private JMenu menuOptions;
	private JMenuItem mRotate;
	private JMenuItem mRotateLeft;
	private JMenuItem mRotateRight;
	private JMenuItem mRotateRightFlip;
	private JMenuItem mRotateLeftFlip;
	private JRadioButtonMenuItem mBilinearInterpolation;
	private JRadioButtonMenuItem mNearestNInterpolation;
	private JMenuItem mOpen;
	private JMenuItem mSave;
	private JMenuItem mExit;
	private JMenuItem mReset;
	private JMenuItem mDisplayHistogram;
	private JMenuItem mEqualizeHistogram;
	private JMenuItem mEqualizeColorBalance;
	private JMenuItem mSaturation;
	private JMenuItem mMeanFilter;
	private JMenuItem mGaussianFilter;
	private JMenuItem mAddRandomNoise;
	private JMenuItem mAddSaltPepperNoise;
	private JMenuItem mMedianFilter;
	private JMenuItem mFFT;
	
	private JPanel toolPanel;
	private JPanel picturesPanel;	
	private JButton btnOpen, btnSave, btnRotate, btnReset, btnHistogram;
	
	
	private ImagePanel origImagePanel;
	private ImagePanel transImagePanel;
	
	public MainFrame(String title) {
		super(title);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		createGUI();
	}
	
	
	/****************************************************
	 * GUI Creation Private Functions
	 ****************************************************/
	
	private void createGUI() {
		
		toolPanel = new JPanel(new GridLayout());
		picturesPanel = new JPanel(new GridLayout());
		
		fileChooser.setFileFilter(new ImageChooserFilter());
		
		createToolPanelContent();
		createPicturesPanelContent();
		createMenuBar();
	
		Container mainPane = this.getContentPane();
		mainPane.setLayout(new BorderLayout());

		mainPane.add(toolPanel, BorderLayout.NORTH);
		mainPane.add(picturesPanel, BorderLayout.CENTER);
		updateControls();
		
		this.pack();
		this.setVisible(true);
		
	}
	
	private void createMenuBar() {
		menuBar = new JMenuBar();
		
		mOpen = createJMenuItem("Open", misc.Utils.createImageIcon("/res/open.png"));
		mSave = createJMenuItem("Save", misc.Utils.createImageIcon("/res/save.png"));
		mRotate = createJMenuItem("Rotate ...", misc.Utils.createImageIcon("/res/rotate.png"));
		mRotateLeft = createJMenuItem("Rotate Left", misc.Utils.createImageIcon("/res/rot_left.png"));
		mRotateRight = createJMenuItem("Rotate Right", misc.Utils.createImageIcon("/res/rot_right.png"));
		mRotateLeftFlip = createJMenuItem("Rotate Left and Flip",misc.Utils.createImageIcon("/res/left_flip.png"));
		mRotateRightFlip = createJMenuItem("Rotate Right and Flip", misc.Utils.createImageIcon("/res/right_flip.png"));		
		mReset =createJMenuItem("Reset", misc.Utils.createImageIcon("/res/reset.png"));
		mDisplayHistogram = createJMenuItem("Display Histogram",null);
		mEqualizeHistogram = createJMenuItem("Equalize Histogram", null);
		mSaturation = createJMenuItem("Enhance Saturation",null);
		mEqualizeColorBalance = createJMenuItem("Equalize Color Balance", null);
		mExit = createJMenuItem("Exit",misc.Utils.createImageIcon("/res/exit.png"));
		mMeanFilter = createJMenuItem("Mean Filter", null);
		mGaussianFilter = createJMenuItem("Gaussian Filter", null);
		mAddRandomNoise = createJMenuItem("Random Noise", null);
		mAddSaltPepperNoise = createJMenuItem("Salt & Pepper Noise", null);
		mMedianFilter = createJMenuItem("Median Filter",null);
		mFFT = createJMenuItem("Fast Fourier Transform", null);
		
		
		ButtonGroup buttonGroup = new ButtonGroup();
		mBilinearInterpolation = createJRadioButtonMenuItem("Bilinear Interpolation", false, this, buttonGroup);
		mNearestNInterpolation = createJRadioButtonMenuItem("NearestN Interpolation", true, this, buttonGroup);
		
		menuFile = new JMenu("File");
		menuFile.add(mOpen);
		menuFile.add(mSave);
		menuFile.addSeparator();
		menuFile.add(mExit);
		
		menuTransform= new JMenu("Transform");
		menuTransform.add(mFFT);
		menuTransform.add(mReset);
		
		menuImage = new JMenu("Image");
		menuImage.add(mDisplayHistogram);
		menuImage.add(mEqualizeHistogram);
		menuImage.add(mSaturation);
		menuImage.add(mEqualizeColorBalance);
		
		menuRotate = new JMenu("Rotate");
		menuRotate.add(mRotate);
		menuRotate.add(mRotateLeft);
		menuRotate.add(mRotateRight);
		menuRotate.add(mRotateLeftFlip);
		menuRotate.add(mRotateRightFlip);
		
		menuFilters = new JMenu("Filters");
		menuFilters.add(mMeanFilter);
		menuFilters.add(mGaussianFilter);
		menuFilters.add(mAddRandomNoise);
		menuFilters.add(mAddSaltPepperNoise);
		menuFilters.add(mMedianFilter);

		
		menuOptions = new JMenu("Options");
		menuOptions.add(mBilinearInterpolation);
		menuOptions.add(mNearestNInterpolation);
		
		menuBar.add(menuFile);
		menuBar.add(menuImage);
		menuBar.add(menuTransform);
		menuBar.add(menuRotate);
		menuBar.add(menuFilters);
		menuBar.add(menuOptions);
		
		this.setJMenuBar(menuBar);
	}

	
	private void createToolPanelContent() {
		btnOpen = new JButton("Open", misc.Utils.createImageIcon("/res/open.png"));
		btnSave = new JButton("Save", misc.Utils.createImageIcon("/res/save.png"));
		btnRotate = new JButton("Rotate...", misc.Utils.createImageIcon("/res/rotate.png"));
		btnReset = new JButton("Reset", misc.Utils.createImageIcon("/res/reset.png"));
		btnHistogram = new JButton("Histogram", misc.Utils.createImageIcon("/res/histogram_info.png"));		
	
		btnOpen.addActionListener(this);
		btnSave.addActionListener(this);
		btnReset.addActionListener(this);
		btnRotate.addActionListener(this);
		btnHistogram.addActionListener(this);

		toolPanel.add(btnOpen);
		toolPanel.add(btnSave);
		toolPanel.add(btnReset);
		toolPanel.add(btnHistogram);
		toolPanel.add(btnRotate);
		
		Dimension dim = new Dimension(0,50);
		toolPanel.setMaximumSize(dim);
		toolPanel.setPreferredSize(dim);
	}
	
	private void createPicturesPanelContent() {

		origImagePanel = new ImagePanel();
		transImagePanel = new ImagePanel();

		picturesPanel.add(origImagePanel);
		picturesPanel.add(transImagePanel);
		
		origImagePanel.setName("Original Image");
		transImagePanel.setName("Transformed Image");
				
	}
	
	
	/*******************************************************
	 * MenuItems and Buttons Actions
	 *******************************************************/
	
	private void rotateBy90Action(Rotation.RotationType rotation) {
		
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}
		
		ImageData pxArr = origImagePanel.getImageData();
		transImagePanel.load(Rotation.rotateBy90(pxArr, rotation));
	}
	
	public void loadTransformed(ImageData imageData) {
		transImagePanel.load(imageData);
	}
	
	
	private void rotateAction() {
		SliderFrame sliderFrame = new SliderFrame("Rotate Image by Angle");
		boolean isBilinear = mBilinearInterpolation.isSelected();
		sliderFrame.addActionListener(new RotateActionListener(origImagePanel, transImagePanel, sliderFrame, isBilinear));
		sliderFrame.setSliderBoundries(0, 360);
		sliderFrame.setVisible(true);	
		transImagePanel.setModified(true);
	}
	
	
	private void resetAction()
	{
		origImagePanel.load(origImagePanel.getBufferedImage());
		transImagePanel.clear();
	}
	
	private void saveDialogAction() {
		int returnVal = fileChooser.showSaveDialog(this);
		
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File imgFile = fileChooser.getSelectedFile();
			String imgPath = imgFile.getPath();
			logger.info("File dialog approved: " + imgPath );
			transImagePanel.save(imgPath);
		}
	}

	private void openDialogAction() {
		int returnVal = fileChooser.showOpenDialog(this);
		
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File imgFile = fileChooser.getSelectedFile();
			String imgPath = imgFile.getPath();
			logger.info("File dialog approved: " + imgPath );
			origImagePanel.load(imgPath);
		}
	}
	

	private void displayHistogramAction() {
		HistogramFrame histogramFrame = new HistogramFrame(origImagePanel.getImageData());
		histogramFrame.setVisible(true);
	}

	private void enhanceSaturationAction() {
		
		SliderFrame sliderFrame = new SliderFrame("Enhance Saturation");
		sliderFrame.addActionListener(new SaturationActionListener(origImagePanel, transImagePanel, sliderFrame));
		sliderFrame.setSliderBoundries(0, 100);
		sliderFrame.setVisible(true);	
		transImagePanel.setModified(true);
		
	}
	
	private void equalizeHistogramAction() {

		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}

		ImageData pxArr = origImagePanel.getImageData();
		
		HistogramEqualization equalizer = new HistogramEqualization(pxArr);
		transImagePanel.load(equalizer.equalize());	
	}
	

	private void equalizeWhiteBalanceAction() {
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}

		ImageData pxArr = origImagePanel.getImageData();
		pxArr  = ColorBalance.enhance(pxArr);
		
		transImagePanel.load(pxArr);
		
	}

	private void meanFilterAction() {

		SliderFrame sliderFrame = new SliderFrame("Define Matrix Dimensions");
		sliderFrame.setOdd(true);
		sliderFrame.addActionListener(new MeanFilterActionListener(origImagePanel, transImagePanel, sliderFrame));
		sliderFrame.setSliderBoundries(0, 10);
		sliderFrame.setVisible(true);	
		transImagePanel.setModified(true);
		
	}

	private void gaussianFilterAction() {
		SliderFrame sliderFrame = new SliderFrame("Define Gaussian Radius");
		sliderFrame.addActionListener(new GaussianFilterActionListener(origImagePanel, transImagePanel, sliderFrame));
		sliderFrame.setSliderBoundries(1, 100);
		sliderFrame.setVisible(true);	
		transImagePanel.setModified(true);	
	}

	private void addRandomNoiseAction() {
		SliderFrame sliderFrame = new SliderFrame("Define noise intensity");
		sliderFrame.addActionListener(new RandomNoiseActionListener(origImagePanel, transImagePanel, sliderFrame));
		sliderFrame.setSliderBoundries(1, 100);
		sliderFrame.setVisible(true);	
		transImagePanel.setModified(true);	
	}
	
	private void addSaltPepperNoiseAction() {
		SliderFrame sliderFrame = new SliderFrame("Define noise intensity");
		sliderFrame.addActionListener(new SaltPepperActionListener(origImagePanel, transImagePanel, sliderFrame));
		sliderFrame.setSliderBoundries(1, 100);
		sliderFrame.setVisible(true);	
		transImagePanel.setModified(true);		
	}
	
	private void medianFilterAction() {
		SliderFrame sliderFrame = new SliderFrame("Define mask size");
		sliderFrame.addActionListener(new MedianFilterActionListener(origImagePanel, transImagePanel, sliderFrame));
		sliderFrame.setOdd(true);
		sliderFrame.setSliderBoundries(0, 5);
		sliderFrame.setVisible(true);	
		transImagePanel.setModified(true);	
	}
	
	private void fftTransformAction() {

		ImageData imageData = origImagePanel.getImageData();
		FrequencyAnalyzer fA = new FrequencyAnalyzer(imageData);
		
		new SpectrumFrame(fA, this).setVisible(true);
	}

	
	
	private void exitAction() {
		System.exit(0);	
	}
	
	/**************************************************
	 * Action Controller
	 **************************************************/
	
	public void actionPerformed(ActionEvent e) {
		
		Object source = e.getSource();
		
		if (source == btnOpen || source == mOpen) {
			openDialogAction();
			
			
		} else if ( source == btnSave || source == mSave ) {
			saveDialogAction();
			
		} else if ( source == mRotateRightFlip  ) {
			rotateBy90Action(Rotation.RotationType.Right_Flip);		
		} else if ( source == mRotateLeftFlip ) {
			rotateBy90Action(Rotation.RotationType.Left_Flip);	
		} else if (source == mRotateRight ) {
			rotateBy90Action(Rotation.RotationType.Right);		
		} else if ( source == mRotateLeft  ) {
			rotateBy90Action(Rotation.RotationType.Left);	
		} else if ( source == btnReset || source == mReset ) {
			resetAction();
		} else if ( source == btnHistogram || source == mDisplayHistogram) {
			displayHistogramAction();
		} else if ( source == mRotate || source == btnRotate) {
			rotateAction();
		} else if ( source == mSaturation) {
			enhanceSaturationAction();
		} else if ( source == mEqualizeHistogram) {
			equalizeHistogramAction();
		} else if ( source == mExit ) {
			exitAction();
		} else if ( source == mEqualizeColorBalance ) {
			equalizeWhiteBalanceAction();
		} else if ( source == mMeanFilter ) {
			meanFilterAction();
		}  else if ( source == mGaussianFilter ) {
			gaussianFilterAction();
		}  else if ( source == mAddRandomNoise ) {
			addRandomNoiseAction();
		} else if ( source == mAddSaltPepperNoise) {
			addSaltPepperNoiseAction();
		} else if ( source == mMedianFilter) {
			medianFilterAction();
		} else if ( source == mFFT ) {
			fftTransformAction();
		}
	
		updateControls();
	}













	/******************************************
	 * Other Functions and Methods
	 ******************************************/
	
	private void updateControls() {
		
		boolean transModified = transImagePanel.isModified();
		mSave.setEnabled(transModified);
		mReset.setEnabled(transModified);
		btnSave.setEnabled(transModified);
		btnReset.setEnabled(transModified);
		
		
		boolean origLoaded = origImagePanel.getBufferedImage() != null;
		
		btnRotate.setEnabled(origLoaded);
		menuImage.setEnabled(origLoaded);
		menuRotate.setEnabled(origLoaded);
		menuTransform.setEnabled(origLoaded);
		menuFilters.setEnabled(origLoaded);
		btnHistogram.setEnabled(origLoaded);
		
		logger.info("Controls updated");
		
	}
	
	/******************************************
	 * Helpers
	 ******************************************/
    private JRadioButtonMenuItem createJRadioButtonMenuItem(
    			String text, boolean selected, 
                ActionListener actionListener, 
                ButtonGroup buttonGroup)
	{
	    JRadioButtonMenuItem radioButtonMenuItem =  new JRadioButtonMenuItem(text, selected);
	    radioButtonMenuItem.addActionListener(actionListener);
	    buttonGroup.add(radioButtonMenuItem);
	    return radioButtonMenuItem;
	}
    
    
    private JMenuItem createJMenuItem(String text, ImageIcon icon) {
    	JMenuItem menuItem = new JMenuItem(text,icon);
    	menuItem.addActionListener(this);
    	return menuItem;
    	
    }



	

}
