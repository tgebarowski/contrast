package gui.listeners;

import gui.dialogs.SliderFrame;
import gui.widgets.ImagePanel;
import ip.Filters;
import ip.kernels.GaussianKernel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import misc.ImageData;

public class GaussianFilterActionListener extends SliderActionListener {


	public GaussianFilterActionListener(ImagePanel origImagePanel,ImagePanel transImagePanel, SliderFrame sliderFrame) {
		super(origImagePanel, transImagePanel, sliderFrame);
	}

	public void actionPerformed(ActionEvent e) {
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}

		ImageData pxArr = origImagePanel.getImageData();
		pxArr = Filters.gaussianFilter(pxArr, new GaussianKernel(sliderFrame.getSliderValue() / 10.0f));

		transImagePanel.load(pxArr);
		
	}
}
