package gui.listeners;

import gui.dialogs.SliderFrame;
import gui.widgets.ImagePanel;
import ip.Noise;

import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;

import misc.ImageData;

public class RandomNoiseActionListener extends SliderActionListener {

	public RandomNoiseActionListener(ImagePanel origImagePanel,	ImagePanel transImagePanel, SliderFrame sliderFrame) {
		super(origImagePanel, transImagePanel, sliderFrame);
	}

	public void actionPerformed(ActionEvent e) {
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}
		ImageData pxArr = origImagePanel.getImageData();
		pxArr = Noise.randomNoise(pxArr, sliderFrame.getSliderValue());

		transImagePanel.load(pxArr);
		
	}
	
	
	

}
