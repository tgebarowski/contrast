package gui.listeners;

import gui.dialogs.SliderFrame;
import gui.widgets.ImagePanel;
import ip.Rotation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import misc.ImageData;

public class RotateActionListener extends SliderActionListener {
	

	private boolean isBilinear;
	

	public RotateActionListener(ImagePanel origImagePanel, ImagePanel transImagePanel, SliderFrame sliderFrame, boolean isBilinear) {
		super(origImagePanel, transImagePanel, sliderFrame);
		this.isBilinear = isBilinear;
	}
	
	public void actionPerformed(ActionEvent e) {
		
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}

		ImageData pxArr = transImagePanel.getImageData();
		int rotAngle = sliderFrame.getSliderValue();
		transImagePanel.load(Rotation.rotate(pxArr, rotAngle * Math.PI / 180.0, isBilinear));	
		sliderFrame.dispose();

	}




}
