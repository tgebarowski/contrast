package gui.listeners;

import gui.dialogs.SliderFrame;
import gui.widgets.ImagePanel;
import ip.Filters;

import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;

import misc.ImageData;

public class MedianFilterActionListener extends SliderActionListener {

	public MedianFilterActionListener(ImagePanel origImagePanel,ImagePanel transImagePanel, SliderFrame sliderFrame) {
		super(origImagePanel, transImagePanel, sliderFrame);

	}

	public void actionPerformed(ActionEvent e) {
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}
		ImageData pxArr = origImagePanel.getImageData();
		pxArr = Filters.medianFilter(pxArr, sliderFrame.getSliderValue());

		transImagePanel.load(pxArr);
		
	}
	

}
