package gui.listeners;

import gui.dialogs.SliderFrame;
import gui.widgets.ImagePanel;

import java.awt.event.ActionListener;

public abstract class SliderActionListener implements ActionListener {
	
	protected ImagePanel origImagePanel;
	protected ImagePanel transImagePanel;
	protected SliderFrame sliderFrame;
	
	
	public SliderActionListener(ImagePanel origImagePanel, ImagePanel transImagePanel, SliderFrame sliderFrame) {
		super();
		this.origImagePanel = origImagePanel;
		this.transImagePanel = transImagePanel;
		this.sliderFrame = sliderFrame;
	}
	
	

}
