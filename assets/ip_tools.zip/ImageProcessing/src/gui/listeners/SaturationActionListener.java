package gui.listeners;

import gui.dialogs.SliderFrame;
import gui.widgets.ImagePanel;
import ip.Saturation;

import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;

import misc.ImageData;

public class SaturationActionListener extends SliderActionListener {


	public SaturationActionListener(ImagePanel origImagePanel, ImagePanel transImagePanel, SliderFrame sliderFrame) {
		super(origImagePanel, transImagePanel, sliderFrame);
	}

	public void actionPerformed(ActionEvent e) {
		
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}
		
		int saturationValue = sliderFrame.getSliderValue();
		ImageData pxArr = origImagePanel.getImageData();
		transImagePanel.load(Saturation.enhance(pxArr, saturationValue / 100.0f));
		

	}

}
