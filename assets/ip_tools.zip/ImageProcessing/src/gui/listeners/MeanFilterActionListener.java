package gui.listeners;

import gui.dialogs.SliderFrame;
import gui.widgets.ImagePanel;
import ip.Filters;
import ip.kernels.MeanKernel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import misc.ImageData;

public class MeanFilterActionListener extends SliderActionListener {



	public MeanFilterActionListener(ImagePanel origImagePanel,	ImagePanel transImagePanel, SliderFrame sliderFrame) {
		super(origImagePanel, transImagePanel, sliderFrame);
	}

	public void actionPerformed(ActionEvent e) {
		BufferedImage hBufferedImage = origImagePanel.getBufferedImage();
		
		if (hBufferedImage != null && origImagePanel.isModified()) {
			transImagePanel.load(hBufferedImage);
			origImagePanel.setModified(false);
		}
		ImageData pxArr = origImagePanel.getImageData();
		pxArr = Filters.convolutionFilter(pxArr, new MeanKernel(sliderFrame.getSliderValue()));

		transImagePanel.load(pxArr);
	}
	
	

}
