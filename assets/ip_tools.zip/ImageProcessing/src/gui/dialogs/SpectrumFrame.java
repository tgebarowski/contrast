package gui.dialogs;

import gui.MainFrame;
import gui.widgets.SpectrumPanel;
import ip.FrequencyAnalyzer;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import misc.ImageData;

public class SpectrumFrame extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private MainFrame mainFrame;
	private SpectrumPanel magnitudePanel;
	private SpectrumPanel phasePanel;
	private SpectrumPanel imagPanel;
	private SpectrumPanel realPanel;
	private SpectrumPanel magnitudeLogPanel;
	private SpectrumPanel imagLogPanel;
	private SpectrumPanel realLogPanel;
	private JButton btnInverseFFT;
	private JButton btnRemoveMoire;
	
	private FrequencyAnalyzer frequencyAnalyzer;
	
	public SpectrumFrame(FrequencyAnalyzer fA, MainFrame mainFrame) {
		this.frequencyAnalyzer = fA;
		this.mainFrame = mainFrame;
		createGUI();
		load();
	}
	
	private void createGUI() {
		
		JTabbedPane tabbedPane = new JTabbedPane();
		JPanel buttonsPanel = new JPanel();
		
		Container mainPane = this.getContentPane();
		
		setMinimumSize(new Dimension(400,400));
		mainPane.setLayout(new BorderLayout());
		
		buttonsPanel.setLayout(new BorderLayout());
		buttonsPanel.setMaximumSize(new Dimension(400,50));
		buttonsPanel.setPreferredSize(new Dimension(400,50));
		
		this.btnInverseFFT = new JButton("Inverse FFT");
		this.btnInverseFFT.addActionListener(this);
		
		this.btnRemoveMoire = new JButton("Remove Moire");
		this.btnRemoveMoire.addActionListener(this);
		
		this.magnitudePanel = new SpectrumPanel();
		this.phasePanel = new SpectrumPanel();
		this.imagPanel = new SpectrumPanel();
		this.realPanel = new SpectrumPanel();
		this.magnitudeLogPanel = new SpectrumPanel();
		this.imagLogPanel = new SpectrumPanel();
		this.realLogPanel = new SpectrumPanel();
		
		tabbedPane.add("Magnitude", magnitudePanel);
		tabbedPane.add("Log(Magnitude)", magnitudeLogPanel);
		tabbedPane.add("Phase", phasePanel);
		tabbedPane.add("Real Part", realPanel);
		tabbedPane.add("Log(Real)", realLogPanel);
		tabbedPane.add("Imag", imagPanel);
		tabbedPane.add("Log(Imag)", imagLogPanel);
		
		mainPane.add(tabbedPane, BorderLayout.PAGE_START);
		
		buttonsPanel.add(btnRemoveMoire, BorderLayout.EAST);
		buttonsPanel.add(btnInverseFFT, BorderLayout.WEST);
		
		mainPane.add(buttonsPanel, BorderLayout.PAGE_END);
		
		pack();
	}
	
	public void load() {
		this.magnitudePanel.load(frequencyAnalyzer.getMagnitudeImage());
		this.phasePanel.load(frequencyAnalyzer.getPhaseImage());
		this.imagPanel.load(frequencyAnalyzer.getImaginaryPartImage());
		this.realPanel.load(frequencyAnalyzer.getRealPartImage());
		this.magnitudeLogPanel.load(frequencyAnalyzer.getMagnitudeLogImage());
		this.imagLogPanel.load(frequencyAnalyzer.getImaginaryPartLogImage());
		this.realLogPanel.load(frequencyAnalyzer.getRealPartLogImage());
	}

	public void actionPerformed(ActionEvent e) {
		
		if ( e.getSource() == btnInverseFFT ) {
			ImageData imageData  = this.frequencyAnalyzer.inverseFFT();
			mainFrame.loadTransformed(imageData);
		} else if ( e.getSource() == btnRemoveMoire ) {
			this.frequencyAnalyzer.removeMoire();
			this.load();
		}
		
	}

}
