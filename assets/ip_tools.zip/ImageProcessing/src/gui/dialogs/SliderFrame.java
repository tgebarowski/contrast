package gui.dialogs;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class SliderFrame extends JFrame implements ChangeListener {

	private static final long serialVersionUID = 1L;
	private int sliderValue;
	private boolean odd;
	private JSlider slider;
	private JLabel  lValue;
	private JButton bApply;
	
	
	public SliderFrame(String title) {
		super(title);
		odd = false;
		createGUI();
	}
	
	public void addActionListener(ActionListener actionListener) {
		this.bApply.addActionListener(actionListener);
	}
	
	public void setSliderBoundries(int min, int max) {
		slider.setMinimum(min);
		slider.setMaximum(max);
	}
	
	public void setOdd(boolean odd) {
		this.odd = odd;
	}
	
	public int getSliderValue() {
		return sliderValue;
	}
	
	public int getMaximumValue() {
		return slider.getMaximum();
	}
	
	private void createGUI() {
		
		Container mainPane = this.getContentPane();
		setMinimumSize(new Dimension(120,50));
		mainPane.setLayout(new BorderLayout());
	
		slider = new JSlider();
		lValue = new JLabel();
		bApply = new JButton("Apply");
		mainPane.add(slider, BorderLayout.WEST);	
		mainPane.add(lValue, BorderLayout.EAST);
		mainPane.add(bApply, BorderLayout.PAGE_END);
		
		lValue.setText(String.valueOf(slider.getValue()));
		slider.addChangeListener(this);
		pack();
		
	}

	public void stateChanged(ChangeEvent e) {
		int value = slider.getValue();
		
		if ( odd )
			value = 2 * slider.getValue() + 1;
		
		this.sliderValue = value;
		this.lValue.setText(String.valueOf(value));
	}
	
	
}
