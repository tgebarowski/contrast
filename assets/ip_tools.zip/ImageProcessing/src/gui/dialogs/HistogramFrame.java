package gui.dialogs;

import gui.widgets.HistogramPanel;
import ip.Histogram;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JFrame;

import misc.ImageData;

public class HistogramFrame extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Histogram histogram;
	private HistogramPanel histogramPanel;
	
	public HistogramFrame(ImageData pixArr) {
		super("Image Histogram");
		createGUI();
		generateHistogram(pixArr);
	}
	
	
	private void createGUI() {
		
		Container mainPane = this.getContentPane();
		setMinimumSize(new Dimension(400,400));
		mainPane.setLayout(new BorderLayout());
		
		histogramPanel = new HistogramPanel();
		mainPane.add(histogramPanel);	
		pack();
		
	}
	
	public void generateHistogram(ImageData pixArr) {
		histogram = new Histogram(pixArr);
		histogramPanel.setHistogram(histogram);
	}

	
	
	
	
	
	
	

}
