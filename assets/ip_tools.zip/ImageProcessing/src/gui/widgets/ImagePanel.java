package gui.widgets;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import misc.ImageData;
import misc.Utils;

import org.apache.log4j.Logger;

/**
 * Image Panel used for representing image object
 * @author tomaszgebarowski
 *
 */
public class ImagePanel extends JPanel {

	/**
	 * 
	 */
	
	
	
	private static Logger logger = Logger.getLogger(ImagePanel.class);
	
	private static final long serialVersionUID = 1L;
	private BufferedImage hImage = null;

	private boolean modified = false;
	private ImageData imageData;
	
	public ImagePanel() {
		super();
		Dimension minDimension = new Dimension(450,400);
		this.setMinimumSize(minDimension);
		this.setPreferredSize(minDimension);
		this.setBorder(new EtchedBorder(1));
		this.modified = false;
	}
	
	
	public ImageData getImageData() {
		return imageData;
	}
	
	public void load(String imgPath) {
		try {
			File input = new File(imgPath);
			hImage = ImageIO.read(input);
			this.imageData = new ImageData(hImage);
			modified = true;		
			this.repaint();
	    } catch (IOException e) {
	    	logger.error("IO Exception");
	    }		
	}
	
	public void load(BufferedImage hImage) {
		this.hImage = hImage;	
		this.imageData = new ImageData(hImage);
		this.repaint();
		this.modified = true;
	}
	
	public void load(ImageData imageData) {
		int xSize = imageData.getXSize();
		int ySize = imageData.getYSize();
		BufferedImage bi = new BufferedImage(xSize,ySize,BufferedImage.TYPE_INT_RGB);
		bi.setRGB(0,0, xSize, ySize, imageData.getPixelArray() ,0,xSize);
		bi.flush();
		
		this.imageData = imageData;
		this.hImage = bi;
		this.modified = true;
		this.repaint();
	}

	
	public void save(String imgPath) {
		
		File output = new File(imgPath);
		try {
			ImageIO.write(hImage, Utils.getExtension(output), output);
		} catch (IOException e) {
			logger.error("IO Exception thrown");
		}
		
	}
	
	public void clear() {
		this.imageData = null;
		this.hImage = new BufferedImage(1,1,BufferedImage.TYPE_INT_RGB);
		this.hImage.flush();
		this.setModified(false);
		this.repaint();
	}

	
	public void paint(Graphics g) {
		super.paint(g);
		if ( hImage != null) {
			logger.info("Drawing Image");
			g.drawString(this.getName(), 20, 17);
			g.drawImage(hImage, 20,30, null);
		}
	}
	
	public BufferedImage getBufferedImage() {
		return this.hImage;
	}


	public boolean isModified() {
		return modified;
	}


	public void setModified(boolean modified) {
		this.modified = modified;
	}
	
}
