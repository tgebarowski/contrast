package gui.widgets;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import misc.SpectrumImage;

public class SpectrumPanel extends JPanel {
	
	private BufferedImage spectrumImage;
	
	public SpectrumPanel() {
		Dimension minDimension = new Dimension(450,400);
		this.setMinimumSize(minDimension);
		this.setPreferredSize(minDimension);
		this.setBorder(new EtchedBorder(1));
		
	}
	
	public void load(BufferedImage image) {
		this.spectrumImage = image;
		this.repaint();
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		if ( spectrumImage != null) {
			g.drawImage(spectrumImage, 0,0, null);
		}
	}
}
