package gui.widgets;

import ip.Histogram;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

import misc.Utils;

public class HistogramPanel extends JPanel {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Histogram histogram;

	public HistogramPanel() {
		super();
		
		Dimension size = new Dimension(300,450);
		this.setPreferredSize(size);
		this.setMinimumSize(size);
	}
	
	public Histogram getHistogram() {
		return histogram;
	}


	public void setHistogram(Histogram histogram) {
		this.histogram = histogram;	
	}



	public void paint(Graphics g) {
		super.paint(g);
		
		int []histRed = histogram.getHistogramR();
		int []histBlue = histogram.getHistogramB();
		int []histGreen = histogram.getHistogramG();
		int []histGray = histogram.getHistogramGray();
		int offsetX = 25;
		int chartOffset = 50;
		int chartHeight = 100;

		int redMax = Utils.maxArray(histRed);
		int greenMax = Utils.maxArray(histGreen);
		int blueMax = Utils.maxArray(histBlue);
		int grayMax = Utils.maxArray(histGray);

		int windowHeight = this.getHeight();
		
		for(int i = 0; i < histRed.length; i++) {
		
			int yVal = windowHeight - chartOffset -  (int)( chartHeight * ( 1.0 * histRed[i] / redMax ));
			g.setColor(Color.red);
			g.drawLine(offsetX + i, windowHeight - chartOffset, offsetX + i, yVal);
			
			yVal = windowHeight - (chartOffset + 2*chartOffset) - (int)(chartHeight *  ( 1.0 * histBlue[i] / blueMax ));
			g.setColor(Color.blue);
			g.drawLine(offsetX + i,windowHeight - chartOffset * 3, offsetX + i, yVal);
			
			yVal = windowHeight - (chartOffset + 4* chartOffset) - (int)(chartHeight * ( 1.0 * histGreen[i] / greenMax ));
			g.setColor(Color.green);
			g.drawLine(offsetX + i,windowHeight - chartOffset * 5, offsetX + i, yVal);
			
			yVal = windowHeight - (chartOffset + 6* chartOffset) - (int)(chartHeight * ( 1.0 * histGray[i] / grayMax ));
			g.setColor(Color.gray);
			g.drawLine(offsetX + i, windowHeight - chartOffset* 7, offsetX + i, yVal);
			
		/*	
			int yVal = windowHeight - chartOffset -  (int)( chartHeight * ( 1.0 * histRed[i] / redMax ));
			int yVal2 = windowHeight - chartOffset - (int)( chartHeight * ( 1.0 * histRed[i+1] / redMax ));
			g.setColor(Color.red);
			g.drawLine(offsetX + i, yVal, offsetX + i+1, yVal2);
			
			yVal = windowHeight - (chartOffset + 2*chartOffset) - (int)(chartHeight *  ( 1.0 * histBlue[i] / blueMax ));
			yVal2 = windowHeight - (chartOffset + 2*chartOffset) - (int)(chartHeight * ( 1.0 * histBlue[i+1] / blueMax ));
			g.setColor(Color.blue);
			g.drawLine(offsetX + i, yVal, offsetX + i+1, yVal2);
			
			yVal = windowHeight - (chartOffset + 4* chartOffset) - (int)(chartHeight * ( 1.0 * histGreen[i] / greenMax ));
			yVal2 = windowHeight - (chartOffset + 4*chartOffset) - (int)(chartHeight * ( 1.0 * histGreen[i+1] / greenMax ));
			g.setColor(Color.green);
			g.drawLine(offsetX + i, yVal, offsetX + i+1, yVal2);
			
			yVal = windowHeight - (chartOffset + 6* chartOffset) - (int)(chartHeight * ( 1.0 * histGray[i] / grayMax ));
			yVal2 = windowHeight - (chartOffset + 6*chartOffset) - (int)(chartHeight * ( 1.0 * histGray[i+1] / grayMax ));
			g.setColor(Color.gray);
			g.drawLine(offsetX + i, yVal, offsetX + i+1, yVal2);
		*/
		}
		this.repaint();
	
	}
	
	
	

}
