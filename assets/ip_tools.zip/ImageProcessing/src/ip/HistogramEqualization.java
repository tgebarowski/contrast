package ip;

import java.awt.Color;

import misc.ColorRGB;
import misc.ImageData;

public class HistogramEqualization {

	private ImageData pixelArray;
	private Histogram histogram;
	private int[] lut;

	
	public HistogramEqualization(ImageData pixelArray) {
		this.pixelArray = pixelArray;
		this.histogram = new Histogram(pixelArray);
	}
	
	private float[] getCumulativeHistogram(int[] hist) {
		
		float[] new_hist = new float[256];
		float coef = 1.0f / histogram.getPictureSize();
		new_hist[0] = hist[0] * coef;
		
		for(int i = 1; i < 256; i++)  {
			new_hist[i] = new_hist[i-1] + hist[i] * coef;
		}
		return new_hist;
	}
	
	private void createLut() {
		this.lut = new int[256];

		float[] cumHist = getCumulativeHistogram(histogram.getHistogramGray());
		
			
		for(int i = 0; i < 256; i++) {
			this.lut[i] = (int)(255 * cumHist[i]);
		}
	}
	
	public ImageData equalize() {
		
		int red,green,blue;
		int[] arr = pixelArray.getPixelArray();
		
		createLut();
		
		for(int i = 0; i < arr.length; i++ ) {
			//Extract color components
			red = (int)((arr[i]>>16)&0xFF);
		    green = (int)((arr[i]>>8)&0xFF);
		    blue = (int)(arr[i]&0xFF);
			
		    //Convert components read from lut into RGB format
			arr[i] = (int)(((int)lut[red] << 16) + ((int)lut[green] << 8) + (int)lut[blue]);	
		}
		pixelArray.setPixelArray(arr);
		return pixelArray;
		
	}
	
	
	
	
	
}
