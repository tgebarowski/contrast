package ip.kernels;

public class MeanKernel extends Kernel {

	public MeanKernel(int size) {
		
		//super(size * 2 + 1);
		super(size);
		//int length = size * 2 + 1;
		int length = size * size;
		
		this.matrix = new float[length];
		
		for(int i = 0; i < length; i++ ) {
			this.matrix[i] = 1.0f / length;
		}
	}

	
}
