package ip.kernels;

public class Kernel {
	
	protected float[] matrix;
	private int size;
	
	
	public Kernel(int size) {
		super();
		this.size = size;
	}
	
	
	public float[] getMatrix() {
		return matrix;
	}
	public void setMatrix(float[] matrix) {
		this.matrix = matrix;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}

	


}
