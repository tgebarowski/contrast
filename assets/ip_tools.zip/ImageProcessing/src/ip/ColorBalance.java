package ip;

import misc.ColorRGB;
import misc.ImageData;

public class ColorBalance {
	
	/**
	 * Enhance color balance
	 * @param pixelArray
	 * @return
	 */
	public static ImageData enhance(ImageData pixelArray) {
		
		int currentColorValue;
		int []pixelsArr = pixelArray.getPixelArray();
		
		Histogram histogram = new Histogram(pixelArray);
		histogram.calculateCumulativeComponents();
		
		float coefR = histogram.getCoefR();
		float coefG = histogram.getCoefG();
		float coefB = histogram.getCoefB();
		
		System.out.println(coefR + " " + coefG + " " + coefB);
		for( int pos = 0; pos < pixelsArr.length; pos++  ) {
			currentColorValue = pixelsArr[pos];
						
			float red = ((currentColorValue>>16)&0xFF);
		    float green = ((currentColorValue>>8)&0xFF);
		    float blue = (currentColorValue&0xFF);
		    
		    red *= coefR;
		    green *= coefG;
		    blue *= coefB;
		    
		    if (red > 255 )
		    	red = 255;
		    else if ( red < 0)
		    	red = 0;
		    
		    if (blue > 255)
		    	blue = 255;
		    else if ( blue < 0)
		    	blue = 0;
		    
		    if( green > 255)
		    	green = 255;
		    else if ( green < 0)
		    	green = 0;
		    
		    
		    pixelsArr[pos] = ((int)red<<16) + ((int)green<<8) + (int)blue;
		}
		
		pixelArray.setPixelArray(pixelsArr);
		
		
		return pixelArray;
		
	}

}
