package ip;

import misc.Complex;
import misc.ImageData;
import misc.SpectrumImage;

public class InverseFFT{

	  /**
	   * Default no argument constructor.
	   */
	  public InverseFFT(){
	  }
	  
	  /**
	   * Recursively applies the 1D inverse FFT algorithm.
	   *
	   * @param x Complex array containing the input to the 1D inverse FFT.
	   * @return Complex array containing the result of the 1D inverse FFT.
	   */
	  public Complex [] recursiveInverseFFT (Complex [] x) 
	  {
	    Complex z1,z2,z3,z4,tmp,cTwo;
	    int n = x.length;
	    int m = n/2;
	    
	    Complex [] result = new Complex [n];
	    Complex [] even = new Complex [m];
	    Complex [] odd = new Complex [m];
	    Complex [] sum = new Complex [m];
	    Complex [] diff = new Complex [m];
	    
	    cTwo = new Complex(2,0);
	    
	    if(n==1)    {
	    	result[0] = x[0];
	    } else {
		      z1 = new Complex(0.0, 2*(Math.PI)/n);
		      tmp = z1.exp();
		      z1 = new Complex(1.0, 0.0);
		      for(int i=0;i<m;++i) {
					z3 = x[i].plus(x[i+m]);
					sum[i] = z3.div(cTwo);
					
					z3 = x[i].minus(x[i+m]);
					z4 = z3.times(z1);
					diff[i] = z4.div(cTwo);
					
					z2 = z1.times(tmp);
					z1 = new Complex(z2.real(), z2.imag());
		      }
	      even = recursiveInverseFFT(sum);
	      odd = recursiveInverseFFT(diff);
	      
	      for(int i=0;i<m;++i){
			result[i*2] = new Complex(even[i].real(), even[i].imag());
			result[i*2 + 1] = new Complex(odd[i].real(), odd[i].imag());
	      }
	    }
	    return result;
	  }

	  /**
	   * Takes a TwoDArray, applies the 2D inverse FFT to the input by applying
	   * the 1D inverse FFT to each column and then each row in turn.
	   *
	   * @param input TwoDArray containing the input image data.
	   * @return TwoDArray containing the new image data.
	   */
	  public ImageData transform(SpectrumImage input){
		  
		input.translateToTopLeft(); 
	    SpectrumImage intermediate = new SpectrumImage(input.getWidth(), input.getHeight());
	    SpectrumImage output = new SpectrumImage(input.getWidth(), input.getHeight());
 
	    
	    for(int i=0;i<input.getWidth();++i){
	    	intermediate.putColumn(i, recursiveInverseFFT(input.getColumn(i)));
	    }
	
	    for(int i=0;i<intermediate.getHeight();++i) {
	    	output.putRow(i, recursiveInverseFFT(intermediate.getRow(i)));
	    }

	    return output.getImageData();
	  }
  
}