package ip;

import misc.Complex;
import misc.SpectrumImage;

public class FFT {

	
	  /**
	   * Data structure to hold the input to the algorithm.
	   */
	  private SpectrumImage input;
	  /**
	   * Data structure to hold the intermediate results of the algorithm.
	   * After applying the 1D FFT to the columns but before the rows.
	   */
	  private SpectrumImage intermediate;
	  /**
	   * Data structure to hold the ouput of the algorithm.
	   */
	  private SpectrumImage output;


	  /** 
	   * Constructor to set up an FFT object and then automatically 
	   * apply the FFT algorithm.
	   *
	   * @param pixels  int array containing the image data.
	   * @param w  The width of the image in pixels.
	   * @param h  The height of the image in pixels.
	   */
	  public FFT(int [] pixels, int w, int h){
	    input = new SpectrumImage(w,h,pixels);
	    intermediate = new SpectrumImage(w,h,pixels);
	    output = new SpectrumImage(w,h,pixels);
	    transform();
	  }
	  
	  /**
	   * Method to recursively apply the 1D FFT to a Complex array.
	   *
	   * @param  x  A Complex array containing a row or a column of
	   * image data.
	   * @return A Complex array containing the result of the 1D FFT.
	   */
	  private static Complex [] recursiveFFT (Complex [] x){
	    Complex z1,z2,z3,z4,tmp,cTwo;
	    int n = x.length;
	    int m = n/2;
	    Complex [] result = new Complex [n];
	    Complex [] even = new Complex [m];
	    Complex [] odd = new Complex [m];
	    Complex [] sum = new Complex [m];
	    Complex [] diff = new Complex [m];
	    
	    cTwo = new Complex(2,0);
	    if(n==1){
	    	result[0] = x[0];
	    } else {
		    z1 = new Complex(0.0, -2*(Math.PI)/n);
		    tmp = z1.exp();
		    z1 = new Complex(1.0, 0.0);
		    for(int i=0;i<m;++i){
				z3 = x[i].plus(x[i+m]);
				sum[i] = z3.div(cTwo);
				
				z3 = x[i].minus(x[i+m]);
				z4 = z3.times(z1);
				diff[i] = z4.div(cTwo);
				
				z2 = z1.times(tmp);
				z1 = new Complex(z2.real(), z2.imag());
		    }
		    even = recursiveFFT(sum);
		    odd = recursiveFFT(diff);
	      
	      for(int i=0;i<m;++i){
			result[i*2] = new Complex(even[i].real(), even[i].imag());
			result[i*2 + 1] = new Complex(odd[i].real(), odd[i].imag());
	      }
	    }
	    return result;
	  }
	   
	  /**
	   * Method to apply the 2D FFT by applying the recursive 1D FFT to the
	   * columns and then the rows of image data.
	   */ 
	  private void transform(){
	      
	      for(int i=0;i<input.getWidth();++i){
	    	  intermediate.putColumn(i, recursiveFFT(input.getColumn(i)));
	      }
	      for(int i=0;i<intermediate.getHeight();++i){
	    	  output.putRow(i, recursiveFFT(intermediate.getRow(i))); 
	      }

	      output.translateToCenter();
	  }
	  
	  public SpectrumImage getSpectrumImage() {
		  return this.output;
	  }
	  
}
