package ip;

import java.awt.image.BufferedImage;

import misc.ColorRGB;
import misc.Complex;
import misc.ImageData;
import misc.SpectrumImage;
import misc.SpectrumImage.SpectrumInfo;

public class FrequencyAnalyzer {
	
	private FFT fourierTransform;
	private ImageData image;
	private int width;
	private int height;
	
	public FrequencyAnalyzer(ImageData imageData) {
		this.width = imageData.getXSize();
		this.height = imageData.getYSize();
		this.image = imageData;
		
		ImageData extendedImageData = adjustDimensions(imageData);
		fourierTransform = new FFT(extendedImageData.getPixelArray(), extendedImageData.getXSize(), extendedImageData.getYSize());		
	}
	
	public ImageData inverseFFT() {
		InverseFFT inverse = new InverseFFT();
		ImageData iData = inverse.transform(fourierTransform.getSpectrumImage());
		iData = cropImage(iData, width, height);
		
		return iData;
	}

	
	public void removeMoire() {
		
		SpectrumImage spectrum = fourierTransform.getSpectrumImage();
		Complex[][] complexValues = spectrum.getValues();
		
		double meanAmplitude = Complex.getMeanAmplitude(complexValues);
		int width = complexValues.length;
		int height = complexValues[0].length;
		
	   	for(int x = 0; x < width; x++) {
    		for( int y = 0; y < height; y++) {
    			
    			//System.out.println("Val:" + complexValues[x][y].mod() + " avg:" + meanAmplitude);
    			
    			int midX = width / 2;
    			int midY = height / 2;
    			int threshold = 15;
    			
    			//if (complexValues[x][y].mod() >  1.75 * meanAmplitude && ((x < midX  && x > midX + threshold) && (y < midY && y > midY + threshold)) ) {
    			if (complexValues[x][y].mod() >  1.75 * meanAmplitude && ((x > midX + threshold || x < midX - threshold) && (y > midY + threshold || y < midY - threshold)) ) {
    				System.out.println("Orig: " + complexValues[x][y].arg() + " mod: "  + complexValues[x][y].mod() +  " x:" + x + "y:" + y );
    				complexValues[x][y] = Complex.getMeanComplexFromRegion(complexValues, x, y, 3);
    				//System.out.println("Modified: "  + complexValues[x][y].arg() + " mod: "  + complexValues[x][y].mod());
    				System.out.println("HIT");
    			}
    			
    			
    		}
    	}
		spectrum.setValues(complexValues);

	}
	
	public BufferedImage getMagnitudeImage() {		
		return fourierTransform.getSpectrumImage().getBufferedImage(SpectrumInfo.Magnitude);
	}
	
	public BufferedImage getPhaseImage() {		
		return fourierTransform.getSpectrumImage().getBufferedImage(SpectrumInfo.Phase);
	}
	
	public BufferedImage getRealPartImage() {		
		return fourierTransform.getSpectrumImage().getBufferedImage(SpectrumInfo.Real);
	}
	
	public BufferedImage getImaginaryPartImage() {		
		return fourierTransform.getSpectrumImage().getBufferedImage(SpectrumInfo.Imaginary);
	}
	
	public BufferedImage getMagnitudeLogImage() {		
		return fourierTransform.getSpectrumImage().getBufferedImage(SpectrumInfo.MagnitudeLog);
	}

	
	public BufferedImage getRealPartLogImage() {		
		return fourierTransform.getSpectrumImage().getBufferedImage(SpectrumInfo.RealLog);
	}
	
	public BufferedImage getImaginaryPartLogImage() {		
		return fourierTransform.getSpectrumImage().getBufferedImage(SpectrumInfo.ImaginaryLog);
	}

	private static ImageData adjustDimensions(ImageData pixelArray) {
		
		int width = pixelArray.getXSize();
		int height = pixelArray.getYSize();
		int newWidth =  nearestPowerOfTwo(width);
		int newHeight =  nearestPowerOfTwo(height);
		int dHeight = newHeight - height;

		int[] extArr = new int[newWidth * newHeight];
		int[] pixels = pixelArray.getPixelArray();
		
		int col = 0; int row = 0;
		
		for (int i = 0; i < extArr.length; i++ ) {
			
			if ( col < width ) {
				int p = row * width + col;
				extArr[i] = pixels[row * width + col]; col++;
			} else if ( col >= width && col <  newWidth) {
				extArr[i] = 0xFFFFFF; col++;
			} else {
				col = 0; row++;
				i--;
			}
			
			if ( row >= height) {
				for(int pos = 0; pos < dHeight * newWidth; pos++) {
					extArr[i + pos] = 0xFFFFFF;
				}
				System.out.print("aaaaaa");
				break;
			}
		}
		
		
		System.out.println(width + "=>" + nearestPowerOfTwo(width));
		System.out.println(height +  "=>" + nearestPowerOfTwo(height));
		
		ImageData newPxArr = new ImageData(newWidth, newHeight);
		newPxArr.setPixelArray(extArr);
	
		return newPxArr;
	}
	
	
	private static ImageData cropImage(ImageData pixelArray, int newWidth, int newHeight) {
		
		int[] cropArr = new int[newWidth * newHeight];
		int[] pixels = pixelArray.getPixelArray();
		int width = pixelArray.getXSize();
		int height = pixelArray.getYSize();
		
		int dWidth = width - newWidth;
		
		int row = 0; int col = 0;
		int offset = 0;
		
		for(int pos = 0; pos < cropArr.length; pos++ ) {
			
			if ( col < newWidth) {
				cropArr[pos] = pixels[pos + offset]; col++;
			} else if ( col == newWidth ) {
				offset += dWidth;
				row++; col = 0;pos--;
			}
			
			if ( row >= newHeight)
				break;
		}
		
		ImageData newPxArr = new ImageData(newWidth, newHeight);
		newPxArr.setPixelArray(cropArr);
	
		return newPxArr;
		
	}
	
	private static int nearestPowerOfTwo(int n) {
		double log2 = Math.log(n)/Math.log(2.0);
		int power = (int)Math.ceil(log2);
		return (int)Math.pow(2, power);
	}
}
