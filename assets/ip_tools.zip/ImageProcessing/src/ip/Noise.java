package ip;

import misc.ImageData;
import misc.Utils;

public class Noise {
	
	public static ImageData randomNoise(ImageData pixelArray, int intensity) {
		
		int[] pixels = pixelArray.getPixelArray();
		
		for(int i = 0; i < pixels.length; i++ ) {
			int color = pixels[i];
			float red = ((color>>16)&0xFF);
		    float green = ((color>>8)&0xFF);
		    float blue = (color&0xFF);
			
		    int randInt = Utils.nextInt(-intensity, intensity);
		    
		    red += randInt;
		    blue += randInt;
		    green += randInt;
		    
		    if (red > 255 )
		    	red = 255;
		    else if ( red < 0)
		    	red = 0;
		    
		    if (blue > 255)
		    	blue = 255;
		    else if ( blue < 0)
		    	blue = 0;
		    
		    if( green > 255)
		    	green = 255;
		    else if ( green < 0)
		    	green = 0;
		   
		    pixels[i] = ((int)red<<16) + ((int)green<<8) + (int)blue;
		}
		
		return pixelArray;
	}
	
	
	public static ImageData saltAndPepperNoise(ImageData pixelArray, int density) {
		
		int[] pixArr = pixelArray.getPixelArray();
		int pos = 0;
		
		
		while(pos < pixArr.length) {
			int color = Utils.getSaltOrPepper();
			pixArr[pos] = ((int)color<<16) + ((int)color<<8) + (int)color;
			pos += (int)(density * Math.random());
		}
		pixelArray.setPixelArray(pixArr);
		
		return pixelArray;
	}

}
