package ip;

import misc.ImageData;

public class Rotation {
	
	public static enum RotationType {Left, Right, Left_Flip, Right_Flip};
	

	public static ImageData rotateBy90(ImageData pixelArray, RotationType rotation) {
			
			int xSize = pixelArray.getXSize();
			int ySize = pixelArray.getYSize();
			
			ImageData transPixelArray = new ImageData(ySize,xSize);
			
			for( int i = 0; i < xSize; i++) {
				for( int j = 0; j < ySize; j++ ) {
					if (rotation == RotationType.Right_Flip)
						transPixelArray.setPixel(ySize-1-j, xSize-1-i, pixelArray.getPixel(i, j));
					else if ( rotation == RotationType.Left_Flip)
						transPixelArray.setPixel(j, i, pixelArray.getPixel(i, j));
					else if ( rotation == RotationType.Right) 
						transPixelArray.setPixel(j, i, pixelArray.getPixel(i, ySize - j - 1));
					else if ( rotation == RotationType.Left) 
						transPixelArray.setPixel(ySize-1-j, xSize-1-i, pixelArray.getPixel(i, ySize - j - 1));
					
				}
			}
			return transPixelArray;
	}
	
	public static ImageData rotate(ImageData pixelArray, double angle, boolean isBilinear) {
		
		double appX, appY; 
		int xSize = pixelArray.getXSize();
		int ySize = pixelArray.getYSize();

		ImageData transPixelArray = new ImageData(xSize,ySize);
		
		double cV = Math.cos(angle);
		double sV = Math.sin(angle);
		
		int cX = xSize / 2;
		int cY = ySize / 2;	
		
		for( int i = 0; i < xSize; i++) {
			for( int j = 0; j < ySize; j++ ) {
				int ox = i - cX;
				int oy = j - cY;
				double nx = ox * cV + oy * sV;
				double ny = -ox * sV + oy * cV;
				appX = nx + cX;
				appY = ny + cY;				
				
				int pxValue = 0;
				
				if (isBilinear)
					pxValue = pixelArray.getBiPixel(appX, appY);
				else
					pxValue = pixelArray.getNvPixel(appX, appY);

				transPixelArray.setPixel(i,j, pxValue);
			}
		}
		return transPixelArray;

	}
	
	
}
