package ip;

import ip.kernels.Kernel;

import java.awt.Dimension;

import misc.ColorRGB;
import misc.ImageData;
import misc.Utils;

public class Filters {
	
	
	/**
	 * Median Filter Algorithm
	 * Setting value of currently processed pixel into the median of values taken from square region of size maskSize
	 * @param pixArr
	 * @param maskSize
	 * @return
	 */
	public static ImageData medianFilter(ImageData pixArr, int maskSize) {
		
		int xSize = pixArr.getXSize();
		int ySize = pixArr.getYSize();
		int xMid =  maskSize / 2;
		int yMid =  maskSize / 2;
		int matrixDim = maskSize * maskSize;

		for(int x = 0; x < xSize; x++) {
			for(int y = 0; y < ySize; y++ )
			{	
				int[] arrR  = new int[matrixDim];
				int[] arrG  = new int[matrixDim];
				int[] arrB  = new int[matrixDim];
				int pos = 0;
				
				for (int row = -yMid; row <= yMid; row++) {
					for (int col = -xMid; col <= xMid; col++) {
						int iy = y+row;
						int ix = x+col;
						
						if (ix > 0 && iy > 0 && ix < xSize && iy < ySize) {
							int pixel = pixArr.getPixel(ix, iy);
							arrR[pos] += ((pixel >> 16) & 0xff);
							arrG[pos] += ((pixel >> 8) & 0xff);
							arrB[pos++] += (pixel & 0xff);
						}
						
					}					
				}
				int r = Utils.median(arrR);
				int g = Utils.median(arrG);
				int b = Utils.median(arrB);				
				int rgb = ( (int)r << 16) | ( (int)g << 8) |  (int)b;
				pixArr.setPixel(x, y,rgb);
			}

		}
		return pixArr;
	}
	
	/**
	 * Convolution Filter implementation
	 * @param pixelArray
	 * @param kernel
	 * @return
	 */
	public static ImageData convolutionFilter(ImageData pixelArray, Kernel kernel) {

		int pos = 0;
		int xSize = pixelArray.getXSize();
		int ySize = pixelArray.getYSize();		
		int[] pxArr = pixelArray.getPixelArray();
		int[] resultArr = new int[xSize * ySize];	
		
		int xKernel = kernel.getSize();
		int yKernel = kernel.getSize();
		int xMid = xKernel / 2;
		int yMid = yKernel / 2;

		
		float[] matrix = kernel.getMatrix();
		
		for (int y = 0; y < ySize; y++) {
			for (int x = 0; x < xSize; x++) {
				
				float r = 0, g = 0, b = 0;

				//Iterating over kernel matrix
				for (int row = -yMid; row <= yMid; row++) {
					int iy = y+row;
					int ioffset;
					
					//Boundary Handling
					if (0 <= iy && iy < ySize)
						ioffset = iy*xSize;
					else
						continue;
					
					//Offset in Matrix
					int matrixOffset = xKernel*(row+yMid)+xMid;
					for (int col = -xMid; col <= xMid; col++) {
						float f = matrix[matrixOffset+col];

						if (f != 0) {
							int ix = x+col;
							//Boundary Handling
							if (!(0 <= ix && ix < xSize))
									continue;

							int rgb = pxArr[ioffset+ix];
							r += f * ((rgb >> 16) & 0xff);
							g += f * ((rgb >> 8) & 0xff);
							b += f * (rgb & 0xff);
						}
					}
				}
				resultArr[pos++] = ( (int)r << 16) | ( (int)g << 8) |  (int)b;
			}
		}
		pixelArray.setPixelArray(resultArr);
		return pixelArray;
	}
	
	/**
	 * Gaussian Filter based on specified kernel.
	 * Procesing image vertically and horizontally using gaussianFilterPartial method
	 * @param pixelArray
	 * @param kernel
	 * @return
	 */
	public static ImageData gaussianFilter(ImageData pixelArray, Kernel kernel) {
		
			int width = pixelArray.getXSize();
			int height = pixelArray.getYSize();
			ImageData result = gaussianFilterPartial(pixelArray, kernel, width, height);
			result = gaussianFilterPartial(result, kernel, height, width);
			return result;
	}
	
	
	/**
	 * Gausian Filter one dimensional mask implementation
	 * @param pixelArray
	 * @param kernel
	 * @param width
	 * @param height
	 * @return
	 */
	private static ImageData gaussianFilterPartial(ImageData pixelArray, Kernel kernel, int width, int height) {
		float[] matrix = kernel.getMatrix();
		int[] pxArr = pixelArray.getPixelArray();
		int[] resultArr = new int[width * height];	
		int cols = kernel.getSize();
		int xMid = cols/2;

		for (int y = 0; y < height; y++) {
			int pos = y;
			int ioffset = y*width;
			for (int x = 0; x < width; x++) {
				float r = 0, g = 0, b = 0, a = 0;
				int moffset = xMid;
				for (int col = -xMid; col <= xMid; col++) {
					float f = matrix[moffset+col];

					if (f != 0) {
						int ix = x+col;
						if ( ix < 0 ) {
							ix = 0;
			
						} else if ( ix >= width) {
								ix = width-1;
						}
						int rgb = pxArr[ioffset+ix];
			
						r += f * ((rgb >> 16) & 0xff);
						g += f * ((rgb >> 8) & 0xff);
						b += f * (rgb & 0xff);
					}
				}
				resultArr[pos] = ( (int)r << 16) | ( (int)g << 8) |  (int)b;
                pos += height;
			}
		}	
		pixelArray.setPixelArray(resultArr);
		return pixelArray;
	}
	
	
	/**Mean Blur Filter - first implementation
	 * 
	 * @param pixArr
	 * @param matrixSize
	 * @deprecated
	 * @return
	 */ 
	public static ImageData meanFilter(ImageData pixArr, Dimension matrixSize) {
		
		int xSize = pixArr.getXSize();
		int ySize = pixArr.getYSize();

		int xMid = matrixSize.width / 2;
		int yMid = matrixSize.height / 2;
		int matrixDim = matrixSize.height * matrixSize.width;
		
		for(int x = 0; x < xSize; x++) {
			for(int y = 0; y < ySize; y++ )
			{	
				int sumR = 0, sumG = 0, sumB = 0;
				
				for (int row = -yMid; row <= yMid; row++) {
					for (int col = -xMid; col <= xMid; col++) {
						int iy = y+row;
						int ix = x+col;
						
						if (ix > 0 && iy > 0 && ix < xSize && iy < ySize) {
							int pixel = pixArr.getPixel(ix, iy);
							ColorRGB cRGB = new ColorRGB(pixel);
							sumR += cRGB.getR();
							sumG += cRGB.getG();
							sumB += cRGB.getB();
						}
						
					}					
				}
				pixArr.setPixel(x, y, (new ColorRGB(sumR/matrixDim, sumG/matrixDim, sumB/matrixDim)).toRGB() );
			}

		}
		return pixArr;
	}


}
