package ip;

import misc.ColorRGB;
import misc.ImageData;

public class Histogram {
	
	private int[] histogramR;
	private int[] histogramG;
	private int[] histogramB;
	private int[] histogramGray;
	private int pictureSize;
	
	private float cumR, cumG, cumB, cumMax;
	
	private ImageData pixArr;
	private boolean isGreyscale = false;
	
	
	public Histogram(ImageData pixArr) {
		this.pixArr = pixArr;	
		isGreyscale = pixArr.isGreyscale();
		
		histogramR = new int[256];
		histogramG = new int[256];
		histogramB = new int[256];
		histogramGray = new int[256];
		generate();
		pictureSize = pixArr.getXSize() * pixArr.getYSize();
	}
	
	/** Generate Histogram
	 * 
	 */
	public void generate() {
		int[] arr = pixArr.getPixelArray();
		
		for(int i = 0; i < arr.length; i++) {
			ColorRGB color = new ColorRGB(arr[i]);
			histogramR[color.getR()]++;
			histogramG[color.getG()]++;
			histogramB[color.getB()]++;		
			histogramGray[color.getGray()]++;
		}
	}
	
	/**
	 * Calculate coefficients for color balance
	 */
	public void calculateCumulativeComponents() {
	
		generate();
		
		for(int i = 0; i < histogramGray.length; i++ ) {
			this.cumR +=  histogramR[i] * i;
			this.cumG +=  histogramG[i] *  i;
			this.cumB +=  histogramB[i] * i;
		}
		
		this.cumMax = Math.max(cumR, Math.max(cumG, cumB));
	}
	
	public float getCoefR() {
		if ( cumMax == cumR)
			return 1.0f;
		else if ( cumMax != 0 )
			return 1.0f +  1.0f * cumR / cumMax;
		
		return 0;
	}
	
	public float getCoefG() {

		if ( cumMax == cumG)
			return 1.0f;
		else if ( cumMax != 0 )
			return 1.0f +  1.0f * cumG / cumMax;
		
		return 0;
	}
	
	public float getCoefB() {	
		if ( cumMax == cumB)
			return 1.0f;
		else if ( cumMax != 0 )
			return 1.0f +  1.0f * cumB / cumMax;
		
		return 0;
	}
	
	
	public int[] getHistogramR() {
		return histogramR;
	}
	
	public int[] getHistogramG() {
		return histogramG;
	}
	
	public int[] getHistogramB() {
		return histogramB;
	}
	
	public int[] getHistogramGray() {
		return histogramGray;
	}

	public int getPictureSize() {
		return pictureSize;
	}

}
