package ip;

import java.awt.Color;

import misc.ColorRGB;
import misc.ImageData;
public class Saturation {
	
	
	public static ImageData enhance(ImageData pixelArray, float saturation) {
		
		int []pixelsArr = pixelArray.getPixelArray();
		int currentColorValue;
		float sat;
		
		for( int pos = 0; pos < pixelsArr.length; pos++  ) {
			currentColorValue = pixelsArr[pos];
			int colorHSB = ColorRGB.RGBtoHSB(currentColorValue);
		    float brithness = ((colorHSB & 0xFF) / 255.0f);

		    if ( brithness < 0.75) {
		    	sat = saturation * 255.0f;
				colorHSB = (colorHSB & 0xFF00FF);
				colorHSB = colorHSB | ((int)sat << 8 );
				pixelsArr[pos] = ColorRGB.HSBtoRGB(colorHSB);
		    }
		}
		
		pixelArray.setPixelArray(pixelsArr);
		
		return pixelArray;
		
	}
	
	

}
