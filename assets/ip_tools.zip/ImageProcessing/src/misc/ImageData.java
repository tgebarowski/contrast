package misc;

import gui.MainFrame;

import java.awt.image.BufferedImage;

import org.apache.log4j.Logger;

/**
 * PixelArray Class representing image data.
 * Acts as a mapping between 2-dimensional and 1-dimension representation
 * @author tomaszgebarowski
 *
 */
public class ImageData {
	
	private int xSize, ySize;
	private boolean isGreyscale = false;
	private int[] pixelArray;
	
	public ImageData(int xSize, int ySize) {
		
		this.xSize = xSize;
		this.ySize = ySize;
		this.pixelArray = new int[xSize*ySize];
		
	}
	
	public ImageData(BufferedImage hBufImage) {
		this.xSize = hBufImage.getWidth();
		this.ySize = hBufImage.getHeight();
		this.isGreyscale = (hBufImage.getType() == BufferedImage.TYPE_BYTE_GRAY) ? true : false;
		this.pixelArray = hBufImage.getRGB(0,0, xSize, ySize, pixelArray, 0, xSize);
	}

	public int getXSize() {
		return xSize;
	}

	public int getYSize() {
		return ySize;
	}
	
	
	public int getMin(){

		int position = 0;
		double min = pixelArray[0];

		for(int i = 1; i< xSize* ySize ; i++)
		{
			if(pixelArray[i]< min)
			{
		  	  min = pixelArray[i];
	 		  position = i;
	   		}		   
		}

	   return pixelArray[position];
	}
	
	public int getMax(){

		int position = 0;
		double max = pixelArray[0];

		for(int i = 1; i< xSize* ySize ; i++)
		{
			if(pixelArray[i] > max)
			{
		  	  max = pixelArray[i];
	 		  position = i;
	   		}		   
		}
	   return pixelArray[position];
	}

	/**
	 * Get Interpolated Pixel value using Neighboring Pixel Approximation Method
	 * @param x Floating point X coordinate
	 * @param y Floating point Y coordinate
	 * @return  Approximated pixel value
	 */
	public final int getNvPixel(double x, double y) {
		return this.getPixel( (int)Math.floor(x), (int)Math.floor(y));
	}
	
	/**
	 * Get Interpolated Pixel value using Bilinear Interpolation Method
	 * Wu,vI(u,v)+Wu+1,vI(u+1,v)+Wu,v+1I(u,v+1)+Wu+1,v+1I(u+1,v+1)
	 * @param x Floating point X coordinate
	 * @param y Floating point Y coordinate
	 * @return Approximated pixel value
	 */
	public int getBiPixel(double x, double y) {
		
		int u = (int)Math.floor(x);
		int v = (int)Math.floor(y);
		
		int comp1 = mulWvI( W_uv(u,v,x,y), this.getPixel(u, v));
		int comp2 = mulWvI( W_u1v(u,v,x,y), this.getPixel(u+1, v));
		int comp3 = mulWvI( W_uv1(u,v,x,y), this.getPixel(u, v+1));
		int comp4 = mulWvI( W_u1v1(u,v,x,y), this.getPixel(u+1, v+1));
		
		return comp1 + comp2 + comp3 + comp4;
	}
	
	
	public final int getPixel(int x, int y) {
		int pos = x + y * xSize;
		
		if ( pos >= 0 && pos < xSize * ySize) {
			
			if ( x>= 0 && y >= 0 && x < xSize && y < ySize)
				return this.pixelArray[pos];
		}
		
		return -1;
	}
	
	public void setPixel(int x, int y, int value) {
		int pos = x + y * xSize;
		
		if ( pos >= 0 && pos < xSize * ySize) {
			if ( x>= 0 && y >= 0 && x < xSize && y < ySize)
				this.pixelArray[pos] = value;
		}
	}


	public int[] getPixelArray() {
		return this.pixelArray;
	}
	
	public void setPixelArray(int[] pxArray) {
		this.pixelArray = pxArray;
	}
	
	public void normalize() {
		
		int min = getMin();
		int max = getMax();
		
		for(int i=0; i<ySize*xSize; i++)
		{
		    this.pixelArray[i] = (int)((pixelArray[i] - min) * 255) / (max-min);
		}
		
	}
	
	public static int mulWvI(double coeff, int intensity) {

		int mask = 0x000000FF;
		int result = 0;
		
		for (int i=0; i < 32; i+=8 ) {
			//logger.info("Mask: " + mask);
			int c = intensity & mask;
			mask = mask << 8;
			//logger.info("Color: " + c);
			int cMul = c >> i;
			cMul = (int)(coeff * cMul);
			cMul = cMul << i;
			
			result |= cMul;
		}
		return (int)result;
	}

	private double W_uv(int u, int v, double x, double y) {
		return (u+1-x) * (v+1-y);
	}
	
	private double W_u1v(int u, int v, double x, double y) {
		return (x-u) * (v+1-y);
	}

	private double W_uv1(int u, int v, double x, double y) {
		return (u+1-x) * (y-v);
	}
	
	private double W_u1v1(int u, int v, double x, double y) {
		return (x-u) * (y-v);
	}
	
	public boolean isGreyscale() {
		return this.isGreyscale;
	}

}
