package misc;

import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.Random;

import javax.swing.ImageIcon;


public class Utils {

    public final static String gif = "gif";
    public final static String tiff = "tiff";
    public final static String png = "png";
    public final static String jpeg = "jpeg";
    public final static String jpg = "jpg";
    public final static String bmp = "bmp";


    /*
     * Get the extension of a file.
     */  
    public static String getExtension(File f) {
        String ext = null;
        String str = f.getName();
        int i = str.lastIndexOf('.');

        if (i > 0 &&  i < str.length() - 1) {
            ext = str.substring( i+1 ).toLowerCase();
            
            if (ext.equals(gif) || ext.equals(tiff) || ext.equals(png) || ext.equals(jpg) || ext.equals(jpeg)  || ext.equals(bmp) )
            	return ext;
        }   
        return "None";
 
    }
    
    
    public static ImageIcon createImageIcon(String path) {
		URL imgURL = Utils.class.getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL);
		} else {
			System.err.println("Couldn't find image in system: " + path);
			return null;
		}
	}
    
    
	public static int sumArray(int[] array) {
		int sum = 0;
		for (int i = 0; i < array.length; i++ ) {
			sum = array[i];
		}
		return sum;
	}

	public static int maxArray(int[] array) {
	    int maximum = array[0];   
	    for (int i=1; i<array.length; i++) {
	        if (array[i] > maximum) {
	            maximum = array[i];
	        }
	    }
	    return maximum;
	}
	
	public static int getSaltOrPepper() {
		double randVal = Math.random();
		
		if ( randVal <= 0.5) {
			return (int) Math.floor(randVal * 50);
		} else {
			return (int)Math.floor(randVal * 255);
		}	
		
	}
	
	public static int median(int[] arr) {
		
		Arrays.sort(arr);
		
	    int middle = arr.length/2;  
	    if (arr.length % 2 == 1) {
	        return arr[middle];
	    } else {
	       // Average of middle two elements
	       return (arr[middle-1] + arr[middle]) / 2;
	    }
	}
	
	
	public static int nextInt(int low, int high) {
		Random rnd = new Random();
		return Math.min(low, high) + rnd.nextInt(Math.abs(high - low));
	}
	
	
}