package misc;

import java.io.File;
import javax.swing.filechooser.*;

public class ImageChooserFilter extends FileFilter {

    public boolean accept(File f) {
        
    	if (f.isDirectory()) {
            return true;
        }

        String extension = Utils.getExtension(f);
        if (extension != null) {
            if (extension.equals(Utils.gif) ||
                extension.equals(Utils.tiff) ||
                extension.equals(Utils.png) ||
                extension.equals(Utils.jpg) ||
                extension.equals(Utils.jpeg)) {
                    return true;
            } else {
                return false;
            }
        }

        return false;
    }

    //The description of this filter
    public String getDescription() {
        return "Image files";
    }
}