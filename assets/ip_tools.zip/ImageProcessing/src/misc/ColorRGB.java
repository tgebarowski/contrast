package misc;


public class ColorRGB {
	
	private int r;
	private int g;
	private int b;
	
	public ColorRGB(int r, int g, int b) {
		super();
		this.r = r;
		this.g = g;
		this.b = b;
	}
	
	public ColorRGB(long colorValue) {
		this.r = (int)((colorValue>>16)&0xFF);
	    this.g = (int)((colorValue>>8)&0xFF);
	    this.b = (int)(colorValue&0xFF);
	}
	
	public int getR() {
		return r;
	}
	
	public void setR(int r) {
		this.r = r;
	}
	public int getG() {
		return g;
	}
	public void setG(int g) {
		this.g = g;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}

	public int getGray() {
		return (int)(0.3*r + 0.59*g + 0.11*b);
	}
	
	public static ColorRGB getFromGray(int gray) {
		return new ColorRGB((int)(0.3 * gray), (int)(0.59 * gray), (int)(0.11 * gray));
	}
	
	/**
	 * Function used for converting colors from RGB palette to HSB
	 * @param color
	 * @return
	 */
	public static int RGBtoHSB(int color) {
		
		float hue = 0, saturation = 0,brithness = 0;
		
		//Extract RGB components from color
		float red = ((color>>16)&0xFF) / 255.0f;
	    float green = ((color>>8)&0xFF) / 255.0f;
	    float blue = (color&0xFF) / 255.0f;
	
	    float max = Math.max(red, Math.max(green,blue));
	    float min = Math.min(red, Math.min(green,blue));
	    float delta = max - min;
	    
	    //Calculate Saturation
	    if ( max == 0 )
	    	saturation = 0;
	    else
	    	saturation  = 1 - min/max;
	    
	    //Calculate Brithness
	    brithness = max;
	    
	    if ( max == min)
	    	hue = 0;
	    else if ( max == red && green >= blue)
	    	hue = 60 * ( green - blue) / delta;
	    else if ( max == red && green < blue)
	    	hue = 60 * ( green - blue) / delta + 360;
	    else if ( max == green )
	    	hue = 60 * ( blue - red) / delta + 120;
	    else if ( max == blue)
	    	hue = 60 * ( red - green) / delta + 240;

	    //Normalize Hue
	    int factor = (int) Math.floor(hue / 360);
	    hue = hue - factor * 360;
	    //Multiply values in order to store them as one integer
	    //Hue is already in range <0;360>
	    saturation *= 255.0f;
	    brithness *= 255.0f;
	    
	    //System.out.println("HUE: " + hue + " " + saturation + " " + brithness);
	    
	    return ((int)hue<<16) + ((int)saturation<<8) + (int)brithness;
	}
	
	public int toRGB() {	
		return ((int)this.r<<16) + ((int)this.g<<8) + (int)this.b;
	}
	
	public static int HSBtoRGB(int color ) {
		
		float hue = ((color>>16)&0xFF);
	    float saturation = ((color>>8)&0xFF);
	    float brithness = (color&0xFF);
		System.out.println(hue);
	    //System.out.println("MY HUE: " + hue / 360.0 + " " + saturation / 255.0f + " " + brithness / 255.0f);
	    
	    saturation /= 255.0f;
	    brithness /= 255.0f;
	    
	    int quotient = (int)(Math.floor( hue / 60.0f) % 6);
	    float fraction  = (float) (hue / 60.0f - Math.floor(hue / 60.0f));
	    
	    float p = brithness * ( 1 - saturation);
	    float q = brithness * ( 1 - fraction * saturation);
	    float t = brithness * ( 1 - (1 - fraction) * saturation);
	    
	    //Multiple components in order to store them in one integer
	    p *= 255; q *= 255; t *= 255; brithness *= 255.0f;
	    
	    switch(quotient) {
		    case 0: return ((int)brithness<<16) + ((int)t<<8) + (int)p;
		    case 1: return ((int)q<<16) + ((int)brithness<<8) + (int)p;
		    case 2: return ((int)p<<16) + ((int)brithness<<8) + (int)t;
		    case 3: return ((int)p<<16) + ((int)q<<8) + (int)brithness;
		    case 4: return ((int)t<<16) + ((int)p<<8) + (int)brithness;
		    case 5: return ((int)brithness<<16) + ((int)p<<8) + (int)q;  
	    }
	    
	    
	    
	    
		return -1;
	}
	

}
