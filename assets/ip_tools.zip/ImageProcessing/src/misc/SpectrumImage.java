package misc;

import java.awt.image.BufferedImage;

public class SpectrumImage {
	
	private int width;
	private int height;
	private double[] imagArr;
	private double[] realArr;
	private double[] magnitudeArr;
	private double[] phaseArr;
	private double[] realLogArr;
	private double[] imagLogArr;
	private double[] magnitudeLogArr;
	
	private Complex[][] values;
	
	
	public enum SpectrumInfo { Imaginary, Real, Phase, Magnitude, RealLog, ImaginaryLog, MagnitudeLog };
	
	public SpectrumImage(int width, int height, int[] sImage) {
		System.out.println(width + " " + height);
		this.width = width;
		this.height = height;
		this.values = new Complex[width][height];
		
		for(int x = 0; x < width; x++) {
			for( int y = 0; y < height; y++ ) {
				values[x][y] = new Complex(sImage[y + x*width],0);
			}
		}

		
	}
	
	public SpectrumImage(int width, int height) {
		this.width = width;
		this.height = height;
		this.values = new Complex[width][height];
	}
	
	public void setValues(Complex[][] values ) {
		this.values = values;
	}
	
	public Complex[][] getValues() {
		return this.values;
	}
	
	/**
	 * Calculates characteristics of a spectrum
	 * @return
	 */
	public void calculate() {
		
		this.magnitudeArr = new double[getSize()];
		this.imagArr = new double[getSize()];
		this.realArr = new double[getSize()];
		this.phaseArr = new double[getSize()];
		this.imagLogArr = new double[getSize()];
		this.realLogArr = new double[getSize()];
		this.magnitudeLogArr = new double[getSize()];
		
		for(int pos = 0, x = 0; x < width; x++) {
			for(int y = 0; y < height; y++, pos++ ) {
				magnitudeLogArr[pos] = Math.log(values[x][y].real() * values[x][y].real() + values[x][y].imag() * values[x][y].imag());
				imagArr[pos] = values[x][y].imag();
				realArr[pos] = values[x][y].real();
				magnitudeArr[pos] = Math.sqrt(values[x][y].real() * values[x][y].real() + values[x][y].imag() * values[x][y].imag());
				imagLogArr[pos] = Math.log(values[x][y].imag());
				realLogArr[pos] = Math.log(values[x][y].real());
				phaseArr[pos] = values[x][y].arg();
			}
		}
	}


	public int getWidth() {
		return width;
	}

	public int getSize() {
		return width * height;
	}

	public int getHeight() {
		return height;
	}

	public Complex [] getColumn(int n){
	    Complex [] c = new Complex[getWidth()];
	    
	    for(int i=0; i<getWidth();i++){
	    	c[i] = new Complex(values[n][i].real(), values[n][i].imag());
	    }
	    return c;
	  }
	  
	  /**
	   * Takes a column number and an array of complex numbers and replaces
	   * that column with the new data.
	   *
	   * @param n int column number (0 is first column).
	   * @param Array of complex numbers representing the new data.
	   */
	  public void putColumn(int n, Complex [] c){
	    for(int i=0;i<getWidth();++i){
	    	values[n][i] = new Complex(c[i].real(), c[i].imag());
	    }
	  }
	 
	  /**
	   * Takes a row number and an array of complex numbers and replaces
	   * that row with the new data.
	   *
	   * @param n int row number (0 is first row).
	   * @param c Array of complex numbers representing the new data.
	   */
	  public void putRow(int n, Complex [] c){
	    for(int i=0;i<getHeight();++i){
	    	values[i][n] = new Complex(c[i].real(), c[i].imag());
	    }
	  }
	  
	  /** 
	   * Takes a row number and returns an array containing the 
	   * complex numbers in that row.
	   *
	   * @param n int row number (0 is first row).
	   * @return ComplexNumber array containing row.
	   */
	  public Complex [] getRow(int n){
	    Complex [] r = new Complex[getHeight()];
	    for(int i=0;i<getHeight();++i){
	    	r[i] = new Complex(values[i][n].real(), values[i][n].imag());
	    }
	    return r;
	  }
	  
	  
	  public void translateToCenter(){
		    Complex [][] output = new Complex [width][height];
		    int x = width/2;
		    int y = height/2;
		    int i2,j2;
		    for(int j=0;j<height;++j)
		    {
			      for(int i=0;i<width;++i){
					i2=i+x;
					j2=j+y;
					if(i2>=width)
						i2=i2%width;
					if(j2>=height)
						j2=j2%height;
					output[i][j] = values[i2][j2];
			       }
		    }
		    values = output;
	  }

	  /** 
	   * Takes a 2D array of doubles representing an image and translates
	   * and wraps the image to put the centre pixel at (0,0).
	   *
	   * @param input 2D array of doubles.
	   * @return 2D array of doubles representing the new image.
	   */
	  
	public void translateToTopLeft(){
 		Complex [][] output = new Complex [width][height];
		int i2,j2;
		int x = width/2;

		for(int j=0;j<height;++j) 
		{
			for(int i=0;i<width;++i){
				i2=i+x;
				j2=j+x;
				if(i2>=width)i2=i2%width;
				if(j2>=height)j2=j2%height;
					output[i][j] = values[i2][j2];
			 }
		}
		this.values = output;
	}

	
	public double getMin(double[] image){

	   int position = 0;
	   double min = image[0];

	   for(int i = 1; i< width * height ; i++)
	   {
	   		if(image[i]< min)
	   		{
	   		  min = image[i];
	   		  position = i;
	   		}
	   }

	   return image[position];
	}
	
	public BufferedImage getBufferedImage(SpectrumInfo type) {
		
		calculate();
		
		double[] data = new double[width*height];
		
		if( type == SpectrumInfo.Imaginary )
			data = this.imagArr;
		else if( type == SpectrumInfo.Real )
			data = this.realArr;
		else if( type == SpectrumInfo.Magnitude )
			data = this.magnitudeArr;
		else if( type == SpectrumInfo.Phase )
			data = this.phaseArr;
		else if( type == SpectrumInfo.RealLog )
			data = this.realLogArr;
		else if( type == SpectrumInfo.MagnitudeLog )
			data = this.magnitudeLogArr;
		else if( type == SpectrumInfo.ImaginaryLog )
			data = this.imagLogArr;
		
	  	
		BufferedImage bI = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		bI.setRGB(0, 0, width, height, normalize(data), 0, width);	
		
		return bI;
	}


	// FOR NORMALIZE
	/**
	* Return maximum gray value of the image
	*
	* @return maximum gray value
	*/
	public double getMax(double[] image){

	    int position = 0;
	    double max = image[0];

	    for(int i = 1; i< width * height ; i++)
	    {
			if(image[i]>max)
			{
				max = image[i];
				position = i;
			}
		}
		return image[position];
	}
	
	public ImageData getImageData() {
		
		ImageData imageData = new ImageData(width, height);
		double[] tmp = new double[width * height];
		//int[] pixels = new int[width * height];
		
		for(int pos = 0 , x = 0; x < width; x++) {
			for (int y = 0; y < height; y++, pos++ ) {
				tmp[pos] = values[x][y].real();
			}
		}
		int[] pixels = normalize(tmp);
	
		imageData.setPixelArray(pixels);
		
		return imageData;		
	}
	

	
	private int[] normalize(double[] image){

	  	double  min, max;

	  	min = getMin(image);
	  	max = getMax(image);
	  	
	  	int[] output = new int[width*height];

	  	
		if (max!=min)
		{
	  		for(int i = 0 ; i < width * height; i++) {
	  			output[i]=(int) ((int)((image[i]-min)*255)/(max-min));
	  			ColorRGB c = new ColorRGB(output[i], output[i], output[i]);
	  			output[i] = c.toRGB();
	  		}
	  		
		} else {
		    for (int i=0;i< width * height;i++)
		        output[i]=0;  
		}
		
		return output;
	 }

	

}
