package tests;

import misc.ImageData;
import junit.framework.TestCase;

public class PixelArrayTest extends TestCase {
	
	
	public void test() {
		
		int result = ImageData.mulWvI(1.0, 0x11223344);
		
		assertEquals(0x11223344, result);
		
	}

}
