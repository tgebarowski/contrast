package tests;

import java.awt.Color;

import junit.framework.TestCase;
import misc.ColorRGB;

public class ColorARGBTest extends TestCase {

	
	public void test_ColorARGB() {
		
		ColorRGB color = new ColorRGB(0xAB1020);
		System.out.println(color.getB());
		System.out.println(color.getG());
		System.out.println(color.getR());
		
	}
	
	public void testHSB() {
		System.out.println("Original RGB to HSB ");
		float[] hsbArr = Color.RGBtoHSB(250, 13, 13,null);
		System.out.println(hsbArr[0] + " " + hsbArr[1] + " " + hsbArr[2]);
		
		System.out.println("My RGB to HSB");
		int hsb = ColorRGB.RGBtoHSB(new Color(12,22,33).getRGB());
		
		int colorRGB = ColorRGB.HSBtoRGB(hsb);
		float red = ((colorRGB>>16)&0xFF);
	    float green = ((colorRGB>>8)&0xFF);
	    float blue = (colorRGB&0xFF);
	    System.out.println("MY RGB " + red  + " " + green + " " + blue );

		
		
	}
	
}
