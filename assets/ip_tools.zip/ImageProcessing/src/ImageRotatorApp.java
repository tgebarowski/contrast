import gui.MainFrame;


/**
 * Image Rotator Application
 * @author tomaszgebarowski
 *
 */
public class ImageRotatorApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       javax.swing.SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                MainFrame n = new MainFrame("Image Processing Toolkit");
	            }
	        });
		
	}

}
