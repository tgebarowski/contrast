Prerequisites

In order to start a server you need to have a MySQL database.
I prepared a sample MySQL dump file so that you can use it to generate the whole structure of the database.
This file can be found in db/MySQL.dump

By default the server listens on port 5054. You can change it in start.py file.
Database configuration is placed in db/DBM.py file, so adjust that to your needs.

Server startup

A PIMP server can be simply started by invoking a command ./start.py in the PIMP Server directory
