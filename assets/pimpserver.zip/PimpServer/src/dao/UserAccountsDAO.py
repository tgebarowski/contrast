from db import DBM
from helpers import Encryption
import dao
import logging;

sTableName = "UserAccounts"

class UserAccountsDAO:
    
    dbConnection = None
    id = None
    
    
    def __init__(self,id):
        """Constructor"""
        if id is not None:
            self.id = id
            self.load()
   

    def setId(self,id):
        self.id = id

    def setName(self,name):
        self.name = name
        
    def setNick(self,nick):
        self.nick = nick
        
    def setSurname(self,surname):
        self.surname = surname;
    
    def setPasswd(self, password):
        self.passwd = Encryption.PasswdEnc.encrypt(password)
        
    def setLocation(self, place,country):
        self.place = place
        self.country = country
        
    def setBirthday(self, birthday):
        self.birthday = birthday
        
    def setPrivilage(self, privilage):
        self.privilage = privilage
               
    
    def load(self):
        """Loads conent of object from a database"""
        global sTableName
        
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT nick,password,name,surname,birthday,country,place,privilage FROM %s WHERE id = %s" % (sTableName,self.id) )
        row = cursor.fetchone()
        
        self.setNick(row[0])
        self.setPasswd(row[1])
        self.setName(row[2])
        self.setSurname(row[3])
        self.setBirthday(row[4])
        self.setLocation(row[6],row[5])
        self.setPrivilage(row[7])
    
    def update(self):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("UPDATE %s SET nick='%s', name='%s', surname='%s', birthday='%s', country='%s', place='%s', privilage='%s' WHERE id = %s" % (sTableName, self.nick, self.name, self.surname, self.birthday, self.country, self.place, self.privilage, self.id))        
     
    def create(self):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("INSERT INTO %s (nick,name,surname, password, birthday,country,place,privilage) VALUES ('%s','%s','%s','%s', '%s','%s','%s','%s')" % (sTableName, self.nick, self.name, self.surname, self.passwd, self.birthday, self.country, self.place, self.privilage) )
                     
    def toString(self):
        return "%s || %s || %s || %s || %s || %s || %s || %s" % (self.nick, self.name, self.surname, self.passwd, self.birthday, self.country,self.place,self.privilage)
        
        
    
    #------------ Static Methods--------------------#
        
    def getIdByNick(nick):
        global sTableName
        id = None
        
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT id FROM %s WHERE nick='%s'" % (sTableName,nick))
        row = cursor.fetchone()
        id = row[0]
        
        return id    
    getIdByNick = staticmethod(getIdByNick)
    
    
    def getNickById(id):
        global sTableName
        nick = None
        
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT nick FROM %s WHERE id='%s'" % (sTableName,id))
        row = cursor.fetchone()
        nick = row[0]
        
        return nick    
    getNickById = staticmethod(getNickById)
    
    
    def getUserById(id):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT id FROM %s WHERE id = '%s'" % (sTableName,id) )
        row = cursor.fetchall()
        
        return row
    
    getUserById = staticmethod(getUserById)
    
    
    def getUserByNick(nick):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        
        if nick is not None:
            cursor.execute("SELECT id FROM %s WHERE nick = '%s'" % (sTableName,nick))
    
        rows = cursor.fetchall()
        return rows   
    
    getUserByNick = staticmethod(getUserByNick);
    
    
    def getUsersByNameAndSurname(name,surname):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        
        if name is not None and surname is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE CONCAT(name,surname) = '%s'" % (sTableName,name + surname))
        elif name is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE name = '%s'" % (sTableName,name))
        elif surname is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE surname = '%s'" % (sTableName,surname))
                   
        rows = cursor.fetchall()
        return rows   
    getUsersByNameAndSurname = staticmethod(getUsersByNameAndSurname)
    
    def getUsersByPlaceAndCountryAndBirthday(place,country, year):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        
        if place is not None and country is not None and year is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE CONCAT(place,country) = '%s' AND YEAR(birthday) = '%s'" % (sTableName,place + country, year))
        elif place is not  None and country is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE CONCAT(place,country) = '%s'" % (sTableName,place + country))    
        elif place is not None and year is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE place = '%s' AND YEAR(birthday) = '%s'" % (sTableName,place, year))
        elif country is not None and year is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE country = '%s' AND YEAR(birthday) = '%s'" % (sTableName,country, year))
        elif country is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE country = '%s'" % (sTableName,country))            
        elif place is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE place = '%s'" % (sTableName,place))      
        elif year is not None:
            cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE YEAR(birthday) = '%s'" % (sTableName,year))                  
        
        rows = cursor.fetchall()
        
        return rows    
    getUsersByPlaceAndCountryAndBirthday = staticmethod(getUsersByPlaceAndCountryAndBirthday)
    
    
    def getUsersByAll(name,surname,year,birthday,country,place):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT id,nick,name,surname,birthday,country,place FROM %s WHERE CONCAT(name,surname,year,birthday,country,place) = '%s'" % (sTableName, name + surname + year + birthday + country + place))
        rows = cursor.fetchall()
        
        return rows 
    getUsersByAll = staticmethod(getUsersByAll)
        
        
    def userExists(nick):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        logging.debug("Checking if user exists: %s" % (nick)) 
        cursor.execute("SELECT id FROM %s WHERE nick = '%s'" % (sTableName, nick))
        
        if cursor.rowcount == 0:
            return False
        
        return True
    
    userExists = staticmethod(userExists)
    

    def setNewPassword(id, password):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        encryptedPass = Encryption.PasswdEnc.encrypt(password)
        cursor.execute("UPDATE %s SET password='%s' WHERE id = %s" % (sTableName, encryptedPass, id))  
        
    setNewPassword = staticmethod(setNewPassword)      
     

    def validatePassword(nick, password):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT password,id FROM %s WHERE nick = '%s'" % (sTableName,nick))
        row = cursor.fetchone()
        
        if row is None:
            return (False,-1,nick)
        
        r_password = row[0]
        r_id = row[1]
        
        if r_password  == Encryption.PasswdEnc.encrypt(password): 
            dao.UserStatsDAO.addUserLoginData(r_id)
            
            return (True, r_id, nick)
        
        return (False, r_id, nick)       
    validatePassword = staticmethod(validatePassword)

