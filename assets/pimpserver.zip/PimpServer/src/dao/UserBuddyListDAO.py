from db import DBM
import UserAccountsDAO

sTableName = "UserBuddyList"

class UserBuddyListDAO:
    """Class providing access to user buddy list"""
    def __init__(self):
        """Empty constructor"""
        
    def getBuddyListForId(id):
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT nick,userid,buddyid FROM %s ua JOIN %s ubl  WHERE ubl.buddyid = ua.id AND userid = %s" % (UserAccountsDAO.sTableName, sTableName, id))
        rows = cursor.fetchall()
    
        return rows
    
    getBuddyListForId = staticmethod(getBuddyListForId)
    
    
    def isBuddyOnList(userId,buddyId):
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT buddyid FROM %s WHERE userId=%s AND buddyId=%s" % (sTableName, userId,buddyId))
        result = cursor.fetchone()
        
        if result is None:
            return False
        
        return True
        
    isBuddyOnList = staticmethod(isBuddyOnList)
    
    def addBuddyToId(userId,buddyId):      
        
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("INSERT INTO %s (userid,buddyid) VALUES ('%s','%s')" % (sTableName,userId,buddyId))

    addBuddyToId = staticmethod(addBuddyToId)
    
    
    def removeBuddyFromId(userId,buddyId):
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("DELETE FROM %s WHERE userId=%s AND buddyId=%s" % (sTableName,userId,buddyId))

    removeBuddyFromId = staticmethod(removeBuddyFromId)
    
    
    def getIdsOfUsersHavingIdAsBuddy(id):
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT userid FROM %s ua JOIN %s ubl  WHERE ubl.buddyid = ua.id AND buddyid = %s" % (UserAccountsDAO.sTableName, sTableName, id))
        rows = cursor.fetchall()
    
        return rows
    
    getIdsOfUsersHavingIdAsBuddy = staticmethod(getIdsOfUsersHavingIdAsBuddy)