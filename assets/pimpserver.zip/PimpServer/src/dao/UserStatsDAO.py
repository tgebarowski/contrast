from db import DBM

sTableName = "UserStats"

class UserStatsDAO:
    
    
    def addUserLoginData(userid):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("INSERT INTO %s(userid) VALUES(%s)" % (sTableName, userid))
                
    addUserLoginData = staticmethod(addUserLoginData)
    
    def getLastLoginData(userid):
        global sTableName
        cursor = DBM.DBC_Provider.getCursorHandler()
        cursor.execute("SELECT time FROM %s WHERE userid='%s' ORDER BY id DESC LIMIT 1" % (sTableName,userid))
        result = cursor.fetchone()
        
        return result
    getLastLoginData = staticmethod(getLastLoginData)
    