import MySQLdb

#TODO: Move MySQL configuration into an XML file

class DBC_Provider:
      
    __hConnection = None  
      
    def __init__(self):
        """Empty constructor"""
        
    def getInstance():
        if DBC_Provider.__hConnection is None:
            DBC_Provider.__hConnection = MySQLdb.connect(host = "localhost", user = "root", passwd = "root", db= "pimp_db", unix_socket="/Applications/MAMP/tmp/mysql/mysql.sock")
       
        return DBC_Provider.__hConnection
        
    getInstance = staticmethod(getInstance);
    
    
    def getCursorHandler():
        dbConnection = DBC_Provider.getInstance()
        cursor = dbConnection.cursor()
        return cursor
    getCursorHandler = staticmethod(getCursorHandler)  
