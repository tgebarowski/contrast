import SocketServer
from xml_layer import ServerRequestParser
from xml_layer import ServerMessagesXMLWrapper
import service_layer
import logging

class RequestHandler(SocketServer.StreamRequestHandler):

    clientId = None
    
    def handle(self):
        
        #User Authentication
        sr = ServerRequestParser(self.rfile.readline().strip(),self.clientId)
        
        msgType = sr.getMsgType()
        
        #Forbid operations that require authorization
        if msgType != "init" and msgType != "userAddRequest" and msgType != "undefined":
            logging.debug("Permission denied")
            self.wfile.write(ServerMessagesXMLWrapper.msgFailure(-1, -1, "Permission denied"))
            return None
        
        #User Authorization Handler
        elif msgType == "init":    
            #Handle Init or UserAddRequest
            xmlResult = sr.handle()
            
            #Analyse Init Response Message
            resTuple = ServerRequestParser.initAuthResult(xmlResult)
            
            logging.debug("Response: %s" % (xmlResult))
            self.wfile.write(xmlResult)
            self.clientId = resTuple[1] 
            accessGranted = resTuple[0]
        
            logging.debug("Client connected id: %s" % ( self.clientId ) )
         
            if  accessGranted is True:
                service_layer.PIMP_Server.addClient(self.clientId,self.wfile)
                service_layer.PIMP_Server.notifyAllBuddiesStatusChanged(self.clientId,"Available","")
                while self.__handleSingleClient():
                    None
                    
        #Create Account Handler
        elif msgType == "userAddRequest":
            xmlResult = sr.handle()
            logging.debug("Sending response: %s" % (xmlResult))
            self.wfile.write(xmlResult)
            self.wfile.close();
            self.rfile.close();
            
            return None
                
                
                
    def __handleSingleClient(self):
        
        try:
            #Parse All Incoming Messages
            sr = ServerRequestParser(self.rfile.readline().strip(), self.clientId)
            xmlResult = sr.handle()
            logging.debug("Sent response: %s" % (xmlResult))
            self.wfile.write(xmlResult)
            return True
        except:
            logging.debug("Client disconnected: %s"  % ( self.clientId ))
            service_layer.PIMP_Server.removeClient(unicode(self.clientId))   
            service_layer.PIMP_Server.notifyAllBuddiesStatusChanged(self.clientId,"Unavailable","")
            return False
                 
            
            
        
        
        

    