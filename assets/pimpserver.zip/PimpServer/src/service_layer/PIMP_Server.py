import SocketServer
import socket
from service_layer import RequestHandler
from service_layer import PIMP_Pinger
from PIMP_Pinger import PIMP_Pinger
from dao import UserBuddyListDAO
from xml_layer import ServerMessagesXMLWrapper
import logging


logging.basicConfig(level=logging.DEBUG)
conClientsMap = {}

class PIMP_Server:
    
    hostname = None
    port = None
    
    def __init__(self, hostname, port):
        self.hostname = hostname
        self.port = port
        
        server = SocketServer.ThreadingTCPServer((self.hostname, self.port), RequestHandler)
        
        
        pinger = PIMP_Pinger()
        pinger.start()
        print "Server is running on %s at port %s" % (hostname,port)
        server.serve_forever()
        

    def addClient(id, socket):
        conClientsMap[id] = socket    
               
    addClient = staticmethod(addClient)
    
    
    def removeClient(id):
        if id in conClientsMap.keys():
            conClientsMap.pop(id)
            logging.debug("Client ID: %s removed" % (id))
    
        
    removeClient = staticmethod(removeClient)
    
    
    def disconnectClient(id):
        socket = PIMP_Server.getClientSocket(id);
        socket.close()
        
        PIMP_Server.removeClient(id)
        
    disconnectClient = staticmethod(disconnectClient)
    
    def getClientSocket(id):
        if id in conClientsMap.keys():
            return conClientsMap[id]
        else:
            return None
    
    getClientSocket = staticmethod(getClientSocket)
    
    
    def getClientsMap():
        global conClientsMap
        return conClientsMap
    
    getClientsMap = staticmethod(getClientsMap)
    
    
    def isClientAvailable(clientId):
        map = PIMP_Server.getClientsMap()
        
        logging.debug("Checking if client %s is available in %s" % (clientId,map.keys()))
        if clientId in map.keys():
            return True
        else:
            return False
        
    isClientAvailable = staticmethod(isClientAvailable)
        
    def notifyAllBuddiesStatusChanged(userId,status,content):
        
        results = UserBuddyListDAO.getIdsOfUsersHavingIdAsBuddy(userId)
        
        for row in results:
            buddyId = unicode(row[0])
            logging.debug("Examining a buddy %s" % (buddyId))
            if PIMP_Server.isClientAvailable(buddyId):                 
                logging.debug("Notifying buddy: %s"  % (buddyId))
                socket = PIMP_Server.getClientSocket(buddyId)
                socket.write(ServerMessagesXMLWrapper.msgUserStatus(buddyId, userId, status,content))
                    
    notifyAllBuddiesStatusChanged = staticmethod(notifyAllBuddiesStatusChanged)   
    
if __name__ == '__main__':
 
    try:
        serverInstance = PIMP_Server("localhost", 5054)
    except socket.error:
        logging.fatal("Server startup failed: Cannot bind address")
    except:
        logging.fatal("Server startup failed due to unknown reason")
