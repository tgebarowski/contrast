from threading import Timer
from threading import Thread
from xml_layer import ServerMessagesXMLWrapper
import service_layer
import time
import logging

class PIMP_Pinger(Thread):

    pingFrequecy = 120.0;
    timer = None

    def __init__(self):
        Thread.__init__(self)
        
    def run(self):
        
        try:
            self.timer = Timer(self.pingFrequecy, self.pingAllClients)
            self.timer.run()
        except:
            logging.warning("Exception in run method PIMP_Pinger class") 
            
        
    def pingAllClients(self):
        clientsMap = service_layer.PIMP_Server.getClientsMap()
        
        try:
            for clientId in clientsMap.keys():
                logging.debug("Ping client: %s" %  (clientId))
                xmlPingMessage = ServerMessagesXMLWrapper.msgPing(clientId, int(time.time()))
                clientsMap[clientId].write(xmlPingMessage)
                
        except:
                logging.warning("Exception in pingAllClients Method: Cannot ping a client: %s" % (clientId))  
                service_layer.PIMP_Server.removeClient(clientId)  
                
                
        self.timer.run()