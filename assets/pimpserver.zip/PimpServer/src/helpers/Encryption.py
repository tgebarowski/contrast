import random
import crypt
import string

class PasswdEnc:
    """Helper class used for encryption purposes"""
    
    def __getsalt(chars = string.letters + string.digits):
        """generate a random 2-character 'salt'"""
        return chars
    
    __getsalt = staticmethod(__getsalt)
    
    def encrypt(password):
        """Performs password encryption"""
        return crypt.crypt(password, PasswdEnc.__getsalt() )
    
    encrypt = staticmethod(encrypt)