from xml.dom.minidom import parse
from xml.dom.minidom import getDOMImplementation
import xml.dom.minidom


class ServerMessagesXMLWrapper:
    
    def __init__(self):
        """Empty Constructor"""
        
    def authorizationAckMsg(tuple):
        impl = getDOMImplementation()
        newMessage = impl.createDocument(None, "message", None)
        top_element = newMessage.documentElement


        if tuple[0] is True:
            statusStr = "ok"
        else: 
            statusStr = "failure"
            
        if tuple[2] == "already_logged":
            statusStr = "already_logged"
            
        authValue = newMessage.createTextNode(statusStr)
        top_element.setAttribute("seq_num", "9")
        top_element.setAttribute("rcpt_id", "%s" % (tuple[1]))
        top_element.setAttribute("type", "authorization")
        top_element.appendChild(authValue)

        return newMessage.toxml() + '\n'
    authorizationAckMsg = staticmethod(authorizationAckMsg)
    
    
    def msgAck(rcptId, seqNum):
        impl = getDOMImplementation()
        newMessage = impl.createDocument(None, "message", None)
        top_element = newMessage.documentElement
        
        top_element.setAttribute("seq_num", "%s" % (seqNum))
        top_element.setAttribute("rcpt_id", "%s" % (rcptId))
        top_element.setAttribute("type", "ack")
        
        return newMessage.toxml() + '\n'
    
    msgAck = staticmethod(msgAck)
    
    
    def msgFailure(rcptId, seqNum, content):
        impl = getDOMImplementation()
        newMessage = impl.createDocument(None, "message", None)
        top_element = newMessage.documentElement
        
        top_element.setAttribute("seq_num", "%s" % (seqNum))
        top_element.setAttribute("rcpt_id", "%s" % (rcptId))
        top_element.setAttribute("type", "failure")
        
        contentMsg = newMessage.createTextNode(content)
        top_element.appendChild(contentMsg)
        
        return newMessage.toxml() + '\n'
    
    msgFailure = staticmethod(msgFailure)


    def msgPing(rcptId,seqNum):
        impl = getDOMImplementation()
        newMessage = impl.createDocument(None, "message", None)
        top_element = newMessage.documentElement
        
        top_element.setAttribute("seq_num", "%s" % (seqNum))
        top_element.setAttribute("rcpt_id", "%s" % (rcptId))
        top_element.setAttribute("type", "ping")
        
        return newMessage.toxml() + '\n'
    
    msgPing = staticmethod(msgPing)    
    
    
    def msgUserStatus(rcptId, userId, status, content):
        impl = getDOMImplementation()
        newMessage = impl.createDocument(None, "message", None)
        top_element = newMessage.documentElement

        top_element.setAttribute("rcpt_id", "%s" % (rcptId))
        top_element.setAttribute("type", "userStatusChanged")
        
        userTag = newMessage.createElement("user")
        
        idTag = newMessage.createElement("id")
        idValue = newMessage.createTextNode("%s" % (userId))
        idTag.appendChild(idValue)
        
        statusTag = newMessage.createElement("status")
        statusValue = newMessage.createTextNode(status)
        statusTag.appendChild(statusValue)
        
        if ( content != ""):
            contentTag = newMessage.createElement("content")
            contentValue = newMessage.createTextNode("%s" % (content) )
            contentTag.appendChild(contentValue)
            userTag.appendChild(contentTag)
            
        userTag.appendChild(idTag)    
        userTag.appendChild(statusTag)    
        
        top_element.appendChild(userTag)
            
        return newMessage.toxml() + '\n'
        
        
    msgUserStatus = staticmethod(msgUserStatus)
    