from xml.dom.minidom import parseString
import service_layer
import logging
from xml_layer import ServerMessagesXMLWrapper
from xml_layer import UserBuddyListXMLWrapper
from xml_layer import UserAccountXMLWrapper
from dao import UserAccountsDAO
from dao import UserBuddyListDAO



class ServerRequestParser:
    
    
    currentClientId = None #Stores ID of client for which this handling routine is executed
    xmlMessageStr = None
    msgType = None
    msgTag = None
    
    def __init__(self, xmlMessageStr, currentClientId):      
        self.xmlMessageStr = xmlMessageStr
        self.currentClientId = currentClientId


    def getMsgType(self):
        
        try:
            xmlMessage = parseString(self.xmlMessageStr)
            logging.debug("Processing XML message: %s" % (self.xmlMessageStr))
            self.msgTag = xmlMessage.getElementsByTagName("message")[0]
            self.msgType = self.msgTag.getAttribute("type")
            return self.msgType
        except:
            return "undefined"
            
        

        
    def handle(self):
        
        try:
            self.getMsgType()
            
            if self.msgType == "init":        
                return self.initRequestHandler()
            elif self.msgType == "chat":
                return self.chatMessageHandler()
                
            elif self.msgType == "buddyListRequest":
                return self.buddyListRequestHandler()
                
            elif self.msgType == "userLookUpRequest":
                return self.userLookUpRequestHandler()
            
            elif self.msgType == "userAddRequest":
                return self.userAddRequestHandler()
            
            elif self.msgType == "userModifyRequest":
                return self.userModifyRequestHandler()
            
            elif self.msgType == "userChangePasswordRequest":
                return self.userChangePasswordHandler()
            
            elif self.msgType == "userStatusChangedRequest":
                return self.userStatusChangedRequestHandler()
            elif self.msgType == "buddyListOpRequest":
                return self.buddyListOpRequestHandler()
            elif self.msgType == "myAccountRequest":
                return self.myAccountRequestHandler()
            
            else:
                print "Unrecognized command: %s " % (self.xmlMessageStr)
                return ServerMessagesXMLWrapper.msgFailure(-1,-1, "Unrecognized server message") 
        except:
            print "Unrecognized command: %s " % (self.xmlMessageStr)
            return ServerMessagesXMLWrapper.msgFailure(-1,-1, "Unrecognized server message")
        
            
    def initRequestHandler(self):
        """Parse XML init request"""
        username = self.msgTag.getElementsByTagName("user")[0].childNodes[0].data
        password = self.msgTag.getElementsByTagName("password")[0].childNodes[0].data 
        
        userPassTuple = UserAccountsDAO.validatePassword(username,password)
        
        if service_layer.PIMP_Server.isClientAvailable(unicode(userPassTuple[1])) is False:
            return ServerMessagesXMLWrapper.authorizationAckMsg(userPassTuple)
        
        return ServerMessagesXMLWrapper.authorizationAckMsg((False, userPassTuple[1], "already_logged"))
        
        
    def chatMessageHandler(self):

        outputMsgs = ""

        seq_num = self.msgTag.getAttribute("seq_num")

        rcptTagList = self.msgTag.getElementsByTagName("rcpt")

        #Deliver message to all recipients
        for rcpt in rcptTagList:
            rcpt_id = rcpt.getAttribute("id")

            socket = service_layer.PIMP_Server.getClientSocket(rcpt_id)
            
            if socket is None:
                outputMsgs = outputMsgs + ServerMessagesXMLWrapper.msgFailure(rcpt_id,seq_num, "Message could not be delivered. User is offline!")
            else:
                socket.write(self.xmlMessageStr + '\n')
                logging.debug("Transmiting message to user %s" % (rcpt_id))
                outputMsgs = ServerMessagesXMLWrapper.msgAck(rcpt_id,seq_num)
            #Transmit message for specified socket
            
        return outputMsgs
        
    def buddyListRequestHandler(self):
        seq_num = int(self.msgTag.getAttribute("seq_num"))
        
        buddyRows = UserBuddyListDAO.getBuddyListForId(self.currentClientId)
        xmlWrapper = UserBuddyListXMLWrapper(buddyRows,seq_num)
        return xmlWrapper.getXMLModel()
    
    
    def myAccountRequestHandler(self):
        seq_num = int(self.msgTag.getAttribute("seq_num"))
        rcpt_id = int(self.msgTag.getAttribute("rcpt_id"))
        
        userAccount = UserAccountsDAO(self.currentClientId);
        xmlWrapper = UserAccountXMLWrapper(userAccount,rcpt_id,seq_num)
        return xmlWrapper.getXMLModel();

    
    def buddyListOpRequestHandler(self):
        
        logging.info("Parsing BuddyListOp Request")
        rcpt_id = self.msgTag.getAttribute("rcpt_id")
        seq_num = int(self.msgTag.getAttribute("seq_num"))  
        buddyTag = self.msgTag.getElementsByTagName("buddy")[0]
        
        buddyId = buddyTag.getAttribute("id")
        mode  = buddyTag.getAttribute("mode")
        
        try:
            
            #Check if not trying to assign yourself as a buddy
            if self.currentClientId == buddyId:
                return ServerMessagesXMLWrapper.msgFailure(rcpt_id,seq_num, "Cannot assign You as a buddy")

            if mode == "add":
                
                #Check if buddy is already on a list
                if UserBuddyListDAO.isBuddyOnList(self.currentClientId, buddyId):
                    return ServerMessagesXMLWrapper.msgFailure(rcpt_id,seq_num, "Buddy Already on a List")
                
                UserBuddyListDAO.addBuddyToId(self.currentClientId, buddyId)
            elif mode == "remove":
                UserBuddyListDAO.removeBuddyFromId(self.currentClientId, buddyId)         
            else:
                return ServerMessagesXMLWrapper.msgFailure(rcpt_id,seq_num, "Unknown Buddy Operation Mode")           
        except:
            return ServerMessagesXMLWrapper.msgFailure(rcpt_id,seq_num, "Operation failure")

        return ServerMessagesXMLWrapper.msgAck(rcpt_id,seq_num) 

    def userLookUpRequestHandler(self):
        
        logging.info("Parsing User LookUp Request")
        
        rcpt_id = self.msgTag.getAttribute("rcpt_id")
        seq_num = int(self.msgTag.getAttribute("seq_num"))  
        
        userTag = self.msgTag.getElementsByTagName("user")[0]
        
        userParamsMap = self.__userParametersParser(userTag)
        
        if userParamsMap["id"] is not None:
            rows = UserAccountsDAO.getUserById(userParamsMap["id"])
        elif userParamsMap["nick"] is not None:
            rows = UserAccountsDAO.getUserByNick(userParamsMap["nick"])
        elif userParamsMap["name"] is not None or userParamsMap["surname"] is not None:
            rows = UserAccountsDAO.getUsersByNameAndSurname(userParamsMap["name"], userParamsMap["surname"])
        elif userParamsMap["place"] is not None or userParamsMap["country"] is not None or  userParamsMap["year"] is not None :
            rows = UserAccountsDAO.getUsersByPlaceAndCountryAndBirthday( userParamsMap["place"],  userParamsMap["country"], userParamsMap["year"] )
    
        xmlResponse = ""
    
        for row in rows:
            userAcc = UserAccountsDAO(row[0])
            userAcc.setPrivilage(None)
            xmlUserWrapper = UserAccountXMLWrapper(userAcc,rcpt_id,seq_num)
            xmlResponse = xmlResponse + xmlUserWrapper.getXMLModel();
            
        return xmlResponse;
            
            
    def userAddRequestHandler(self):
     
        userTag = self.msgTag.getElementsByTagName("user")[0]
        userParamsMap = self.__userParametersParser(userTag)
            
        if self.__userParametersValidate(userParamsMap) is True:
            newUser = UserAccountsDAO(None)
            newUser.setNick(userParamsMap["nick"])
            newUser.setName(userParamsMap["name"])
            newUser.setSurname(userParamsMap["surname"])
            newUser.setPasswd(userParamsMap["password"])
            newUser.setPrivilage("user")
            newUser.setLocation(userParamsMap["place"],userParamsMap["country"])
            newUser.setBirthday(userParamsMap["birthday"])

            if UserAccountsDAO.userExists(newUser.nick):
                logging.debug("User already exists");
                return ServerMessagesXMLWrapper.msgFailure(-1,-1, "User already exists")  
            
            try:
                newUser.create()
            except:
                logging.debug("Internal Server Database Error")
                return ServerMessagesXMLWrapper.msgFailure(-1,-1, "Internal Server Database Error")
                
            logging.debug("User Account successfully created: %s" % (newUser.nick))
            return ServerMessagesXMLWrapper.msgAck(1,1) 
        else:
            logging.debug("User Account was NOT created! Not enough data provided")
            return ServerMessagesXMLWrapper.msgFailure(-1,-1, "Not enough data")
        
        
    def userModifyRequestHandler(self):
        
        userTag = self.msgTag.getElementsByTagName("user")[0]
        userParamsMap = self.__userParametersParser(userTag)

        thisUser = UserAccountsDAO(self.currentClientId)
        thisUser.setName(userParamsMap["name"])
        thisUser.setSurname(userParamsMap["surname"])
        thisUser.setLocation(userParamsMap["place"],userParamsMap["country"])
        thisUser.setBirthday(userParamsMap["birthday"])

        try:
            thisUser.update()
        except:
            logging.debug("Internal Server Database Error")
            return ServerMessagesXMLWrapper.msgFailure(-1,-1, "Internal Server Database Error")
                
        logging.debug("User Account successfully modified: %s" % (thisUser.nick))
        return ServerMessagesXMLWrapper.msgAck(1,1) 
            
            
    def userChangePasswordHandler(self):
        passwordTag = self.msgTag.getElementsByTagName("password")[0]
        oldTag = passwordTag.getElementsByTagName("old")[0]
        newTag = passwordTag.getElementsByTagName("new")[0]
        
        oldPassword = oldTag.childNodes[0].data
        newPassword = newTag.childNodes[0].data
        
        nick = UserAccountsDAO.getNickById(self.currentClientId)
        result = UserAccountsDAO.validatePassword(nick,oldPassword)
        
        if result[0] == False:
            logging.debug("Incorrect provided password")
            return ServerMessagesXMLWrapper.msgFailure(-1,-1, "Provided password is incorrect")
        
        UserAccountsDAO.setNewPassword(self.currentClientId,newPassword)
        logging.debug("Password successfuly changed for user: %s" % (nick))
        return ServerMessagesXMLWrapper.msgAck(1,1) 
            
    def userStatusChangedRequestHandler(self):
        
        status = None
        id = None
        content = ""
        
        rcpt_id = self.msgTag.getAttribute("rcpt_id") 
        
        userTag = self.msgTag.getElementsByTagName("user")[0]
        
        idTag = userTag.getElementsByTagName("id")
        
        if idTag:
            id = idTag[0].childNodes[0].data
            
        statusTag = userTag.getElementsByTagName("status")
        
        if statusTag:
            status = statusTag[0].childNodes[0].data
            
        contentTag = userTag.getElementsByTagName("content")
        
        if contentTag:
            content = contentTag[0].childNodes[0].data
            
        
        logging.debug("Status Changed Request: %s %s %s" % (id,status,content))    
            
        if status is not None and id is not None:
            service_layer.PIMP_Server.notifyAllBuddiesStatusChanged(id,status,content)
            
        if status == "Unavailable":
            service_layer.PIMP_Server.disconnectClient(id)
            return None;
 
        return ServerMessagesXMLWrapper.msgAck(rcpt_id,1)
    
    def __userParametersValidate(self,params):
        
        if params["name"] is None or params["surname"] is None or params["nick"] is None or params["birthday"] is None \
        or params["place"] is None or params["country"] is None:
            return False
        
        return True
                
            
    def __userParametersParser(self,userTag):
        
        idTag = userTag.getElementsByTagName("id")
        if idTag:
            id = idTag[0].childNodes[0].data
        else:
            id = None    
        
        nameTag = userTag.getElementsByTagName("name")
        if nameTag:
            name = nameTag[0].childNodes[0].data
        else:
            name = None
                
        surnameTag = userTag.getElementsByTagName("surname")
        if surnameTag:
            surname = surnameTag[0].childNodes[0].data
        else:
            surname = None
            
            
        passwordTag = userTag.getElementsByTagName("password")
        if passwordTag:
            password = passwordTag[0].childNodes[0].data
        else:
            password = None
            
            
        nickTag = userTag.getElementsByTagName("nick")
        if nickTag:
            nick = nickTag[0].childNodes[0].data
        else:
            nick = None
            
        yearTag = userTag.getElementsByTagName("year")
        if yearTag:
            year = yearTag[0].childNodes[0].data
        else:
            year = None
            
            
        birthdayTag = userTag.getElementsByTagName("birthday")
        if birthdayTag:
            birthday = birthdayTag[0].childNodes[0].data
        else:
            birthday = None
            
        placeTag = userTag.getElementsByTagName("place")
        if placeTag:
            place = placeTag[0].childNodes[0].data
        else:
            place = None
            
        countryTag = userTag.getElementsByTagName("country")
        if countryTag:
            country = countryTag[0].childNodes[0].data
        else:
            country = None                
        
        userParamsMap = {}
        userParamsMap["id"] = id
        userParamsMap["name"] = name
        userParamsMap["surname"] = surname
        userParamsMap["password"] = password
        userParamsMap["nick"] = nick
        userParamsMap["year"] = year
        userParamsMap["birthday"] = birthday
        userParamsMap["country"] = country
        userParamsMap["place"] = place
        
        return userParamsMap  
    
    
    def initAuthResult(xmlResult):
        xmlMessage = parseString(xmlResult)
        msgTag = xmlMessage.getElementsByTagName("message")[0]
        msgType = msgTag.getAttribute("type")

        rcpt_id = None

        if msgType != "authorization":
            return (False,-1)
        else:
            msgContent = msgTag.childNodes[0].data
            if msgContent == "ok":
                rcpt_id = msgTag.getAttribute("rcpt_id")
                return (True,rcpt_id)
            else:
                return (False,rcpt_id)
            
    initAuthResult = staticmethod(initAuthResult)
