from xml.dom.minidom import parse
from xml.dom.minidom import getDOMImplementation
import xml.dom.minidom

from dao import UserAccountsDAO

class UserAccountXMLWrapper:
    def __init__(self, userAccountsDAO, rcptId, seqNum):
        self.seqNum = seqNum
        self.rcptId = rcptId
        self.userAccountsDAO = userAccountsDAO
        
    def getXMLModel(self):
        impl = getDOMImplementation()
        newMessage = impl.createDocument(None, "message", None)
        top_element = newMessage.documentElement
       
        userTag = newMessage.createElement("user")
        
        idTag = newMessage.createElement("id")
        idValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.id))
        idTag.appendChild(idValue)
        
        nickTag= newMessage.createElement("nick")
        nickValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.nick))
        nickTag.appendChild(nickValue)
        
        nameTag = newMessage.createElement("name")
        nameValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.name))
        nameTag.appendChild(nameValue)
        
        surnameTag = newMessage.createElement("surname")
        surnameValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.surname))
        surnameTag.appendChild(surnameValue)
        
        birthdayTag = newMessage.createElement("birthday")
        birthdayValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.birthday))
        birthdayTag.appendChild(birthdayValue)
        
        placeTag = newMessage.createElement("place")
        placeValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.place))
        placeTag.appendChild(placeValue)
        
        countryTag = newMessage.createElement("country")
        countryValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.country))
        countryTag.appendChild(countryValue)
        
        
        if self.userAccountsDAO.privilage is not None:
            privilageTag = newMessage.createElement("privilage")
            privilageValue = newMessage.createTextNode("%s" % (self.userAccountsDAO.privilage))
            privilageTag.appendChild(privilageValue)
            userTag.appendChild(privilageTag)
        
        
        userTag.appendChild(idTag)
        userTag.appendChild(nickTag)
        userTag.appendChild(nameTag)
        userTag.appendChild(surnameTag)
        userTag.appendChild(birthdayTag)
        userTag.appendChild(placeTag)
        userTag.appendChild(countryTag)
        
        top_element.appendChild(userTag)
        
        top_element.setAttribute("seq_num", "%s" % (self.seqNum))
        top_element.setAttribute("rcpt_id", "%s" % (self.rcptId))
        
        if self.userAccountsDAO.privilage is None:
            top_element.setAttribute("type", "userinfo")
        else:
            top_element.setAttribute("type", "userAccount")
        
        return newMessage.toxml() + '\n'