from xml.dom.minidom import getDOMImplementation
import service_layer

class UserBuddyListXMLWrapper:
    def __init__(self, buddyList, seqNum):
        self.buddyList = buddyList
        self.seqNum = seqNum
        
    def getXMLModel(self):
        impl = getDOMImplementation()
        newMessage = impl.createDocument(None, "message", None)
        top_element = newMessage.documentElement
       
        buddyListTag = newMessage.createElement("buddyList")
        
        for buddy in self.buddyList:
            buddyTag = newMessage.createElement("buddy")
            buddyId = buddy[2]
            
            available = service_layer.PIMP_Server.isClientAvailable(unicode(buddyId))
            
            if available is True:
                availableStr = "Available"
            else:
                availableStr = "Unavailable"

            buddyTag.setAttribute("status", "%s" % ( availableStr ))
            
            buddyTag.setAttribute("id", "%s" % (buddyId))
            buddyContent = newMessage.createTextNode(buddy[0])
            buddyTag.appendChild(buddyContent)
            buddyListTag.appendChild(buddyTag)
        
        top_element.setAttribute("type", "buddyList")
        top_element.setAttribute("rcpt_id", "%s" % (buddy[1]))
        top_element.setAttribute("seq_num", "%s" % (self.seqNum))
        top_element.appendChild(buddyListTag)

        return newMessage.toxml() + '\n'
    