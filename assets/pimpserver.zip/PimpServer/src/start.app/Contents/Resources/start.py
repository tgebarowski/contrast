#Author: Tomasz Gebarowski

#!/opt/local/bin/python2.5
import socket
import logging
from service_layer import PIMP_Server

if __name__ == '__main__':
 
    try:
        serverInstance = PIMP_Server("localhost", 5054)
    except socket.error:
        logging.fatal("Server startup failed: Cannot bind address")
    except:
        logging.fatal("Server startup failed due to unknown reason")