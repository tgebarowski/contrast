/*
 * Main.java
 *
 * Created on 5 May 2007, 15:21
 *
 */

package neuralnetworksapp;
import nn.*;
import gui.*;

/**
 * Neural Netoworks Simulator 
 * @author  Tomasz Gebarowski
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GatesGUI().setVisible(true);
            }
        });

        
    }
    
}
