/*
 * Rule.java
 * $Id: Rule.java 30 2007-01-24 23:46:26Z Thomasz $
 */

package KnowledgeBase;

import java.util.Vector;

/**
 * This class describes the Rules used in the KnowledgeBase
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class Rule {
    private String name;
    private Expression permisse;
    private SimpleExpression conclusion;
    
    /**
     * Creates a new instance of Rule
     * @param name The name of the rule
     */
    public Rule(String name) {
        this.name = name;
    }
    
    public void addPremisse(Expression p) {
        this.permisse = p;
    }
    
    public void addConclusion(SimpleExpression c) {
        this.conclusion = c;
    }
     
    /**
     * This function returns the name of the rule
     * @return The name of the object
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * This function returns the permisse of this object
     * @return permesse of this object
     */
    public Expression getPermisse()
    {
        return this.permisse;
    }
    
    /**
     * This function returns the conclusion of this object
     * @return The conclusion
     */
    public SimpleExpression getConclusion() {
        return this.conclusion;
    }
    
    public String toString() {
        return name + "\n " + " Permisse: " + this.permisse + "\n  Conclusion: " + this.conclusion;
    }
}
