/**
 * KnowledgeBase.java
 * $Id: KnowledgeBase.java 38 2007-01-31 19:18:26Z Thomasz $
 */

package KnowledgeBase;

import java.util.Vector;

/**
 * This class is the KnowledgeBase itself
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class KnowledgeBase {
    private Vector<Universe> universeList = new Vector();
    private Vector<Variable> variableList = new Vector();
    private Vector<Rule> ruleList = new Vector();
    
    /**
     * Creates a new instance
     */
    public KnowledgeBase() {
    }
    
    /**
     * Add another universe onto this knowledgebase
     * @param u Universe Universe to add
     */
    public void addUniverse(Universe u) {
        this.universeList.add(u);
    }
    
    /**
     * Add another variable to this knowledgebase
     * @param v Variable Variable to add
     */
    public void addVariable(Variable v) {
        this.variableList.add(v);
    }
    
    /**
     * Add another rule to this knowledgebase
     * @param r Rule Rule to add
     */
    public void addRule(Rule r) {
        this.ruleList.add(r);
    }
    
    /**
     * Get one of the added universes by its name
     * @param name String Name of the universe to return
     * @throws KnowledgeBase.UniverseNotFoundException Throws when no universe is found
     * @return Universe The universe with the requested name
     */
    public Universe getUniverseByName(String name) throws UniverseNotFoundException {
        for (int i = 0; i < this.universeList.size(); i++)
        {
            if (this.universeList.get(i).getName().trim().equals(name))
                return this.universeList.get(i);
        }
        
        throw new UniverseNotFoundException("Universe with name '" + name + "' not found.");
    }
    
    /**
     * Get one of the added universes by its name
     * @param name String Name of the variable to return
     * @return Variable The variable with the requested name
     * @throws KnowledgeBase.VariableNotFoundException Throws when no variable is found
     */
    public Variable getVariableByName(String name) throws VariableNotFoundException {
        for (int i = 0; i < this.variableList.size(); i++)
        {
            if (this.variableList.get(i).getName().equals(name))
                return this.variableList.get(i);
        }
        
        throw new VariableNotFoundException("Variable with name '" + name + "' not found.");
    }
    
    public Set getSetByVariableName(String varName, String setName) throws Exception {
        Variable var = getVariableByName(varName);
        Universe u = getUniverseByName( var.getUniverseName() );
        
        return u.getSetByName(setName);
    }
    
    /**
     * Get one of the added universes by its name
     * @param name String Name of the rule to return
     * @return Rule The rule with the requested name
     * @throws KnowledgeBase.RuleNotFoundException Throws when no rule is found
     */
    public Rule getRuleByName(String name) throws RuleNotFoundException {
        for (int i = 0; i < this.ruleList.size(); i++)
        {
            if (this.ruleList.get(i).getName().equals(name))
                return this.ruleList.get(i);
        }
        
        throw new RuleNotFoundException("Rule with name '" + name + "' not found.");
    }
    
    
   /**
    * Get all Rules
    * @return Vector<Rule> List of all rules
    */  
    public Vector<Rule> getRules() {
        return this.ruleList;
    }
    
    
  /**
    * Get all variables
    * @return Vector<Variable> List of all variables
    */  
    public Vector<Variable> getVariables() {
        return this.variableList;
    }
    
    public String toString() {
        StringBuffer str = new StringBuffer();
        
        for (int i = 0; i < this.universeList.size(); i++)
        {
            str.append("Universe: " + this.universeList.get(i) + "*\n");
        }
        
        for (int i = 0; i < this.variableList.size(); i++)
        {
            str.append("Variable: " + this.variableList.get(i) + "\n");
        }
        
        for (int i = 0; i < this.ruleList.size(); i++)
        {
            str.append("Rule: " + this.ruleList.get(i) + "\n");
        }
        
        return str.toString();
    }
    
    
    public class UniverseNotFoundException extends Exception
    {
        public UniverseNotFoundException(String err)
        {
            super(err);
        }
    }

    public class VariableNotFoundException extends Exception
    {
        public VariableNotFoundException(String err)
        {
            super(err);
        }
    }

    public class RuleNotFoundException extends Exception
    {
        public RuleNotFoundException(String err)
        {
            super(err);
        }
    }
}

