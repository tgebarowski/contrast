/**
 * Expression.java
 * $Id: Expression.java 49 2007-02-05 14:10:13Z Thomasz $
 */

package KnowledgeBase;

import java.util.Vector;

/**
 * Class describes a expression
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class Expression {
    private Vector<Term> termList = new Vector();
    private boolean not;
    
    /**
     * Creates a new instance
     */
    public Expression() {
    }
    
    /**
     * Add another term into the expression
     * @param t Term The term to add
     */
    public void addTerm(Term t) {
        this.termList.add(t);
    }
    
    /**
     * Get the list of all terms in this expression
     * @return Vector<Term> List of all terms
     */
    public Vector<Term> getTermList()
    {
        return this.termList;
    }
    
    
  /**
    * Set not attribute associated with a factor
    * @param not boolean Value of not attribute
    */     
    public void setNot(boolean not) {
        this.not = not;
    }
    
  /**
    * Get logical value of NOT attribute
    * @return boolean Logical value of not attribute
    */     
    public boolean isNot() {
        return this.not;
    }
    
    
    public String toString() {
        
        String str = new String();
       
        
        int size = termList.size();
       
        if ( isNot() )
            str = str.concat(" NOT ( ");
        
        if ( size > 0 )
        {
            int i = 0;
        
            for (i = 0; i < size - 1; i++)
            { 
                str = str.concat( this.termList.elementAt(i).toString() + " OR ");
            }
            str = str.concat(  this.termList.elementAt(i).toString() );
            
        }
        
        if ( isNot() )
            str = str.concat(" ) ");
        
        return str;
    }
}
