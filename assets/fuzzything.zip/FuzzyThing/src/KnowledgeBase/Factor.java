/*
 * Factor.java
 * $Id: Factor.java 49 2007-02-05 14:10:13Z Thomasz $
 */

package KnowledgeBase;

/**
 * This class describes a factor inside the KnowlegdeBase
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class Factor {
    private SimpleExpression simpleExpression;
    private Factor factor;
    private Expression expression;
    private boolean not;
    
    public Factor() {
    }
    
    /**
     * Creates a new instance of Factor
     * @param s The simpleExpression of this Factor
     */
    public void addSimpleExpression(SimpleExpression s) {
        this.simpleExpression = s;
    }
    
    /**
     * Set not attribute associated with a factor
     * @param not boolean Value of not attribute
     */     
    public void setNot(boolean not) {
        this.not = not;
    }
    /**
     * Get logical value of NOT attribute
     * @return boolean Logical value of not attribute
     */     
    public boolean isNot() {
        return this.not;
    }
    
    
    /**
     * Creates a new instance of Factor
     * @param f A instance of a factor
     */
    public void addFactor(Factor f)
    {
        this.factor = f;
    }
    
    /**
     * Creates a new instance of Factor
     * @param e A instance of an expression
     */
    public void addExpression(Expression e)
    {
        this.expression = e;
    }
    
    /**
     * This function get the simpleExpression stored inside the object
     * @return The simpleExpression
     */
    public SimpleExpression getSimpleExpression()
    {
        return this.simpleExpression;
    }
    
    /**
     * This functon gets the factor of this object
     * @return The factor
     */
    public Factor getFactor()
    {
        return this.factor;
    }
    
    /**
     * This function gets the expression of this object
     * @return The expression
     */
    public Expression getExpression()
    {
        return this.expression;
    }
    
    /**
     * This function gets
     * @return The object thats filled
     * @throws KnowledgeBase.NoAtributeFilledException This exception is throwed when none of the three objects are set.
     */
    public Object getFilled() throws NoAtributeFilledException
    {
        if (this.simpleExpression == null)
            return this.simpleExpression;
        
        if (this.factor == null)
            return this.factor;
        
        if (this.expression == null)
            return this.expression;
        
        throw new NoAtributeFilledException("");
    }
    
    public String toString() {
        
        StringBuffer str = new StringBuffer();
        String notStr = new String("");

        if ( isNot()) {
            notStr = "NOT ";
       } 
            
        
        if ( this.factor != null ) {
                str.append(notStr);  
                str.append( this.factor.toString() );
                
        }
        
        if ( this.expression != null ) {
            str.append(notStr);
            str.append( this.expression.toString());
        }
        
        if ( this.simpleExpression != null) {
            str.append(notStr);
            str.append( this.simpleExpression.toString());
        }

        return str.toString();
    }
    
    
    
}

class NoAtributeFilledException extends Exception
{
    public NoAtributeFilledException(String err)
    {
        super(err);
    }
}
