/**
 * Variable.java
 * $Id: Variable.java 15 2007-01-11 11:32:09Z Mathijs $
 */

package KnowledgeBase;

/**
 * Descripbes a variable in the knowledgebase
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class Variable {
    /**
     * Possible types of a variable
     */
    public enum Type {IN, OUT}
    
    private String name;
    private String universeName;
    private Type type;
    
    /**
     * Creates a new instance
     * @param name String Name of the variable
     * @param universeName String Name of the connected universe
     * @param t Variable.Type Type of variable
     */
    public Variable(String name, String universeName, Variable.Type t) {
        this.name = name;
        this.universeName = universeName;
        this.type = t;
    }

    /**
     * Get the name of the variable
     * @return String Name of variable
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * Get the name of the connected universe
     * @return String Name of universe
     */
    public String getUniverseName() {
        return this.universeName;
    }
    
    /**
     * Get the type of this variable
     * @return Variable.Type Type of variable
     */
    public Variable.Type getType() {
        return this.type;
    }
    
    public String toString() {
        String type;
        if (this.type == this.type.IN)
            type = "in";
        else
            type = "out";
        
        return new StringBuffer(this.name + " in universe " + this.universeName + " of type " + type + "\n").toString();
    }
}
