/**
 * Term.java
 * $Id: Term.java 30 2007-01-24 23:46:26Z Thomasz $
 */

package KnowledgeBase;

import java.util.Vector;

/**
 * Describes a term in the knowledgebase
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class Term {
    private Vector<Factor> factorList = new Vector();
    
    /**
     * Creates a new instance
     */
    public Term() {
    }
    
    /**
     * Add more factors to this term
     * @param f Factor Factor to add
     */
    public void addFactor(Factor f) {
        this.factorList.add(f);
    }
    
    /**
     * Get the list of factors in this term
     * @return Vector<Factor> Vector with all factors
     */
    public Vector<Factor> getFactorList()
    {
        return this.factorList;
    }
    
    
    public String toString() {
        
        String str = new String();
        
        int size = factorList.size();
        if ( size > 0 )
        {
            int i = 0;
        
            for (i = 0; i < size - 1; i++)
            { 
                str = str.concat( " ( " + this.factorList.elementAt(i).toString() + " ) " + " AND ");
            } 
            str = str.concat( " ( " + this.factorList.elementAt(i).toString() + " ) " );
            
        }
        
        return str;
    }
}
