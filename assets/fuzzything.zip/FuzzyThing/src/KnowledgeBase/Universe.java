/*
 * Universe.java
 * $Id: Universe.java 29 2007-01-23 14:43:40Z Mathijs $
 */

package KnowledgeBase;

import java.util.Vector;

/**
 * This class describes the universe of the KnowledgeBase
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class Universe {
    private String name;
    private Vector<Set> setList = new Vector();;
    
    /**
     * Creates a new instance of Universe
     * @param name The name of the universe
     */
    public Universe(String name) {
        this.name = name;
    }
    
    /**
     * This function gets the name of the universe
     * @return The name of this universe
     */
    public String getName()
    {
        return this.name;
    }
    
    /**
     * This function gets the setlist by name
     * @param name The name of the setlist
     * @return The setlist
     * @throws KnowledgeBase.SetNotFoundException This exception gets throwed when the searched setlist is not found.
     */
    public Set getSetByName(String name) throws SetNotFoundException {
        for (int i = 0; i < this.setList.size(); i++)
        {
            if (this.setList.get(i).getName().equals(name))
                return this.setList.get(i);
        }
        
        throw new SetNotFoundException("Set with name '" + name + "' not found.");
    }
    
    /**
     * This function adds a setlist to the universe
     * @param s The setlist that will be added
     */
    public void addSet(Set s)
    {
        s.setUniverse(this);
        this.setList.add(s);
    }
    
    public String toString()
    {
        StringBuffer str = new StringBuffer();
        
        str.append(this.name + "\n");
        
        for (int i = 0; i < this.setList.size(); i++)
        {
            str.append(" Set: " + this.setList.get(i) + "\n");
        }
        
        return str.toString();
    }
    
    public Vector<Set> getSets()
    {
        return this.setList;
    }
}

class SetNotFoundException extends Exception
{
    public SetNotFoundException(String err)
    {
        super(err);
    }
}