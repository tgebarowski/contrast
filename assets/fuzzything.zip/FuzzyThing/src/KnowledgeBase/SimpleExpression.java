/*
 * SimpleExpression.java
 * $Id: SimpleExpression.java 34 2007-01-29 21:31:25Z Thomasz $
 */

package KnowledgeBase;

/**
 * This class is the definition of a SimpleExpression
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class SimpleExpression {
    private String variableName;
    private String setName;
    
    /**
     * Creates a new instance of SimpleExpression
     * @param variableName The name of the variable. If the expression is <I>height IS low</I>, then <I>height</I> is the variable name.
     * @param setName The name of the set which the SimpleExpression is pointing to. If the expression is <I>height IS low</I>, then <I>low</I> is the setname.
     */
    public SimpleExpression(String variableName, String setName) {
        this.variableName = variableName;
        this.setName = setName;
    }
    
    /**
     * This function gets the variableName of this object.
     * @return variableName The name of the variable that is described in the object.
     */
    public String getVariableName() {
        return this.variableName;
    }
    
    /**
     * This function returns the setName of this object
     * @return setName the setName of this object.
     */
   public String getSetName() {
        return this.setName;
   }
   
   public String toString()
   {
       String operator;
       return this.variableName + " IS " + this.setName;
   }
}