/**
 * Set.java
 * $Id: Set.java 39 2007-02-01 15:07:20Z Mathijs $
 */

package KnowledgeBase;

/**
 * Describes a set in the knowledgebase
 * @author Mathijs Kadijk
 * @author Rick Pastoor
 */
public class Set {
    private String name;
    private Double[] x;
    private Universe u;
    private double clipped;
    
    /**
     * Creates a new instance
     * @param name String Name of the set
     * @param x1 Double Value of first x
     * @param x2 Double Value of second x
     * @param x3 Double Value of third x
     * @param x4 Double Value of fourth x
     */
    public Set(String name, double x1, double x2, double x3, double x4) {
        this.name = name;
        
        this.x = new Double[4];
        this.x[0] = x1;
        this.x[1] = x2;
        this.x[2] = x3;
        this.x[3] = x4;
        this.clipped = 1.0;
    }
    
    /**
     * Creates a new instance
     * @param name String Name of the set
     * @param x1 Double Value of first x
     * @param x2 Double Value of second x
     * @param x3 Double Value of third x
     * @param x4 Double Value of fourth x
     * @param clipped Double Clipped value
     */
    public Set(String name, double x1, double x2, double x3, double x4, double clipped) {
        this(name, x1, x2, x3, x4);
        this.clipped = clipped;
    }
 
    
  /**
    * Set Universe 
    * @param u Universe Reference to the universe
    */      
    public void setUniverse(Universe u) {
        this.u = u;
    }

   /**
     * Get universe
     * @return Universe Universe to which the set belongs
     */  
    public Universe getUniverse() {
        return this.u;
    }
    
    /**
     * Get name of this set
     * @return String Name of set
     */
    public String getName() {
        return this.name;
    }
    
  /**
    * Get clip point value
    * @return double Clip point value
    */    
    public double getClippedValue() {
        return this.clipped;
    }
    
    
  /**
    * Set name of this set
    * @param name String Name of set
    */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Get value of one of the x's
     * @param i Integer Number of the x you want (1-4)
     * @return Double Value of the requested x
     */
    public double getX(int i) {
        return this.x[i - 1];
    }
    
    public String toString() {
        return new StringBuffer(this.name + "\n" + "  Values: " + x[0].toString() +
                " " + x[1].toString() + " " + x[2].toString() +
                " " + x[3].toString() + " clip point: " + clipped + "\n").toString();
    }
}
