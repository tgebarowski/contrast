/*
 * TopDownParser.java
 *
 * Created on 20 January 2007, 15:30
 *
 * Class responsible for parsing Rule premisse.
 * It uses Top-Down parsing method.
 *
 * @author Tomasz Gebarowski
 */

package KnowledgeBaseParser;

import KnowledgeBase.*;
import java.util.Vector;
import java.util.Stack;
import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.regex.*;


/** Class implementing Premisse parser
 *  It uses top down parser method
 */
public class TopDownPremisseParser extends Object {
        
        private String text;
        private Expression e;
        private int openBrackets;
        private Boolean matched;
        
        private final static boolean debugMode = false;
 
        
       /**
        * Constructor initializing basic data types used in class
        */
        public TopDownPremisseParser() {
            openBrackets = 0;
            e = new Expression();
            matched = false;
                   
        }
        
        
      /**
        *  Start parsing an expression
        *  @param text String String representation of expression
        *  @return Expression Reference to the first expression on a syntax-tree
        */
        public Expression parse(String text) throws ParseErrorException {
            
            if ( text.trim().length() > 0 ) {
                this.e = new Expression();
                evaluateExpression(text, this.e);
            } else {
                throw new ParseErrorException("Invalid Expression format");
            }
            
            return e;
        }
        
       /** Private method used to reduce Brackets in a given Expression.
        *  Removes brackets if and only if they are matched at 1st and last position of given string.
        *  @param text String String representation of expression
        */
        private String reduceBrackets(String text) {
            Stack<Integer>	stack = new Stack<Integer>();
            String tmp;
            text = text.trim();
            tmp = text;
                         
            // Remove boundry brackets
            if ( tmp.charAt(0) == '(' && tmp.charAt(tmp.length()-1 ) == ')' ) {
                tmp = tmp.substring(1, tmp.length()-1);
            }
            
            // Verify Bracket matching
            for(int i=0; i < tmp.length(); i++)
            {
		switch (tmp.charAt(i))
		{
			case '(':
				stack.push(new Integer(i));
				break;
			case ')': {
                                    try {
                                            int	openLocation = stack.pop();
                                            break;
                                    } catch (EmptyStackException e ) {
                                        return text;
                                    }
                                }
		}
            }
                     
            return tmp;
        }
        
       /** Separated expression for terms with respect to major ORs. 
        *  It omits ORs which are surrounded by brackets
        *  @param text String String representation of expression
        */
        private void separateMajorORs(String text, Vector<String> vctStr )
        {
            String rest = "";
            Boolean found = false;
            
            int len = text.length();

            for ( int i = 0; i < len ; i++)
            {
                if ( ( text.charAt(i) == 'O' && (i + 3) < len ) && openBrackets == 0  )
                {
                    if ( text.charAt(i+1) == 'R' &&  ( text.charAt(i+2) == ' ' || text.charAt(i+2) == '\t')  )
                    {
                        String separated = text.substring(0, i-1);
                        rest = text.substring(i+3, len);
                        
                        vctStr.addElement(separated.trim());
                        matched = true;
                        found = true;
                        break;
                    }
                    
                }
               
                else if ( text.charAt(i) == '(' ) {
                    openBrackets++;
                } else if ( text.charAt(i) == ')' ) {
                    openBrackets--;
                } 
            }
            
            if ( found )
                separateMajorORs(rest, vctStr); 
            else if  (matched )
                vctStr.addElement(text);
        }
        
        
       /** Separated term for factors with respect to major ANDs. 
        *  It omits ANDs which are surrounded by brackets
        *  @param text String String representation of expression
        */
        private void separateMajorANDs(String text, Vector<String> vctStr)
        {
            String rest = "";
            Boolean found = false;
      
            int len = text.length();
            
            for ( int i = 0; i < len ; i++)
            {
                if ( ( text.charAt(i) == 'A' && (i + 4) < len ) && openBrackets == 0  )
                {
                    if ( text.charAt(i+1) == 'N' && text.charAt(i+2) == 'D' && ( text.charAt(i+3) == ' ' || text.charAt(i+3) == '\t')  )
                    {
                        String separated = text.substring(0, i-1);
                        rest = text.substring(i+4, len);
                        vctStr.addElement(separated.trim());
                        found = true; matched = true; break;
                        
                    }           
                }
                
                else if ( text.charAt(i) == '(' )
                    openBrackets++;
                else if ( text.charAt(i) == ')' )
                    openBrackets--;

            }
            
            if ( found )
                separateMajorANDs(rest, vctStr);
            else if ( matched ) {
                vctStr.addElement(text);
            }
        }
        
       
       /**
        *  Evaluate Expression
        *  @param text String String representation of expression
        */
        private void evaluateExpression(String text, Expression parent)  throws ParseErrorException 
        {
            if ( parent == null)
                parent = new Expression();
                
            matched = false;
            text = reduceBrackets(text);
            
            Vector<String> vctStr = new Vector();
            separateMajorORs(text, vctStr);
                     
            
            if ( vctStr.size() > 1 )
            { 
                for ( int i = 0; i < vctStr.size(); i++) {      
                    evaluateTerm(vctStr.elementAt(i), parent );
                }
            } else if ( isFactor(text) ) {
                
                evaluateTerm(text, parent);

            } else {
                if ( debugMode )
                    System.out.println(text + " is a simple expression 2");
                
                Term t = new Term();
                Factor f = new Factor();
                f.addSimpleExpression(createSimpleExpression(text));
                t.addFactor(f);
                e.addTerm(t);
            }           
            
            
        }
        
       /**
        * Evaluate Term
        * @param text String String representation of term
        */
        private void evaluateTerm(String text, Expression e)  throws ParseErrorException  {
            if ( debugMode )
                System.out.println("TERM:" + text);
            
            Term t = new Term();
            e.addTerm(t);
            
            matched = false;
            text = reduceBrackets(text);
   
            Vector<String> vctStr = new Vector();            
            separateMajorANDs(text, vctStr);
            matched = false;
            
            
            boolean negated = isNegated(text);
            
            if ( negated ) {
                 text = removeNot(text);
                 e.setNot(true);
            }
            

            if ( vctStr.size() > 1 )
            {
                for ( int i = 0; i < vctStr.size(); i++) {
                    String tmp =  vctStr.elementAt(i);
                    evaluateFactor(tmp, t );                    
                }
            } else if ( isExpression(text) ) {
                 Factor f = new Factor();
                 Expression exp = new Expression();
                 
                 evaluateExpression(text, exp);      
                 f.addExpression(exp);
                 t.addFactor(f);

            } else if ( isSimpleExpression(text) ) {
                if ( debugMode )
                    System.out.println(text + " is a simple expression 1 ");
                
                Factor f = new Factor();
                f.addSimpleExpression(createSimpleExpression(text));
                t.addFactor(f);
            } 
            
        }
        
      /**
        *  Check if a given Factor is really negated
        *  @param text String String representation of  factor
        *  @return boolean Return true if a factor is negated
        */       
        private boolean isNegated(String text ) {  
            Pattern p = Pattern.compile("[ \t]*NOT.+");
            Matcher m = p.matcher(text);

            if ( m.lookingAt() )
                return true;
            
            return false;
            
        }
      
      /**
        *  Remove "NOT" string from the input text
        *  @param text String String representation of negated factor
        *  @return String Modified string without "NOT" prefix
        */      
        private String removeNot(String text) throws ParseErrorException {
            Pattern p = Pattern.compile(".*NOT(.+)");
            Matcher m = p.matcher(text);
            
            if ( !m.lookingAt() )
                 throw new ParseErrorException("Inappropriate syntax of NOT operator");
                   
            String outStr = m.group(1).trim();
            outStr = reduceBrackets(outStr);

            return outStr;
        }
        
       /**
        *  Evaluate Factor
        *  @param text String String representation of factor
        */   
        private void evaluateFactor(String text, Term t) throws ParseErrorException  {
            
             if ( debugMode )
                System.out.println("FACTOR: " + text);  
             
             boolean negated = isNegated(text);
             
             Factor f = new Factor();
             
             if ( negated ) {
                 text = removeNot(text);
                 f.setNot(true);
                 
             }
             text = text.trim();
             
             if ( isExpression(text) ) {
                 Expression exp = new Expression();
                 evaluateExpression(text, exp);       
                 f.addExpression(exp);
                 
                 t.addFactor(f);
             } else if ( isSimpleExpression(text) ) { 
                 if ( debugMode )
                    System.out.println(text + " Simple expression 3");
                 
                 f.addSimpleExpression(createSimpleExpression(text));
                 t.addFactor(f);
             }
        }
        
       /**
        *  Check if a given string is still an expression
        *  @param text String String representation of expression
        *  @return boolean True if given string is expressiong
        */   
        private boolean isExpression(String text) {
            
            Pattern p = Pattern.compile("(.*)OR(.*)");
            Matcher m = p.matcher(text);

            if ( m.lookingAt() )
                return true;
            
            return false;
        }
        
         /**
        *  Check if a given string is still a factor
        *  @param text String String representation of factor
        *  @return boolean True if given string is factor
        */   
        private boolean isFactor(String text) {
            
            Pattern p = Pattern.compile("(.*)AND(.*)");
            Matcher m = p.matcher(text);

            if ( m.lookingAt() )
                return true;
            
            return false;
        }
        
        
        /**
        *  Check if a given string is still a simple expression
        *  @param text String String representation of simple expression
        *  @return boolean True if given string is a simple expression
        */   
        private boolean isSimpleExpression(String text) {
            
            Pattern p = Pattern.compile("([A-Za-z0-9]+)[ \t]+IS[ \t]+([A-Za-z0-9]+)");
            Matcher m = p.matcher(text);

            if ( m.lookingAt() )
                return true;
            
            return false;
        } 
        
        
       /** Parse string in order to find SimpleExpression
        *  @param  value String String representation of the SimpleExpression
        *  @return SimpleExpression Returns created SimpleExpression
        */
        public SimpleExpression createSimpleExpression( String value ) throws ParseErrorException {

            // Match the whole SET definition
            Pattern p = Pattern.compile("(.*)IS(.*)");
            Matcher m = p.matcher(value);

            if ( !m.lookingAt()  )
                throw new ParseErrorException("String is not a SimpleExpression");
            
            SimpleExpression se = new SimpleExpression( m.group(1).trim() , m.group(2).trim() );
           
            return se; 
        }
        
    }
