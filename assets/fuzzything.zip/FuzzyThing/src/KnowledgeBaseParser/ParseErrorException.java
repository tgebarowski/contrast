/*
 * ParseErrorException.java
 *
 * Exception used in signalling parse errors
 * @author Tomasz Gebarowski
 */

package KnowledgeBaseParser;

 public class ParseErrorException extends Exception
 {
       public String name; // containing name of the parse error

      /** Creates instance of an exception
       *  @param name  String Content of the error
       *  @throws Exception
       */
       public ParseErrorException(String name) {
           this.name = name;

       }

      /**
       * Print error message
       */
       public void print() {
            System.err.println(name);
       }   
  }
