/*
 * KnowledgeBaseParser.java
 *
 * Created on 10th January 2007, 15:46
 */

package KnowledgeBaseParser;


import java.util.Vector;
import java.util.Stack;
import java.util.Iterator;
import java.util.regex.*;
import java.io.*;

import KnowledgeBase.*;

/**
 * Class representing KnowlegeBaseParser
 * It is used for parsing knowledge base files.
 * @author Tomasz Gebarowski
 */
public class KnowledgeBaseParser {
    
    private KnowledgeBase kb; // rerefence to the Knowledge Base
    private Universe currentUniverse; // reference to the curently processed Universe
    private Rule currentRule; // reference to the curently processed Rule
    private String fileName; // path to the parsed file
    private Vector<String> content; // vector of lines
    private String currentLine; // string containing current line
    private Iterator currentIt; // current Line iterator
    private StateManager stateManager; // reference to StateManager objec
    private BufferedReader in; // BufferedReader object
    private TopDownPremisseParser ruleParser;
    
    // Debug Mode - if true then print output strings showing different levels of parsing
    private final static boolean debugMode = false;
   
     

   /**
    * Class responsible for managing states of the parsed file
    * It uses stack based aproach to switch between states.
    * Current state is always on top
    */
    private class StateManager extends Object {
        private Stack states; // stack object
        private int pos; // current position on the stack
        
       /**
        * Creates instance of class
        */
        public StateManager() {
            states = new Stack();
            pos = -1;
        }
        
       /**
        * Push new state onto the stack
        * @param name String Name of the state
        */
        public void addState(String name) {  
            if ( name != null ) {
                String tmp = name;
                states.addElement( tmp );
                pos++;
            }     
        }
        
       /**
        * Remove current state from the stack
        */
        public void removeState() {
            if ( states.size() > 0 ) {
                states.remove(pos);
                pos--;
                
            }
        }
        
       /**
        * Get current state from the stack
        */
        public String getCurrent() {
            return (String)states.elementAt(pos);
        }
        
       /** Returns true if a given state is on the stack
        *  @param state  String Name of the state
        */
        public boolean isOnTop(String state) {
            if ( pos < 0 )
                return false;
            
            String tmp = (String)states.elementAt(pos);
            
            if ( tmp.compareTo( state ) == 0 )
                return true;
            else 
                return false;
            
        }
    }
    

    
   /**
    * Creates a new instance of KnowledgeBaseParser 
    * @param kb KnowledgeBase Reference to the KnowledgeBase
    * @param fileName String Knowledge base file path
    */
    public KnowledgeBaseParser(KnowledgeBase kb, String fileName) {
        this.kb = kb;
        this.fileName = fileName;
        content = new Vector();
        stateManager = new StateManager();
        ruleParser = new TopDownPremisseParser();
                  
    }
    
   /** Load file content and store in line by line in a vector of strings
    *  Remove empty lines.
    */
    public void load() throws Exception {
        File fin = new File(fileName);
        FileInputStream fis = new FileInputStream(fin); 
        BufferedReader in = new BufferedReader(new InputStreamReader(fis));    
        
        String currentLine = null;
        while((currentLine = in.readLine()) != null) {
             String tmpLine =  currentLine;
             if ( tmpLine.trim().length() > 0 )
                content.add( (String)tmpLine );

        }
        
        this.currentIt = content.iterator();
        
    }
    
   /** Move to the next line of file. Iterate vector.
    */
    private void nextLine() {
        if ( currentIt.hasNext() ) {
            currentLine = (String)currentIt.next();
            currentLine.trim();
        } else {
            currentLine = null;
        }
    }
    
   /** Return current line
    *  @return String Current line content
    */
    private String currentLine() {
        return currentLine;

    }
    
   /** Parse Knowledge Base
    *  Check if KB tags are structured properly.
    *  @throws ParseErrorException Exception thrown on parse error
    */
    private void parseKB() throws ParseErrorException{

        String beginKB = (String)(content.firstElement());
        String endKB = (String)(content.lastElement());
        
        if ( beginKB.trim().compareTo("KB") != 0 )
            throw new ParseErrorException("Missing KB at the begining of file or improper starting line.");
        else if ( endKB.trim().compareTo("KB_END") != 0 )
            throw new ParseErrorException("Missing KB at the end of file or improper line ending.");
        
         stateManager.addState("KB");
    }
    
   /** Parse Universe
    *  Iterate over Universe structure. Send matched strings to the processUniverse method
    *  @throws ParseErrorException Exception thrown on parse error
    */
    private void parseUniverse() throws ParseErrorException {
        
        this.nextLine(); // skip KB entry
        
        // Match lines starting with SET | UNIVERSE | UNIVERSE_END
        Pattern p = Pattern.compile("[ \t]*(SET|UNIVERSE(_END)?)(.*)");
        Matcher m;
        
        while (true) {
            this.nextLine();
            m = p.matcher(currentLine);
                     
            if ( !m.lookingAt() ) {
                break;
            } else {

              processUniverse(m.group(1), m.group(3) );   
            }
            
        }   
    }
    
   /** Parse Variables
    *  Iterate over Variables structure.
    *  Send matched strings to the processVariables method.
    *  @throws ParseErrorException Exception thrown on parse error
    */
    private void parseVariables() throws ParseErrorException {
        
        // Match the whole line containing variables
        Pattern p = Pattern.compile("[ \t]*(VARIABLE)(.*)(VARIABLE_END)");
        Matcher m;
        
        while (true) {  
            m = p.matcher(currentLine);
                     
            if ( !m.lookingAt() ) {
                break;
            } else {
                if ( stateManager.isOnTop("KB") ) {
                    stateManager.addState(m.group(1).trim()); // add VARIABLE state to the stackManager
                    processVariables(m.group(2) );                                       
                } else {
                    throw new ParseErrorException("VARIABLE token used in a wrong place. It should be delimited by KB tags."); 
                }    
            }  
            stateManager.removeState();
            this.nextLine();
        }
        
    }
    
   /** Parse Rules
    * Iterate over Rules structure.
    * Send matched strings to the processRules method.
    * @throws ParseErrorException Exception thrown on parse error
    */
    private void parseRules() throws ParseErrorException {
        
        // Match lines starting with IF | THEN | RULE | RULE_END 
        Pattern p = Pattern.compile("[ \t]*(IF|THEN|RULE(_END)?)(.*)");
        Matcher m;
        
        while (true) {
            
            m = p.matcher(currentLine);
                     
            if ( !m.lookingAt() ) {
                break;
            } else {
              processRules(m.group(1), m.group(3) );   
            }
            this.nextLine();
        }
        
    }
    
   /** Method responsible for processing rules
    * @param tag String Matched tag  ( IF|THEN|RULE|RULE_END otherwise parse error) 
    * @param value String Remaining part of the line content
    * @throws ParseErrorException Exception thrown on parse error
    */
    private void processRules(String tag, String value) throws ParseErrorException {
        if ( tag.compareTo("RULE") == 0 )
        {  
            
            // Match Rule Name without spaces and separators otherwise return Exception
            Pattern p = Pattern.compile("[\t\\s]*[_A-Za-z0-9]+[\t\\s]*");
            Matcher m = p.matcher(currentLine);
            
            if ( m.lookingAt() ) 
            {
                currentRule = new Rule(value);
                kb.addRule( currentRule );
            } else {
              throw new ParseErrorException("Wrong rule name. Rule should have one word name without any separators.");   
            }
            
            if ( stateManager.isOnTop("KB") ) {
                stateManager.addState(tag);                            
            } else {
               throw new ParseErrorException("RULE token used in a wrong place. It should be delimited by KB tags."); 
            }
    
        } else if ( tag.compareTo("RULE_END") == 0 )
        {
            stateManager.removeState();     
        // Try to match IF statement
        } else if ( tag.compareTo("IF") == 0 ) {
            processPremisse( value );
        
        // Try to match THEN statement
        } else if ( tag.compareTo("THEN") == 0 ) {
           processConclusion( value ); 
            
        }

    }
    
   /** Method responsible for processing premisse
    * @param value String Premisse content 
    * @throws ParseErrorException Exception thrown on parse error
    */
    private void processPremisse( String value ) throws ParseErrorException {
        
        if ( debugMode )
            System.out.println("PREMISSE:" + value);
 
        Expression e = ruleParser.parse(value);
        currentRule.addPremisse(e);
 
    }
    

    
   /** Method responsible for processing premisse
    * @param value String Premisse content 
    * @throws ParseErrorException Exception thrown on parse error
    */
    private void processConclusion ( String value ) throws ParseErrorException {
        
        if ( debugMode )
            System.out.println("CONCLUSION:" + value);

        currentRule.addConclusion( ruleParser.createSimpleExpression(value) );
    }
    
   /** Method responsible for processing Variables
    * and adding them into KnowledgeBase.
    * @param value String String representation of variable
    * @throws ParseErrorException Exception thrown on parse error
    */
    private void processVariables(String value) throws ParseErrorException {
        
        //Define separators ( tab(s) or/and space(s) ) 
        Pattern p = Pattern.compile("[\t\\s]+");
        // Split input with the pattern
        String[] result = p.split(value);
        
        // checking if the universe exists -- should be added
        
        Variable.Type type;
        
        if ( result[3].trim().compareTo("in") == 0 ) {
            type = Variable.Type.IN;
        } else if ( result[3].trim().compareTo("out") == 0 ) {
            type = Variable.Type.OUT;
        } else {
            throw new ParseErrorException("Incorrect variable type: " + result[3]);
        }
        
        kb.addVariable( new Variable( result[1], result[2], type ) );
    }
    
    
   /** Method responsible for processing Sets
    *  and adding them into KnowledgeBase.
    *  @param value String String representation of a set
    *  @throws ParseErrorException Exception thrown on parse error
    */
    private void processSets(String value ) throws ParseErrorException {
      
        //Define separators ( tab(s) or/and space(s) )
        Pattern p = Pattern.compile("[\t\\s]+");
        // Split input with the pattern
        String[] result = p.split(value);
             
        currentUniverse.addSet( new Set(result[1], Double.parseDouble( result[2]), Double.parseDouble( result[3]), Double.parseDouble( result[4]), Double.parseDouble( result[5]) ) );        
    }
    
   /** Method responsible for processing Universes
    *  and adding them into KnowledgeBase.
    *  @param tag String Represents matched tag ( SET|UNIVERSE|UNIVERSE_END otherwise parse error )
    *  @param value String Remaining part of the line content
    *  @throws ParseErrorException Exception thrown on parse error
    */
    private void processUniverse(String tag, String value) throws ParseErrorException {
        
        if ( tag.compareTo("UNIVERSE") == 0 )
        {
            if ( stateManager.isOnTop("KB") ) {
                stateManager.addState(tag);
                currentUniverse = new Universe( value.trim()  );
                kb.addUniverse( currentUniverse ); // Add universe to the knowledge base
                               
            } else {
               throw new ParseErrorException("UNIVERSE token used in a wrong place. It should be delimited by KB tags."); 
            }
    
        } else if ( tag.compareTo("UNIVERSE_END") == 0 )
        {
            stateManager.removeState();
            
        }  else if ( tag.compareTo("SET") == 0 )
        {
            if ( stateManager.isOnTop("UNIVERSE") )
                stateManager.addState(tag);
            else {
                throw new ParseErrorException("SET token used in a wrong place. It should be delimited by UNIVERSE tags.");
            }

            // Match the whole SET definition
            Pattern p = Pattern.compile("[ \t]*(SET)(.*)(SET_END)(.*)");
            Matcher m = p.matcher(currentLine);
            m.lookingAt();
            processSets( m.group(2) );
            
            stateManager.removeState();

        } 
         
        
    }
    
   /**
    * Method used to start parsing.
    */
    public void parse() {
        try {
            parseKB();   
            parseUniverse();
            parseVariables();
            parseRules();
            
            stateManager.removeState(); // remove KB state
        } catch ( ParseErrorException e ) {
            e.print();
        }
        
    }
    

}
