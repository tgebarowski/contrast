/*
 * FLC.java
 *
 * Created on 23 januari 2007, 12:54
 *
 */

package FLC;

import fuzzything.*;
import KnowledgeBase.*;
import KnowledgeBase.KnowledgeBase.*;
import KnowledgeBaseParser.*;
import java.io.*;
import java.util.Vector;

/**
 * Fuzzy Logic Controller
 * @author mathijs
 * @author Tomasz Gebarowski
 */
public class FLC extends Thread {
    private fuzzything.Process testedProcess;
    private KnowledgeBase kb;
    private KnowledgeBaseParser kbp;
    private boolean run;
    
    private final static boolean debugMode = false;
    
    /**
     * Fuzzy Logic Controller Constructor
     * @param p Process reference to controlled process
     * @param kbPath String knowledge base path
     */
    public FLC(fuzzything.Process p, String kbPath) {
        this.testedProcess = p;
        this.kb = new KnowledgeBase();
        this.kbp = new KnowledgeBaseParser(kb, kbPath);
        this.run = true;
        
        try
        {
            kbp.load();
            kbp.parse();
        } 
        catch ( ParseErrorException e ) 
        {
            e.print();
        } catch (Exception e ) {
            e.printStackTrace();
        }
    }
    
    
  /**
    * Start the simulation process
    */ 
    public void run()
    { 
        while (true)
        {
            testedProcess.simulateStep(0.1);
            Vector<Set> sets = makeDecisions();
            double d = this.defuzzificate(sets);
            
            if ( sets.size() > 0 ) {
                String str = sets.get(0).getName();
                executeDecisions(d, str);
            }
 
            try {
                Thread.sleep(30);
            }
            catch (Exception e)
            {}
        }
    }
    
  /**
    * Return the membership of value to a given fuzzy set 
    * @param s Set Specified set
    * @param d double Value for which the membership should be determined
    * @return double Level of membership   
    */
    private double getFuzzyValue(Set s, double d)
    {   
        if(d >= s.getX(1) && d < s.getX(2))
        {
            return - (d / (s.getX(1) - s.getX(2)) ) + (s.getX(1) / (s.getX(1) - s.getX(2)));
        }
        else if(d >= s.getX(2) && d <= s.getX(3))
        {
            return s.getClippedValue();
        }
        else if(d > s.getX(3) && d <= s.getX(4))
        {
            return (d  / (s.getX(3) - s.getX(4)) ) - (s.getX(4) / (s.getX(3) - s.getX(4)));
        }
        return 0;
    }
    
  /**
    * Begin fuzzification of a premisse ( expression )
    * @param e Expression reference to a premisse 
    * @return Level of membership 
    */     
    private double fuzzifyPremisse( Expression exp) {
        return fuzzifyExpression(exp);
    }
    

    
  /**
    * Expression fuzzification
    * @param exp Expression Expression to be fuzzified
    * @return Level of membership 
    */      
    private double fuzzifyExpression( Expression exp ) {
        Vector<Term> terms = exp.getTermList();
        Vector<Double> fuzzyValues = new Vector();
        Vector<Double> fuzzyValuesFct = new Vector();
        double val = 0;
        
        for (int j = 0; j < terms.size(); j++)
        {
            Term t = (Term)terms.elementAt(j);
            Vector<Factor> factors = t.getFactorList();
            for( int i = 0; i < factors.size(); i++ )
            {
                Factor f = (Factor)factors.elementAt(i);
                val = fuzzifyFactor(f);
                
                // If negated
                if ( f.isNot() )
                    val = 1 - val;
                
                fuzzyValuesFct.addElement(val); 
            }       
            
            double minValue = minFromVector(fuzzyValuesFct);
            
            // If negated
            if ( exp.isNot() ) {
                minValue = 1 - minValue;
            }
            
            fuzzyValues.addElement( minValue );
            fuzzyValuesFct.clear();
        }
        
        //Select Maximum value form fuzzyValues vector
        
        return maxFromVector(fuzzyValues);
    }
 
  /**
    * Factor fuzzification
    * @param f Factor Factor to be fuzzified
    * @return Level of membership 
    */    
    private double fuzzifyFactor( Factor f ) {
            double val = 0;
           

            if ( f.getSimpleExpression() != null)
            {
                val =  fuzzifySimpleExpression(f) ;
            } else if ( f.getFactor() != null ) {
                val =  fuzzifyFactor( f.getFactor() );       
            } else if ( f.getExpression() != null ) {
                 val = fuzzifyExpression( f.getExpression() );    
            } else {
                return 0;
            }
            
            //Return fuzzy value
            return val;
    }
    
  /**
    * Simple Expression Fuzzification Method
    * @param f Factor Factor to be fuzzified
    * @return Level of membership 
    */      
    private double fuzzifySimpleExpression(Factor f) {
        // get Simple Expression from Factor
        SimpleExpression se = f.getSimpleExpression();
        // get set name and variable name from Simple Expression
        String setName = se.getSetName();
        String varName = se.getVariableName();
        // variable used to store fuzzy result 
        
        try {
            // select set using variableName and setName
            Set s = kb.getSetByVariableName(varName, setName);
            // calculate fuzzy value
            
            //System.out.println("VARIABLE name: " + varName + " value: " + testedProcess.getVariable(varName));
            
            double fuzzyResult = this.getFuzzyValue(s, testedProcess.getVariable(varName)  );
            return fuzzyResult;
            
        } catch (Exception e ) {
            e.printStackTrace();
        }
        
        return -1;
    }  
    
  /**
    * Return clipped set from a given set and clip point
    * @param s Set Set to be clipped
    * @param clippedValue double Value of a clip point
    * @return Set Clipped set
    */           
    private Set getClippedSet(Set s, double clippedValue)
    {
        double x2 = s.getX(1);
        double x3 = s.getX(4);
        
        if (s.getX(1) != s.getX(2))
        {
            x2 = s.getX(1) - clippedValue * (s.getX(1) - s.getX(2));
        }
        
        if (s.getX(3) != s.getX(4))
        {
            x3 = s.getX(4) + clippedValue * (s.getX(3) - s.getX(4));
        }
        
        
        return new Set(s.getName(), s.getX(1), x2, x3, s.getX(4), clippedValue);
    }
    
  /**
    * Evaluate single rule
    * @param r Rule Rule to be evaluated
    * @return Set Clipped set which is the result of the rule evaluation
    */     
    private Set evaluateSingleDecision(Rule r)
    {
         Set nSet;
         SimpleExpression se = r.getConclusion();
         
         // calculate premisse fuzzy value
         double pFuzzyValue = fuzzifyExpression( r.getPermisse() );
         
         if ( debugMode )
            System.out.println("Fuzzy Value for rule: (" + r.getPermisse() +") => " +  r.getConclusion() + "= " + pFuzzyValue);

         // Process conclusion
         try {
                 String setName = se.getSetName();
                 String varName = se.getVariableName();
                 
                 // select set using variableName and setName
                 nSet = kb.getSetByVariableName(varName, setName);
                 nSet = getClippedSet(nSet, pFuzzyValue);
                 
                 // set name associated with the output variable
                 nSet.setName(varName);
                 //System.out.println("Clipped set: " + nSet);
                 return nSet;  
      
         } catch ( Exception  e) {
             
                 e.printStackTrace();
         }
         return null;
    }

    
  /**
    * Evaluate all the rules stored in the Knowledge Base
    * @return Vector<Set> Returns vector of clipped sets
    */   
    private Vector<Set> makeDecisions()
    {
        Vector<Set> sets = new Vector();
        
        // Loop through all rules
        Vector<Rule> rules = this.kb.getRules();
        for (int i = 0; i < rules.size(); i++) {
            Rule r = (Rule)rules.elementAt(i);
            Set s = evaluateSingleDecision(r);
            sets.addElement(s);
        }
        return sets;
    }   
    
  /** Get the lower boundry of a given vector of sets.
    *  @param sets Vector<Set> Vector of sets
    *  @return double lower boundry
    */   
    private double minSetValue(Vector<Set> sets) {
        Vector values = new Vector();
        
        for( int i = 0; i < sets.size(); i++ ) {
            double d = (double)sets.elementAt(i).getX(1);
            values.addElement( d ); 
        }
        
        return minFromVector(values);
    }
    
   /** Get the upper boundry of a given vector of sets.
     *  @param sets Vector<Set> Vector of sets
     *  @return double upper boundry
     */
    private double maxSetValue(Vector<Set> sets) {
        Vector values = new Vector();
        
        for( int i = 0; i < sets.size(); i++ ) {
            double d = (double)sets.elementAt(i).getX(4);
            values.addElement( d ); 
        }
        
        return maxFromVector(values);
    }
    
  /** Update process attributes 
    * @param defuzzifiedValues Vector<Set> Vector of defuzzified valus that were returned by defuzzification method
    */
    private void executeDecisions(double value, String name) {
            this.testedProcess.setVariable(name, value);
    }
    
  /** Defuzzificate all output variable values
    * Function returns the set in which only two attributes are important:
    * x1 - defuzzified value
    * name - the name of output variable to which the defuzzified value is assigned
    * All other x's of set are set to zero.
    * @param clippedSets Vector<Set>  Reference to a vector of clipped sets
    * @return double Defuzzified value
    */
    private double defuzzificate(Vector<Set> clippedSets) {
        double s1 = 0;
        double s2 = 0;
        
        for (double x = this.minSetValue(clippedSets); x <= this.maxSetValue(clippedSets); x += 0.5)
        {
            double maxY = 0;
            for (int i = 0; i < clippedSets.size(); i++)
            {
                Set s = clippedSets.elementAt(i);
                maxY = Math.max(this.getFuzzyValue(s, x), maxY);
            }
            
            s1 += x * maxY;
            s2 += maxY;
        }
        
        // avoid division by zero
        if ( s2 == 0 )
            return 0;
 
        return s1 / s2;
    }
    
    
  /**
    * Return maximum from a given vector of doubles
    * @param vct Vector<Double> Reference to a vector of double
    * @return double Maximum double stored in a vector
    */       
    private double maxFromVector( Vector<Double> vct) {
        double max = 0;
        for ( int i = 0; i < vct.size(); i++) {
            max = Math.max(max, vct.elementAt(i)); 
        }
        return max;
    }

    
  /**
    * Return minimum from a given vector of doubles
    * @param vct Vector<Double> Reference to a vector of double
    * @return double Minimum double stored in a vector
    */     
    private double minFromVector( Vector<Double> vct) {
        double min = 1;
        for ( int i = 0; i < vct.size(); i++) {
            min = Math.min(min, vct.elementAt(i)); 
        }
        return min;
    }
}
