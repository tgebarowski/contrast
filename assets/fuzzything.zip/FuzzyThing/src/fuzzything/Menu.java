/*
 * Menu.java
 *
 * Created on 1 February 2007, 23:13
 *
 * @author Tomasz Gebarowski
 */

package fuzzything;


import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import FLC.*;


/** Class displaying Main Menu for the application
 */
public class Menu extends JPanel implements ActionListener  {
    
    
  /** Class extending JPanel and displaying application image
    */
    private class ImgPanel extends JPanel {
        
        // buffered image to store logo
        private BufferedImage imgLogo;
        
        
      /**
        * ImgPanel condtructor
        */
        ImgPanel() {
            super();
            this.setPreferredSize(new Dimension(300, 116));
            this.setBorder(BorderFactory.createLineBorder (Color.black, 2));
            this.setBackground(Color.white);
            
            
            try {
                imgLogo = ImageIO.read(ClassLoader.getSystemResourceAsStream("images/logo.jpg"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
      /**
        * Method called on every repaint even
        * @param g Graphics Reference to Graphics object
        */
        public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		setBackground(Color.white);
		g.setColor(getForeground());
                
                //draw logo
                g.drawImage(imgLogo, 0 , 0, null);

		
	}
    }  
    
    private JPanel buttonPanel;
    private ImgPanel imgPanel;
    private JButton bTankProcess;
    private JButton bSteeringProcess;
    private JButton bQuit;
    
    private JFrame jf;
    
  /**
    * Creates a new instance of Menu
    */
    public Menu() {
        this.jf = new JFrame("Fuzzy Logic Process Tester");
        this.jf.setSize( new Dimension(300, 200));
        this.jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        buttonPanel = new JPanel(new GridLayout(3, 1) );
        buttonPanel.setBorder( BorderFactory.createEmptyBorder(5,5,5,5) );
        imgPanel = new ImgPanel();
        
        bTankProcess = new JButton("Tank Process");
        bSteeringProcess = new JButton("Steering Process");
        bQuit = new JButton("Quit");
        
        bTankProcess.addActionListener(this);
        bSteeringProcess.addActionListener(this);
        bQuit.addActionListener(this);
        
        
        buttonPanel.add(bTankProcess);
        buttonPanel.add(bSteeringProcess);
        buttonPanel.add(bQuit);
        
        this.jf.setLayout(new GridLayout(2, 1));
        
        this.jf.getContentPane().add(imgPanel);
        this.jf.getContentPane().add(buttonPanel);
        
        this.jf.pack();
        this.jf.setVisible(true);
    }
    
  /** Method implemented from ActionListener used for listening button actions
    *  @param e ActionEvent Reference to current action event
    */
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        
        JFrame processFrame = new JFrame("Process Tester");
        
        String kb = "";
        Object p = null;
        
        if ( o == bQuit ) {
            System.exit(0);
        } else if ( o == bTankProcess ) {
            kb = "KB_Tank.txt";
            p = new Tank();

        } else if ( o == bSteeringProcess ) {
            kb = "KB_Car.txt";
            p = new Steering(); 
        }
        
        processFrame.setSize(700,700);

        processFrame.getContentPane().add((JPanel)p);
        processFrame.setVisible(true);

        FLC flc = new FLC((Process)p, kb);
        flc.start();
    }
}
