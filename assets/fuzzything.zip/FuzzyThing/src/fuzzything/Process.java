package fuzzything;

/** Interface class to define simulated process. 
*/
public abstract interface Process
{
	/** Gets a variable.
	*
	* @param name	a String, representing the name of the variable
	*/
	public abstract double getVariable(String name);
	
	/** Sets a variable.
	*
	* @param name	a String, representing the name of the variable
	* @param value	a double, representing the value of that variable
	*/	
	public abstract void setVariable(String name, double value);
	
	/** Simulates the movement of the robot over a certain time period. 
	*
	* @param deltaT a double, representing the interval of time which is simulated.
	*/	
	public abstract void simulateStep(double deltaT);
}