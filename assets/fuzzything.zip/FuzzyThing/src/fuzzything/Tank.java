/*
 * Tank.java
 *
 * Created on 28 January 2007, 13:24
 *
 */

package fuzzything;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import java.util.*;

/**
 * This class represents Tank process that will be controlled by FLC
 * @author Tomasz Gebarowski
 */
public class Tank extends JPanel implements Process, ActionListener, ChangeListener {
    
    // Visual Components of GUI
    private WaterContainer wc;
    private JSlider outFluxSlider;
    private JButton simulateButton;
    private JButton resetButton;
    //Used for storing tap image
    private BufferedImage tapImg;
    
    //Used for storing current state of process
    private boolean paused;
    
    // Basic parameters of tank
    private double height;
    private double inFlux;
    private double outFlux;
    
    //Numeric constants used fo Slider
    static final int FLUX_MIN = 5;
    static final int FLUX_MAX = 26;
    static final int FLUX_INIT = 10; 
    //Default level of water
    static final float MAX_HEIGHT = 100.0f;
    static final float DEFAULT_HEIGHT = 50.0f;
    
   /** This class represents a Water Container that is drawn on JPanel
    *  Class extends JPanel.
    */
    private class WaterContainer extends JPanel  {

        private float height;
        
       /** WaterContainer constructor 
        *  @param height float Initial level of water 
        */
        WaterContainer(float height) {
            super();
            this.setPreferredSize(new Dimension(400, 0));
            this.setBorder(BorderFactory.createLineBorder (Color.blue, 2));
            this.setBackground(Color.white);
            
            this.height = height;
            
            try {
                tapImg = ImageIO.read(ClassLoader.getSystemResourceAsStream("images/tap.gif"));
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        
       /** Method used to change level of water
        *  @param float height New level of water
        */
        public void setHeight(float height) {
            this.height = height;
        }
        
       /** Method called on every repaint
        *  @param g Graphics Reference to object of type graphics
        */
        public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		setBackground(Color.white);
		g.setColor(getForeground());
		drawScene(g);
	}
        
       /**
        * Method used for drawing a water container, labels and additional symbols.
        * @param g Graphics Reference to object of type graphics.
        */
        private void drawScene(Graphics g) {
            Rectangle panelBounds = super.getBounds();
            int pWidth = panelBounds.width;
            int pHeight = panelBounds.height;

            // draw container border
            g.drawRect(pWidth / 4, 10, pWidth / 2,  pHeight - 50);
   
            g.setColor(Color.BLUE);
            
            // draw water level
            g.fillRect(pWidth / 4 + 1,
                       pHeight - 50 -   Math.round( 3 * this.height ),
                       pWidth / 2 - 1,
                       Math.round( 3 * this.height ) + 10 );
            
            
            //draw labels   
            g.drawString("inFlux:" + inFlux, pWidth / 4 - 100, 20);
            g.drawString("outFlux:" + outFlux, pWidth / 4 + pWidth / 2 + 30 , pHeight - 100);
            
            //draw height label
            g.setColor(Color.WHITE);
            g.drawString( height + " liters",  pWidth / 2 - 30,  (int)Math.round(  pHeight -  3 * this.height - 35 ) ); 
            
            //draw tap
            int width = tapImg.getWidth();         
            int height = tapImg.getHeight();
            g.drawImage(tapImg, (int)Math.round(0.75 * pWidth) , pHeight - 35 - height, null);
            
            if ( paused ) {
                g.fillRect((int)Math.round(0.75 * pWidth)+40, pHeight - 35 - height + 38, 50, 20 );
            }
        }
        
        

        
    }
    

    
    /** Creates a new instance of Tank */
    public Tank() {
        super(new GridBagLayout() );
        
        inFlux = 10;
        outFlux = 0.5 * FLUX_INIT;
        height = DEFAULT_HEIGHT;
        paused = true;
        createUI();
        
    }
    
 
   /** Draw all gui elements
    */
    public void createUI () {
     
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        
        this.setSize(400,600);
        
        
        wc = new WaterContainer((float)height);
        simulateButton = new JButton("Start");
        simulateButton.addActionListener(this);
        simulateButton.addChangeListener(this);
        
        resetButton = new JButton("Reset");
        resetButton.addActionListener(this);
        
        outFluxSlider = new JSlider( JSlider.HORIZONTAL, FLUX_MIN, FLUX_MAX, FLUX_INIT);
        outFluxSlider.setMajorTickSpacing(10);
        outFluxSlider.setMinorTickSpacing(1);
        outFluxSlider.setPaintTicks(false);
        outFluxSlider.setPaintLabels(false);
        outFluxSlider.addChangeListener(this);

        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.gridheight = 1;
        constraints.ipadx = 150;
        constraints.ipady = 500;
        this.add(wc, constraints);

        constraints.ipadx = 10;
        constraints.ipady = 10;
        
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.weightx = 0.5;
        constraints.fill = constraints.NONE;
        
        JPanel panel = new JPanel(new FlowLayout() );
        JLabel label = new JLabel("outFlux:");
        panel.add(label);
        panel.add(outFluxSlider);
        panel.add(simulateButton);
        panel.add(resetButton);
        
        this.add(panel, constraints);
        
        
    }
    
   /** Method implemented from ActionListener used for listening button actions
    *  @param e ActionEvent Reference to current action event
    */
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        
        if ( o == simulateButton ) {
           changeProcessState();
 
        } else if ( o == resetButton ) {
            paused = true;
            simulateButton.setText("Start");
            height = DEFAULT_HEIGHT;
            wc.setHeight(DEFAULT_HEIGHT);
        }
    }
    
   /** Method implemented from ChangeListener used for listening button actions
    *  @param e ChangeEvent Reference to current change event
    */
    public void stateChanged(ChangeEvent e) {

        Object source = e.getSource();
        
        if ( source == outFluxSlider ) {
            JSlider s = (JSlider)e.getSource();
            int value = (int)s.getValue();

            if (!s.getValueIsAdjusting()) { //done adjusting
                  outFlux =  0.5 * value;

            } else { //value is adjusting; just set the text
                outFlux = 0.5 * value;
                repaint();
            }
        } else if  ( source == simulateButton ) {
            if ( paused )
                simulateButton.setText("Start");
            else
                simulateButton.setText("Pause");
        }
    }
    
   /** Used for change process state
    *  Toggles pause on/off.
    */
    public void  changeProcessState(){
        this.paused ^= true;

    }
    
   /** Getter for the paused attribute
    *  @return boolean Paused attribute.
    */
    public boolean getPaused() {
        return paused;
    }
          
   /** Method implemented from Process interface used to get the value of process variable
    *  @param name String variable name
    *  @return double Variable value
    */
    public double getVariable(String name) { 
        if ( name.equals("height")  ) {
            return height;
        } else {
            return -1;
        }
    }
    
   /** Method implemented from Process interface used to set the value of process variable
    *  @param name String variable name
    *  @param value double Variable value
    */
    public void setVariable(String name, double value ) {
        if ( name.equals("inFlux") ) {
            inFlux = value;
        } 
    }
    
   /** Method implemented from Process interface used to simulate one step of process
    *  @param deltaT double Time period
    */   
    public void simulateStep(double deltaT) {
       
       if ( !paused ) {
            height = height + (inFlux - outFlux) * deltaT;
            wc.setHeight((float)height);
       }
       
       repaint();
    }
}
