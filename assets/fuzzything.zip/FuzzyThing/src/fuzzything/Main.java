/*
 * Main.java
 *
 * Created on 10 januari 2007, 15:47
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package fuzzything;

import KnowledgeBase.*;
import KnowledgeBaseParser.*;
import javax.swing.*;
import FLC.*;

/**
 *
 * @author mathijs
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        
        
        //JFrame jf = new JFrame();
        //jf.setSize(700,700);
        //jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
        Menu m = new Menu();
        
        //Steering p = new Steering();
         
        //Tank p = new Tank();
       
        /*jf.getContentPane().add(p);
        //jf.pack();
        jf.setSize(800, 800);
        jf.setVisible(true);

        FLC flc = new FLC(p, "KB_Tank.txt");
        flc.run();//*/
        
    }
    
}
