/**
 *  @file       azt_code_simple_object.c
 *  @brief      <<DESCRIPTION>>
 *
 *  @author     <<AUTHOR>>
 *  @date       <<DATE>>
 *
 *  @defgroup	AztCodeSimpleObjectObject AztCodeSimpleObject API
 *  @brief	    Definition of the AztCodeSimpleObject API
 */
/* <<COPYRIGHT>> */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <glib.h>
#include "azt_code_simple_object.h"

/* Domain definition for debugger */
#undef G_LOG_DOMAIN
#define G_LOG_DOMAIN "AztCodeSimpleObject"


/**
 * @struct _AztCodeSimpleObject
 * @brief AztCodeSimpleObject members
 *
 * @ingroup AztCodeSimpleObjectObject 
 */
struct _AztCodeSimpleObject
{
    /**
     * @name Public Fields
     */

    /**
     * @name Private Fields
     */
    guint _value; /**< Exemplary integer field description */
};


/* Documented in header */
AztCodeSimpleObject *
azt_code_simple_object_new(guint value)
{
    AztCodeSimpleObject *self = NULL;
    /* Allocate new AztCodeSimpleObject */
    self = g_try_malloc0(sizeof(AztCodeSimpleObject));

    if(self != NULL)
    {
        /* Initialize members */
        self->_value = value;
    }
    return self;
}



/* Documented in header */
void
azt_code_simple_object_destroy(AztCodeSimpleObject *self)
{
    if(self != NULL)
    {
        /* Free members */
        self->_value = 0;
        g_free(self);
    }
}

/* Documented in header */
void
azt_code_simple_object_set_value(AztCodeSimpleObject *self,
                                 const guint value)
{
    if(self != NULL)
    {
        self->_value = value;
    }
}


/* End of azt_code_simple_object.c */


