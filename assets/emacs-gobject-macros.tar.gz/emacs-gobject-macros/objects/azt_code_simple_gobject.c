/**
 *  @file       azt_code_simple_gobject.c
 *  @brief      <<DESCRIPTION>>
 *
 *  @author     <<AUTHOR>>
 *  @date       <<DATE>>
 */
/* <<COPYRIGHT>> */


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "azt_code_simple_gobject.h"

/* Domain definition for debugger */
#undef G_LOG_DOMAIN
#define G_LOG_DOMAIN "AztCodeSimpleGObject"

/* Type definition of the _AztCodeSimpleGObjectPrivate structure              */
typedef struct _AztCodeSimpleGObjectPrivate AztCodeSimpleGObjectPrivate;

/**
 * @struct _AztCodeSimpleGObjectPrivate
 * @brief Private fields of AztCodeSimpleGObject 
 *
 * @ingroup AztCodeSimpleGObject
 */
struct _AztCodeSimpleGObjectPrivate
{
    /**
     * @name Private Members
     */
    guint _value; /**< Field Description */
};


/*  Macro definition for accessing private data of an object                 */
#define AZT_CODE_SIMPLE_GOBJECT_GET_PRIVATE(o) \
    ((AztCodeSimpleGObjectPrivate *)((AZT_CODE_SIMPLE_GOBJECT(o))->priv))

/*  ----------------- Predefinitions --------------------------------------- */

/* GObject Methods */
static void azt_code_simple_gobject_class_init(AztCodeSimpleGObjectClass *klass);
static void azt_code_simple_gobject_init(AztCodeSimpleGObject *self);
static void azt_code_simple_gobject_dispose(GObject *object);
static void azt_code_simple_gobject_finalize(GObject *object);

/* Method Implementation */
static gboolean
__azt_code_simple_gobject_initialize_impl(AztCodeSimpleGObject *self,
                                          const guint value);


/* ----------------- End of Predefinitions --------------------------------- */



/*  Generating the whole stuff connected with a registration of a new GObject
 *  and definition of a azt_code_simple_gobject_get_type method
 */
G_DEFINE_TYPE(AztCodeSimpleGObject, azt_code_simple_gobject, G_TYPE_OBJECT)



/*
 * Standard GObject method invoked in order to initialize object class
 */
static void
azt_code_simple_gobject_class_init(AztCodeSimpleGObjectClass *klass)
{
    GObjectClass *object_class = G_OBJECT_CLASS (klass);
    /* Attach implementations of generic GObject methods                      */
    object_class->dispose = azt_code_simple_gobject_dispose;
    object_class->finalize = azt_code_simple_gobject_finalize;

    /* Attach implementation callbacks to virtual public methods              */
    klass->initialize = __azt_code_simple_gobject_initialize_impl;
}


/*
 * Standard GObject method used for initializing object
 */
static void
azt_code_simple_gobject_init(AztCodeSimpleGObject *self)
{
    (AZT_CODE_SIMPLE_GOBJECT(self))->priv = (AztCodeSimpleGObjectPrivate *) \
        g_try_malloc0(sizeof(AztCodeSimpleGObjectPrivate));
}


/*
 * Standard GObject method used for disposing memory allocated by the object
 */
static void
azt_code_simple_gobject_dispose(GObject *object)
{
    AztCodeSimpleGObject *self = (AztCodeSimpleGObject *)object;
    AztCodeSimpleGObjectPrivate *priv = NULL;

    /* Get private pointer */
    if(self != NULL)
    {
        priv = AZT_CODE_SIMPLE_GOBJECT_GET_PRIVATE(self);
    }

    /* If priv is NULL, we already deallocated it */
    if(priv != NULL)
    {
        g_free(priv);
        (AZT_CODE_SIMPLE_GOBJECT(object))->priv = NULL;
    }
    G_OBJECT_CLASS(azt_code_simple_gobject_parent_class)->dispose(object);
}


/*
 * Standard GObject method called after dispose
 */
static void
azt_code_simple_gobject_finalize(GObject *object)
{
    G_OBJECT_CLASS(azt_code_simple_gobject_parent_class)->finalize(object);
}


/* -------------------------------------------------------------------------- */
/* ------------------------ Public Virtual Methods -------------------------- */
/* -------------------------------------------------------------------------- */

/* Documented in header */
static gboolean
__azt_code_simple_gobject_initialize_impl(AztCodeSimpleGObject *self,
                                          const guint value)
{
    gboolean ret_val = FALSE;
    
    if (self != NULL)
    {
        AztCodeSimpleGObjectPrivate *priv =\
            AZT_CODE_SIMPLE_GOBJECT_GET_PRIVATE(self);
        
        priv->_value = value;

        ret_val = TRUE;
    }
    return ret_val;
}


/* -------------------------------------------------------------------------- */
/* --------------------- Public Non-Virtual Methods ------------------------- */
/* -------------------------------------------------------------------------- */

/* Documented in header */
void azt_code_simple_gobject_set_value(AztCodeSimpleGObject *self,
                                       const guint value)
{
    if (self != NULL)
    {
        AztCodeSimpleGObjectPrivate *priv =\
            AZT_CODE_SIMPLE_GOBJECT_GET_PRIVATE(self);
        
        priv->_value = value;
    }
}



/* -------------------------------------------------------------------------- */
/* ------------------------------ Constructor ------------------------------- */
/* -------------------------------------------------------------------------- */

/* Documented in header */
AztCodeSimpleGObject *
azt_code_simple_gobject_new(guint value)
{
    AztCodeSimpleGObject *obj = NULL;

    obj =\
        (AztCodeSimpleGObject *)g_object_new(AZT_CODE_SIMPLE_GOBJECT_TYPE, NULL);

    if(obj != NULL)
    {
        AZT_CODE_SIMPLE_GOBJECT_GET_CLASS(obj)->initialize(obj, value);
    }
    return obj;
}


/* End of azt_code_simple_gobject.c */
