/**
 *  @file       azt_code_simple_gobject.h
 *  @brief      <<DESCRIPTION>>
 *
 *  @author     <<AUTHOR>>
 *  @date       <<DATE>>
 *
 *  @defgroup	AztCodeSimpleGObjectGObject AztCodeSimpleGObject API
 *  @brief	    Definition of the AztCodeSimpleGObject API
 *
 *  @ingroup    AztCodeHeaderTemplate
 */
/* <<COPYRIGHT>> */


#ifndef __AZT_CODE_SIMPLE_GOBJECT_H__
#define __AZT_CODE_SIMPLE_GOBJECT_H__

#include <glib.h>
#include <glib-object.h>

G_BEGIN_DECLS

/*------------------ GObject standard boilerplate code ---------------------- */

#define AZT_CODE_SIMPLE_GOBJECT_TYPE \
    (azt_code_simple_gobject_get_type ())

#define AZT_CODE_SIMPLE_GOBJECT(obj) \
    (G_TYPE_CHECK_INSTANCE_CAST ((obj),\
                                 AZT_CODE_SIMPLE_GOBJECT_TYPE,\
                                 AztCodeSimpleGObject))

#define AZT_CODE_SIMPLE_GOBJECT_CLASS(klass) \
    (G_TYPE_CHECK_CLASS_CAST ((klass),\
                              AZT_CODE_SIMPLE_GOBJECT_TYPE,\
                              AztCodeSimpleGObjectClass))

#define IS_AZT_CODE_SIMPLE_GOBJECT(obj)\
    (G_TYPE_CHECK_INSTANCE_TYPE ((obj),\
                                 AZT_CODE_SIMPLE_GOBJECT_TYPE))

#define IS_AZT_CODE_SIMPLE_GOBJECT_CLASS(klass)\
    (G_TYPE_CHECK_CLASS_TYPE ((klass), AZT_CODE_SIMPLE_GOBJECT_TYPE))

#define AZT_CODE_SIMPLE_GOBJECT_GET_CLASS(obj)\
    (G_TYPE_INSTANCE_GET_CLASS ((obj),\
                                AZT_CODE_SIMPLE_GOBJECT_TYPE,\
                                AztCodeSimpleGObjectClass))

/* ---------------- GObject Class Native Definitions ---------------------- */

/** @typedef AztCodeSimpleGObject
 *  @brief  Definition of a GObject object type
 *
 *  @ingroup AztCodeSimpleGObjectGObject
 */
typedef struct _AztCodeSimpleGObject      AztCodeSimpleGObject;


/*
 * Definition of AztCodeSimpleGObject Class
 */
typedef struct _AztCodeSimpleGObjectClass AztCodeSimpleGObjectClass;

struct _AztCodeSimpleGObjectClass
{
    /* Parent class                                                           */
    GObjectClass parent_class;

    /* Pointers to virtual methods                                            */
    gboolean (*initialize)(AztCodeSimpleGObject *self,
                           const guint value);

    /* ... */

    /* End of pointer to virtual methods                                      */
};

/*
 * Structure defining instance of AztCodeSimpleGObject
 */
struct _AztCodeSimpleGObject
{
    /** Parent object */
    GObject parent;
    /** Private data pointer */
    gpointer priv;
};


/*
 * Returns GObject type
 */
GType azt_code_simple_gobject_get_type (void);

/*  -------------- End of GObject Class Native Definitions ------------------ */


/* -------------------------------------------------------------------------- */
/* ----------------------------- Public API --------------------------------- */
/* -------------------------------------------------------------------------- */

/**
 * @brief  Function used for creating a new instance of AztCodeSimpleGObject
 *         And initialize it with proper value
 *
 * @param[in]  value Integer initializer
 *
 * @return Pointer to a new instance of an object
 *
 * @ingroup AztCodeSimpleGObjectGObject
 */
AztCodeSimpleGObject *
azt_code_simple_gobject_new(guint value);

/**
 * @brief  Destroy AztCodeSimpleGObject object
 *
 * @param[in]  self Pointer to current instance of an object
 *
 * @ingroup AztCodeSimpleGObjectGObject
 */
#define azt_code_simple_gobject_destroy(self) \
    g_object_unref(self)


/* ----------------------- Public Non-Virtual Methods ---------------------- */

/**
 * @brief Non-virtual value setter
 * 
 * @param Pointer to current instance of AztCodeSimpleGObject
 * @param value Value to be assigned to GObject member
 *
 * @ingroup AztCodeSimpleGObjectGObject
 */
void azt_code_simple_gobject_set_value(AztCodeSimpleGObject *self,
                                       const guint value);

/* ... */


/* ----------------------- Public Virtual Methods -------------------------- */

/**
 * @brief Initialize GObject after creation 
 * 
 * @param self[in] Pointer to current instance of AztCodeSimpleGObject
 * @param value[in] Value used for initialization
 *
 * @return TRUE if success otherwise FALSE
 *
 * @ingroup AztCodeSimpleGObjectGObject
 */
static inline gboolean
azt_code_simple_gobject_initialize(AztCodeSimpleGObject *self,
                                   guint value)
{
    return (AZT_CODE_SIMPLE_GOBJECT_GET_CLASS(self)->initialize(self,
                                                                value));
}

/* ... */


G_END_DECLS
#endif /* __AZT_CODE_SIMPLE_GOBJECT__H_ */

/* End of azt_code_simple_gobject.h */
