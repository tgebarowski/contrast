/**
 *  @file       azt_code_simple_object.h
 *  @brief      <<DESCRIPTION>>
 *
 *  @author     <<AUTHOR>>
 *  @date       <<DATE>>
 *
 *  @defgroup	AztCodeSimpleObjectObject AztCodeSimpleObject API
 *  @brief	    Definition of the AztCodeSimpleObject API
 *
 *  @ingroup    AztCodeHeaderTemplate
 */
/* <<COPYRIGHT>> */


#ifndef __AZT_CODE_SIMPLE_OBJECT_H__
#define __AZT_CODE_SIMPLE_OBJECT_H__

/**
 *  @typedef AztCodeSimpleObject
 *  @brief  Definition of a AztCodeSimpleObject
 *
 */
typedef struct _AztCodeSimpleObject AztCodeSimpleObject;

/* -------------------------------------------------------------------------- */
/* ------------------------------- Public API ------------------------------- */
/* -------------------------------------------------------------------------- */

/* ------------------------ Constructor & Destructor ------------------------ */

/**
 * @brief  Function used for creating a new instance of AztCodeSimpleObject
 * @return New instance of Object or NULL if failed
 *
 * @ingroup AztCodeSimpleObjectObject
 */
AztCodeSimpleObject *
azt_code_simple_object_new(guint value);

/**
 * @brief  Function to destroy AztCodeSimpleObject
 * @param  self Pointer to current instance of an object
 *
 * @ingroup AztCodeSimpleObjectObject
 */
void
azt_code_simple_object_destroy(AztCodeSimpleObject *self);


/* ----------------------------- Public Methods ----------------------------- */

/**
 * @brief Value setter
 *
 * @param[in] self Pointer to current instance of the object
 * @param[in] value Value to be assigned to object
 *
 * @return
 * 
 * @ingroup AztCodeSimpleObjectObject
 */
void azt_code_simple_object_set_value(AztCodeSimpleObject *self,
                                      const guint value);

#endif /* __AZT_CODE_SIMPLE_OBJECT_H__ */

/* End of azt_code_simple_object.h */




