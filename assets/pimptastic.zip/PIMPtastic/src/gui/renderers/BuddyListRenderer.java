/*
 * BuddyListRenderer.java
 *
 * Created on June 3, 2007, 12:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package gui.renderers;

import data_objects.BuddyDO;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.ListCellRenderer;
import misc.ImageFactory;
import misc.TextFactory;
import pimptastic.config.Appearance;

/**
 * Class changing render behavior of BuddyList
 * @author Tomasz Gebarowski
 * @author Wiktor Kotecki
 */
public class BuddyListRenderer extends JPanel implements ListCellRenderer {

    private final JLabel imageLabel;
    private final JLabel nickLabel;
    private final JLabel descLabel;
    private final JPanel descPanel;
    private final JTextPane textPane;
    
    public BuddyListRenderer () {

            //this.setSize(100,30);
        
            imageLabel = new JLabel();
            nickLabel = new JLabel();
            descLabel = new JLabel();
            descPanel = new JPanel();
            textPane = new JTextPane();
            
            descLabel.setFont( new Font("Verdana", Font.PLAIN,11));
            nickLabel.setFont( new Font("Verdana", Font.PLAIN,16));
            
            descPanel.setLayout(new BorderLayout());
            descPanel.add(nickLabel, BorderLayout.NORTH);
            descPanel.add(descLabel, BorderLayout.SOUTH);
            
            
            setLayout(new BorderLayout() );
            
            textPane.insertComponent(descPanel);
            textPane.insertComponent(imageLabel);
            
            add(textPane);
            
    }
    
    private void selectedItem() {
        textPane.setBackground(Appearance.getBuddyListBackColorSel());
        textPane.setForeground(Appearance.getBuddyListForeColorSel());
        descPanel.setBackground(Appearance.getBuddyListBackColorSel());
    }
    
    private void notSelectedItem() {
        textPane.setBackground(Appearance.getBuddyListBackColor());
        textPane.setForeground(Appearance.getBuddyListForeColor()); 
        descPanel.setBackground(Appearance.getBuddyListBackColor());
        
    }

    public Component getListCellRendererComponent(JList list, Object value,  int index, boolean isSelected, boolean cellHasFocus) {

                //TODO: Possible move it outside the renderer so that images don't have to be generated every render event
                
                // Assume user is offline
                ImageIcon buddyImage = ImageFactory.getImage("buddyStatusUnavailable", this);
                
                if (isSelected)
                    selectedItem();
                else
                    notSelectedItem();
               
                
                if (value instanceof BuddyDO) {
                    
                    String status =  ((BuddyDO)value).getStatus();

                    if (status.equals(TextFactory.getText("buddyStatusAvailable")) )
                        buddyImage = ImageFactory.getImage("buddyStatusAvailable", this);
                    else if (status.equals(TextFactory.getText("buddyStatusBusy")) )
                        buddyImage = ImageFactory.getImage("buddyStatusBusy", this);
                    else if (status.equals(TextFactory.getText("buddyStatusAway")) )
                        buddyImage = ImageFactory.getImage("buddyStatusAway", this);     
                    else if (status.equals(TextFactory.getText("buddyStatusCustom")) )
                        buddyImage = ImageFactory.getImage("buddyStatusCustom", this);   
                    else if (status.equals(TextFactory.getText("buddyStatusBRB")) )
                        buddyImage = ImageFactory.getImage("buddyStatusBRB", this); 
                    else if (status.equals(TextFactory.getText("buddyStatusShopping")) )
                        buddyImage = ImageFactory.getImage("buddyStatusShopping", this);                    
                    else if (status.equals(TextFactory.getText("buddyStatusSurfing")) )
                        buddyImage = ImageFactory.getImage("buddyStatusSurfing", this);                     
                    else if (status.equals(TextFactory.getText("buddyStatusMusic")) )
                        buddyImage = ImageFactory.getImage("buddyStatusMusic", this);                     
                    else if (status.equals(TextFactory.getText("buddyStatusBreak")) )
                        buddyImage = ImageFactory.getImage("buddyStatusBreak", this);
                  
                    String content = ((BuddyDO)value).getContent(); 
                    
                    nickLabel.setText(((BuddyDO)value).getNick() );        
                    
                    imageLabel.setIcon(buddyImage);
                    
                    if ( content == null )
                        content = "\n";
                        
                    descLabel.setText(content);        
                 
                }
    
                 return this;
    }
    
    
}
