/*
 * BuddyListRenderer.java
 *
 * Created on June 3, 2007, 12:59 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package gui.renderers;

import data_objects.ChatMessageDO;
import data_objects.ErrorMessageDO;
import java.awt.Component;
import java.awt.Font;
import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.JList;
import misc.ImageFactory;
import pimptastic.config.Appearance;

/**
 * Class changing render behavior of BuddyList
 * @author Tomasz Gebarowski
 * @author Wiktor Kotecki
 */
public class ChatMessageListRenderer   extends DefaultListCellRenderer {
    
   
    @Override
    /** Overloaded getListCallRendererComponent from DefaultListCellRenderer class */
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
		// Let superclass deal with most of it...
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                
                
                ImageIcon img = ImageFactory.getImage("msgOut", this);
                
                
                if (value instanceof ErrorMessageDO ) {
                        img = ImageFactory.getImage("msgError",this);
                } else if ( value instanceof ChatMessageDO ) {
                    
                    if ( ((ChatMessageDO)value).isIncoming()) {
                        img = ImageFactory.getImage("msgIn", this);
                    }
                }

                setIcon(img);
          
                Font textFont = new Font("Verdana", Font.PLAIN, 16);
                this.setFont(textFont);
                this.setText( getTextContent((ChatMessageDO)value, list.getWidth() - img.getIconWidth() - 6));    

		return this;
    }
    
    public String getTextContent(ChatMessageDO chatDO, int width) {
        String foreColor;
        String backColor;
        
        if (chatDO instanceof ErrorMessageDO) {
            foreColor = Appearance.colorToString(Appearance.getErrorMsgForeColor());
            backColor = Appearance.colorToString(Appearance.getErrorMsgBackColor());
        } else if  (chatDO.isIncoming() ) {
            foreColor = Appearance.colorToString(Appearance.getIncomingMsgForeColor());
            backColor = Appearance.colorToString((Appearance.getIncomingMsgBackColor()));
        } else {
            foreColor = Appearance.colorToString(Appearance.getSentMsgForeColor());
            backColor = Appearance.colorToString((Appearance.getSentMsgBackColor()));
        }
        
        
        Font messageFont = Appearance.getMessageFont();
        
        String fontTag = "<font face='" + messageFont.getFamily() +"' color='"+ foreColor +"' size='"+ messageFont.getSize()+"pt'>";
        String htmlMessage =  "<html><body width='" + width + "' bgcolor='"+ backColor +"'>"+ fontTag +"<b>" + chatDO.getSenderNick() + "</b>&nbsp;" +  Appearance.getMsgFieldSeparator() + "&nbsp;" + chatDO.getContent() +"</font></body></html>";  
        return htmlMessage;
    }
    
    
}
