/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.visual_objects;

import data_objects.BuddyDO;
import gui.MainWindow;
import gui.widgets.BuddyListBox;
import java.util.Collections;
import java.util.Vector;
import java.util.logging.Logger;
import pimptastic.PIMPtastic;

/**
 *
 * @author tomaszgebarowski
 */
public class SelectedBuddiesVO {
    
    private Vector<BuddyDO> selectedBuddies;
    
    
    public SelectedBuddiesVO(Object[] selBuddiesArr) {
            selectedBuddies = new Vector();
            
            for(int i = 0; i < selBuddiesArr.length; i++) {
                Object current = selBuddiesArr[i];
                if ( current instanceof BuddyDO) {
                    selectedBuddies.add((BuddyDO)current);
                }
            }
    }
    
    /**Create Buddy Set from Vector of ID's - User in message delivery
     * 
     */ 
    public SelectedBuddiesVO(Vector<Integer> rcptIdVct, int sender_id, int my_id) {
            selectedBuddies = new Vector();
            MainWindow mainWindow = PIMPtastic.getInstance().getMainWindow();
      
            BuddyListBox buddyListBox = mainWindow.getBuddyListBox();
            
            for(Integer id: rcptIdVct) {          
                if ( id instanceof Integer) {
                    
                    //Replace my ID with Sender ID
                    if ( id.intValue() == my_id)
                        id = new Integer(sender_id);
                    
                    selectedBuddies.add(( buddyListBox.getBuddyDO(id.intValue())));
                }
            }
    }
    
    public SelectedBuddiesVO(Vector<BuddyDO> selectedBuddies) {
        this.selectedBuddies = selectedBuddies;
                
    }
    
    public Vector<Integer> getIdVector() {
        
        Vector idVct = new Vector();
        
        for( BuddyDO buddy: selectedBuddies) {
            Integer id = buddy.getBuddyId();
            idVct.add(id);
        }
        
        return idVct;
    }
   
    public Vector<BuddyDO> getSelectedBuddiesVct() {
        
        return this.selectedBuddies;
    }
    
    public String toHash() {
        
        if (selectedBuddies == null )
        {
            Logger.getLogger("logger").warning("SelectedBuddies is null");
            return "";
        }
        
        Collections.sort(selectedBuddies);
        
        String hashedValue = "";
        
        for(BuddyDO value: selectedBuddies) {
            hashedValue += (String.valueOf(value.getBuddyId()) + "#");
        }
        
        return hashedValue;
    }
    
    public String getTabCaption() {
        
        Collections.sort(selectedBuddies);
        
        String hashedValue = "";
        
        for(BuddyDO value: selectedBuddies) {
            hashedValue += " " + (value.getNick());
        }
        
        return hashedValue;
    }

}
