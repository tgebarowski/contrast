/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.visual_objects;

import javax.swing.ImageIcon;

/**
 *
 * @author tomaszgebarowski
 */
public class StatusComboItemVO {
    
    private String statusName;
    private String statusContent;
    private ImageIcon imageIcon;
    
    
    
    public StatusComboItemVO(String statusName, ImageIcon imageIcon, String content) {
        this.statusName = statusName;
        this.imageIcon = imageIcon;
        this.statusContent = content;
    }
    
    
    public StatusComboItemVO(String statusName, ImageIcon imageIcon) {
        this.statusName = statusName;
        this.imageIcon = imageIcon;
        this.statusContent = "";
    }

    public String getStatusName() {
        return statusName;
    }

    public ImageIcon getImageIcon() {
        return imageIcon;
    }
    
    @Override
    public String toString() {
        return statusName;
    }

    public String getStatusContent() {
        return statusContent;
    }

    public void setStatusContent(String statusContent) {
        this.statusContent = statusContent;
    }

    public void setImageIcon(ImageIcon imageIcon) {
        this.imageIcon = imageIcon;
    }

}
