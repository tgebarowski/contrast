/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.widgets;

import data_objects.BuddyDO;
import gui.dialogs.SearchBuddyDialog;
import gui.visual_objects.SelectedBuddiesVO;
import gui.renderers.BuddyListRenderer;
import gui.widgets.BuddyListBox;
import gui.widgets.BuddyListBox;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.JMenuItem;
import misc.TextFactory;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyChatListBox extends BuddyListBox implements ActionListener {
    
    public BuddyChatListBox() {
        this.setCellRenderer(new BuddyListRenderer());
    }


    public void setBuddyListDO(SelectedBuddiesVO selectedBuddiesDO) {
        
        Vector<BuddyDO> buddiesVct =  selectedBuddiesDO.getSelectedBuddiesVct();
         this.setListData(buddiesVct);
    }
    
    @Override
    protected void addMenuItems() {
        JMenuItem menuItem = new JMenuItem(TextFactory.getText("popupBuddyInfo"));
        menuItem.addActionListener(this);
        this.buddyPopupMenu.add(menuItem);
    }
    
    @Override
    public void actionPerformed(ActionEvent event) {
        Object obj = this.getSelectedValue();
        
        if ( obj instanceof BuddyDO ) {
            BuddyDO buddyDO = (BuddyDO)obj;
            int buddyId = buddyDO.getBuddyId();
            String nick = buddyDO.getNick();
            SearchBuddyDialog searchBuddyDialog = new SearchBuddyDialog(buddyId, nick);
            searchBuddyDialog.setVisible(true);
        }
        
    }

}
