/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.widgets;

import data_objects.BuddyDO;
import data_objects.BuddyListDO;
import data_objects.UserStatusDO;
import gui.ChatMessageWindow;
import gui.dialogs.RemoveBuddyDialog;
import gui.listeners.PopUpMenuListener;
import gui.renderers.BuddyListRenderer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.logging.Logger;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import misc.TextFactory;
import pimptastic.PIMPtastic;
import protocol.Communicator;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyListBox extends JList implements ActionListener {

    protected BuddyListDO buddyListDO;
    private Communicator imInstance;
    private PIMPtastic appInstance;  
    protected JPopupMenu buddyPopupMenu;

    public BuddyListBox() {
        
        this.setCellRenderer(new BuddyListRenderer());
        appInstance = PIMPtastic.getInstance();
        imInstance = PIMPtastic.getCommunicator();
        
        imInstance.sendBuddyListRequest();
        createPopUpMenu();
        
        
        
    }
    
    private void createPopUpMenu() {
        
        buddyPopupMenu = new JPopupMenu();
        MouseListener popupMouseListener = new PopUpMenuListener(buddyPopupMenu);
        this.addMouseListener(popupMouseListener);    
        this.addMenuItems();
    }
    
    protected void addMenuItems() {
        JMenuItem menuItem = new JMenuItem(TextFactory.getText("popupRemoveBuddy"));
        menuItem.setActionCommand("Remove");
        menuItem.addActionListener(this);        
        this.buddyPopupMenu.add(menuItem);
        
        menuItem = new JMenuItem(TextFactory.getText("popupRefreshBuddyList"));
        menuItem.setActionCommand("Refresh");
        menuItem.addActionListener(this);                
        this.buddyPopupMenu.add(menuItem);
    }
    
    public void setBuddyListDO(BuddyListDO buddyListDO) {
        this.buddyListDO = buddyListDO;
        this.loadContentFromDO();
    }
    
    /**
     * Updates buddy status depending on UserStatusDO object
     * @param userStatusDO
     */
    public void updateBuddyStatusDO(UserStatusDO userStatusDO) {
        
        Logger.getLogger("logger").info("Updating buddy status: " + userStatusDO.getUserid() + "-> "+ userStatusDO.getStatus() );
        
        ChatMessageWindow chatWindow = PIMPtastic.getInstance().getMainWindow().getChatMessageWindow();
        
        int userId = userStatusDO.getUserid();
        String status = userStatusDO.getStatus();
        String content = userStatusDO.getContent();
        
        for (BuddyDO buddy: buddyListDO.getBuddyVct()) {
            if (buddy.getBuddyId() == userId ) {
                buddy.setStatus(status);
                buddy.setContent(content);
                //Update All List Boxes with this buddy in ChatMessageWindow
                chatWindow.updateBuddyChatListBoxes(buddy);
            }
        }
        loadContentFromDO();
        
        
    }
    
    public BuddyDO getBuddyDO(int id) {
        for( BuddyDO buddy: buddyListDO.getBuddyVct() ) {
            if ( buddy.getBuddyId() == id )
                return buddy;
        }
        
        return new BuddyDO(id,"Unknown", "", "");
    }
    
    protected void loadContentFromDO() {
        
        this.setListData(this.buddyListDO.getBuddyVct());
        
    }
    
    
    public void actionPerformed(ActionEvent event) {
       
        String commandType = event.getActionCommand();
     
        if ( commandType.equals("Remove"))
            removeBuddyFromListAction();
        else if ( commandType.equals("Refresh")) {
            imInstance.sendBuddyListRequest();
        }
        
    }
    
    
    private void removeBuddyFromListAction() {
        Object obj = this.getSelectedValue();
        
        if ( obj instanceof BuddyDO) {
        
            final BuddyDO buddyDO = (BuddyDO)obj;
            java.awt.EventQueue.invokeLater(new Runnable() {
                 public void run() {
                    new RemoveBuddyDialog(buddyDO).setVisible(true); 
                 }
            });
        }   
        
    }

}
