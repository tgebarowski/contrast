/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.widgets;

import gui.visual_objects.StatusComboItemVO;
import gui.renderers.StatusComboBoxRenderer;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import misc.ImageFactory;
import misc.TextFactory;

/**
 *
 * @author tomaszgebarowski
 */



public class StatusComboBox extends JComboBox {
    
    private Vector<StatusComboItemVO> statusModesVct = new Vector();
    
    private StatusComboItemVO currentStatus;

    public StatusComboBox() {
        
        StatusComboItemVO availableStatusVO = this.getStatusComboItemVOByName(TextFactory.getText("buddyStatusAvailable"));

        statusModesVct.add( availableStatusVO );  
        statusModesVct.add( this.getStatusComboItemVOByName(TextFactory.getText("buddyStatusAway")));
        statusModesVct.add( this.getStatusComboItemVOByName(TextFactory.getText("buddyStatusBusy")));
        statusModesVct.add( this.getStatusComboItemVOByName(TextFactory.getText("buddyStatusBRB")));
        statusModesVct.add( this.getStatusComboItemVOByName(TextFactory.getText("buddyStatusBreak")));
        statusModesVct.add( this.getStatusComboItemVOByName(TextFactory.getText("buddyStatusCustom")));
        statusModesVct.add( this.getStatusComboItemVOByName(TextFactory.getText("buddyStatusUnavailable")));

        
        this.setModel(new DefaultComboBoxModel(statusModesVct));       
        this.setRenderer(new StatusComboBoxRenderer());
        
        this.setCurrentStatus(availableStatusVO);
        
    }
    
    
    public StatusComboItemVO getCurrentStatus() {
        return this.currentStatus;
    }
    
    public void setCurrentStatus(StatusComboItemVO status ) {
        this.currentStatus = status;
    }
    
    public StatusComboItemVO getStatusComboItemVOByName(String name) {
            StatusComboItemVO status = new StatusComboItemVO(name, null);
        
             if ( name.equals(TextFactory.getText("buddyStatusBusy")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusBusy",this));
            else if ( name.equals(TextFactory.getText("buddyStatusAvailable")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusAvailable",this));
            else if ( name.equals(TextFactory.getText("buddyStatusAway")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusAway",this));
            else if ( name.equals(TextFactory.getText("buddyStatusCustom")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusCustom",this));   
            else if ( name.equals(TextFactory.getText("buddyStatusUnavailable")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusUnavailable",this));  
            else if ( name.equals(TextFactory.getText("buddyStatusBRB")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusBRB",this));  
            else if ( name.equals(TextFactory.getText("buddyStatusBreak")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusBreak",this));  
            else if ( name.equals(TextFactory.getText("buddyStatusMusic")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusMusic",this));  
            else if ( name.equals(TextFactory.getText("buddyStatusShopping")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusShopping",this));       
            else if ( name.equals(TextFactory.getText("buddyStatusSurfing")))
                status.setImageIcon(ImageFactory.getImage("buddyStatusSurfing",this));  
            
            
            return status;
    }
            
    
    
    /**
     * Select a ComboBox item which is placed in currentStatus field
     */
    public void loadCurrentState() {
        this.setSelectedItem(this.currentStatus);
    }


}
