/*
 * TabPopupListener.java
 *
 * Created on June 3, 2007, 3:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package gui.listeners;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPopupMenu;

/**
 * Pop Up Menu listener used to retrieve popup menu actions
 * @author Tomasz Gebarowski
 */

public class PopUpMenuListener extends MouseAdapter {
    
    private JPopupMenu popup;
    
    public PopUpMenuListener(JPopupMenu popup ) {
        this.popup = popup;
    }
    
    public void mousePressed(MouseEvent e) {
        maybeShowPopup(e);
    }

    public void mouseReleased(MouseEvent e) {
        maybeShowPopup(e);
    }

    /**
     * Check if allowed to display popup menu
     * Displays it if allowed
     */
    private void maybeShowPopup(MouseEvent e) {
        if (e.isPopupTrigger()) {
            popup.show(e.getComponent(), e.getX(), e.getY());
        }
    }
}