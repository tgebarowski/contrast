/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import data_objects.UserAccountDO;
import java.io.OutputStream;
import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class UserAddRequestWrapper extends UserModifyRequestWrapper {

    private static String tagPassword = "password";
            
    /*<message type="userAddRequest">
     <user><nick></nick>
           <name></name>
           <surname></surname>
           <birthday>YYYY-MM_DD</birthday>
           <place></place>
           <country></country>
           <password></password>
     </user></message>
    */
    
    
    public UserAddRequestWrapper(UserAccountDO userAccountDO) {
        
        super(userAccountDO);
        this.password = userAccountDO.getPassword();
        
    }
    
    
    @Override
    public String toXML()  {    
    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "userAddRequest");

        
        Element userElement = xmlDocument.createElement(tagUser);       
        rootElement.appendChild(userElement);
        
        
        Element nickElement = xmlDocument.createElement(tagNick);
        nickElement.appendChild(xmlDocument.createTextNode(this.nick));

        Element nameElement = xmlDocument.createElement(tagName);
        nameElement.appendChild(xmlDocument.createTextNode(this.name));
        
        Element surnameElement = xmlDocument.createElement(tagSurname);
        surnameElement.appendChild(xmlDocument.createTextNode(this.surname));
        
        Element placeElement = xmlDocument.createElement(tagPlace);
        placeElement.appendChild(xmlDocument.createTextNode(this.place));
        
        Element countryElement = xmlDocument.createElement(tagCountry);
        countryElement.appendChild(xmlDocument.createTextNode(this.country));
        
        Element birthdayElement = xmlDocument.createElement(tagBirthday);
        birthdayElement.appendChild(xmlDocument.createTextNode(this.birthday));
        
        Element passwordElement = xmlDocument.createElement(tagPassword);
        passwordElement.appendChild(xmlDocument.createTextNode(this.password));        
        
        userElement.appendChild(nickElement);
        userElement.appendChild(nameElement);
        userElement.appendChild(surnameElement);
        userElement.appendChild(placeElement);
        userElement.appendChild(countryElement);
        userElement.appendChild(birthdayElement);
        userElement.appendChild(passwordElement);
                
        return serializeToXML();


    }
    
    //TODO: Try to move this to ServerRequestWrapper
    private String serializeToXML() {
     
        try {
            OutputStream stream = new java.io.ByteArrayOutputStream();
            XMLSerializer serializer = new XMLSerializer();
            serializer.setOutputByteStream(stream);
            serializer.serialize(xmlDocument);
            return stream.toString().replaceAll("\n", " ");
        
        } catch (Exception e ) { return null; }    
    }

}
