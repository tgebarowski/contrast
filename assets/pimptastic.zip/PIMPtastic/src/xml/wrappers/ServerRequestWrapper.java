/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.OutputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;

/**
 *
 * @author tomaszgebarowski
 */
public class ServerRequestWrapper implements IRequestWrapper {
    
    protected Document xmlDocument;
    protected static String attrType = "type";
    protected static String attrRcpt = "rcpt_id";
    protected static String attrSeqNum = "seq_num";
    
    private static String tagMessage = "message";
    
    
    public ServerRequestWrapper()  {
        
        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            DOMImplementation domImpl = documentBuilder.getDOMImplementation();
            
            xmlDocument = domImpl.createDocument(null,tagMessage, null);
            xmlDocument.setXmlVersion("1.0");
            
        } catch ( ParserConfigurationException e ) {
            e.printStackTrace();
        }
    }
    
    public String toXML() {
        
        try {
            OutputStream stream = new java.io.ByteArrayOutputStream();
            XMLSerializer serializer = new XMLSerializer();
            serializer.setOutputByteStream(stream);
            serializer.serialize(xmlDocument);
            return stream.toString().replaceAll("\n", " ");
        
        } catch (Exception e ) { return null; }    
          
    }
    
    

}
