/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.OutputStream;
import javax.xml.*;
import javax.xml.parsers.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class InitRequestWrapper extends ServerRequestWrapper implements IRequestWrapper  {
    
    private String username, password;
    
    /** <message type="init"><user></user><password></password></message> **/    
    private static String attrType = "type";
    private static String tagUser = "user";
    private static String tagPass = "password";
    

    public InitRequestWrapper(String username, String password) {
        super();
        this.username = username;
        this.password = password;
        
    }
    
    @Override
    public String toXML()  {    
    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "init");
 
        Element userElement = xmlDocument.createElement(tagUser);        
        userElement.appendChild(xmlDocument.createTextNode(this.username));
        
        Element passElement = xmlDocument.createElement(tagPass);
        passElement.appendChild(xmlDocument.createTextNode(this.password));
        
        rootElement.appendChild(userElement);
        rootElement.appendChild(passElement);
                
        return super.toXML();


    }
            
    
    
    
}
