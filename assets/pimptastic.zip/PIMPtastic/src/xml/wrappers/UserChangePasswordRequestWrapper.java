/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class UserChangePasswordRequestWrapper  extends ServerRequestWrapper implements IRequestWrapper  {

    private long seq_num;
    private int rcpt_id;
    private String oldPassword;
    private String newPassword;
    private final String tagPassword = "password";
    private final String tagNew = "new";
    private final String tagOld = "old";
    
    public UserChangePasswordRequestWrapper(int rcpt_id, long seq_num, String oldPassword, String newPassword) {
        this.oldPassword = oldPassword;
        this.newPassword = newPassword;
        this.seq_num = seq_num;
        this.rcpt_id = rcpt_id;
    }
    
    @Override
    public String toXML()  {    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "userChangePasswordRequest");
        rootElement.setAttribute(attrRcpt, String.valueOf(this.rcpt_id));
        rootElement.setAttribute(attrSeqNum, String.valueOf(this.seq_num));
        
        Element passwordElement = xmlDocument.createElement(tagPassword);       
   
        Element oldElement = xmlDocument.createElement(tagOld);
        oldElement.appendChild(xmlDocument.createTextNode(oldPassword));
        
        Element newElement = xmlDocument.createElement(tagNew);
        newElement.appendChild(xmlDocument.createTextNode(newPassword));        
        
        passwordElement.appendChild(newElement);
        passwordElement.appendChild(oldElement);
        
        rootElement.appendChild(passwordElement);
        
        return super.toXML();


    }
    
    
}
