/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import data_objects.UserInfoDO;
import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class UserInfoRequestWrapper  extends ServerRequestWrapper implements IRequestWrapper {
    
    private int userid, rcpt_id;
    private long seq_num;
    private String nick, name,surname,place,country,birthday,password,year;
    
    private static String tagId = "id";
    private static String tagUser = "user";
    private static String tagNick = "nick";
    private static String tagName = "name";
    private static String tagSurname = "surname";  
    private static String tagBirthday = "birthday";
    private static String tagYear = "year";
    private static String tagPlace = "place";
    private static String tagCountry = "country";
    
    
    /* <message rcpt_id="" seq_num="" type="userInfoRequest">
     <user><name></name><surname></surname></user>
     </message> */
    
    
    public UserInfoRequestWrapper(UserInfoDO userDO) {
        this(
                userDO.getRcptId(),
                userDO.getSeqNum(),
                userDO.getId(),
                userDO.getNick(),
                userDO.getName(),
                userDO.getSurname(),
                userDO.getPlace(),
                userDO.getCountry(),
                userDO.getBirthday(),
                userDO.getYearOfBirth()
         );


    }
    
    public UserInfoRequestWrapper(int rcpt_id, long seq_num, int userid, String nick, String name, String surname, String place, String country, String birthday, int year) {
        super();
        this.rcpt_id = rcpt_id;
        this.seq_num = seq_num;
        this.userid = userid;
        this.nick = nick; this.name = name; this.surname = surname;
        this.place = place; this.country = country; this.birthday = birthday;
        
        //Conver Year of birth into string format
        if (year == 0 )
            this.year = "";
        else
            this.year = String.valueOf(year);
        
    }
    
    public String toXML()  {    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "userLookUpRequest");

        
        Element userElement = xmlDocument.createElement(tagUser);       
        
        rootElement.setAttribute(attrRcpt, String.valueOf(this.rcpt_id));
        rootElement.setAttribute(attrSeqNum, String.valueOf(this.seq_num));
        rootElement.appendChild(userElement);
        
        if (this.userid != -1 ) {
            Element idElement = xmlDocument.createElement(tagId);
            idElement.appendChild(xmlDocument.createTextNode(String.valueOf(this.userid)));
            userElement.appendChild(idElement);
        }
        
        if (this.nick.length() > 0 ) {
            Element nickElement = xmlDocument.createElement(tagNick);
            nickElement.appendChild(xmlDocument.createTextNode(this.nick));
            userElement.appendChild(nickElement);
        }
        if (this.name.length() > 0 ) {
            Element nameElement = xmlDocument.createElement(tagName);
            nameElement.appendChild(xmlDocument.createTextNode(this.name));
            userElement.appendChild(nameElement);
        }
        if (this.surname.length() > 0) {
            Element surnameElement = xmlDocument.createElement(tagSurname);
            surnameElement.appendChild(xmlDocument.createTextNode(this.surname));
            userElement.appendChild(surnameElement);
        }
        if (this.place.length() > 0 ) {
            Element placeElement = xmlDocument.createElement(tagPlace);
            placeElement.appendChild(xmlDocument.createTextNode(this.place));
            userElement.appendChild(placeElement);
        }
        if (this.country.length() > 0 ) {
            Element countryElement = xmlDocument.createElement(tagCountry);
            countryElement.appendChild(xmlDocument.createTextNode(this.country));
            userElement.appendChild(countryElement);
        }
        if (this.birthday.length() > 0 ) {
            Element birthdayElement = xmlDocument.createElement(tagBirthday);
            birthdayElement.appendChild(xmlDocument.createTextNode(this.birthday));
            userElement.appendChild(birthdayElement);
        }   
        
        if (this.year.length() > 0 ) {
            Element yearElement = xmlDocument.createElement(tagYear);
            yearElement.appendChild(xmlDocument.createTextNode(this.year));
            userElement.appendChild(yearElement);
        }   
        
        return super.toXML();


    }

}
