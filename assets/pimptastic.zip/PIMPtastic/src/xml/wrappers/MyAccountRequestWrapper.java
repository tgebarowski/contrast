/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class MyAccountRequestWrapper  extends ServerRequestWrapper implements IRequestWrapper {

    
    private int rcpt_id;
    private long seq_num;
    
    /*<message rcpt_id="" seq_num="" type="buddyListRequest"/>*/
    

    
    public MyAccountRequestWrapper(int rcpt_id, long seq_num) {
        
        super();
        this.rcpt_id = rcpt_id;
        this.seq_num = seq_num;       
    }
    
    
    @Override
    public String toXML()  {    
        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "myAccountRequest");
        rootElement.setAttribute(attrRcpt, String.valueOf(this.rcpt_id));
        rootElement.setAttribute(attrSeqNum, String.valueOf(this.seq_num));
                
        return super.toXML();


    }
    
    
}
