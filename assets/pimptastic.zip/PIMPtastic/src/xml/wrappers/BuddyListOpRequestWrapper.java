/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import data_objects.BuddyListOpDO;
import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyListOpRequestWrapper   extends ServerRequestWrapper implements IRequestWrapper  {
    
    private static String tagBuddy ="buddy";
    private static String attrBuddyId = "id";
    private static String attrMode = "mode";
    
    private BuddyListOpDO buddyListOpDO;
    
    
    /**<message rcpt_id="1" seq_num="90" type="buddyListOpRequest"><buddy id="1" mode="add|remove"/></message>
     * 
     */
    public BuddyListOpRequestWrapper(BuddyListOpDO buddyListOpDO) {
        
        super();
        this.buddyListOpDO = buddyListOpDO;
    }
    
    
    @Override
    public String toXML()  {    
    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "buddyListOpRequest");
        rootElement.setAttribute(attrRcpt, String.valueOf(buddyListOpDO.getRcptId()));
        rootElement.setAttribute(attrSeqNum, String.valueOf(buddyListOpDO.getSeqNum()));
        
        Element buddyElement = xmlDocument.createElement(tagBuddy);
        buddyElement.setAttribute(attrBuddyId, String.valueOf(buddyListOpDO.getBuddyId()) );
        buddyElement.setAttribute(attrMode, buddyListOpDO.getMode() );
        
        rootElement.appendChild(buddyElement);        
        
        return super.toXML();
    }

}
