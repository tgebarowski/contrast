/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import data_objects.UserAccountDO;
import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class UserModifyRequestWrapper extends ServerRequestWrapper implements IRequestWrapper  {
    
    protected String nick, name,surname,place,country,birthday,password;
    
    
    protected static String attrRcptId ="rcpt_id";
    protected static String tagUser = "user";
    protected static String tagNick = "nick";
    protected static String tagName = "name";
    protected static String tagSurname = "surname";  
    protected static String tagBirthday = "birthday";
    protected static String tagPlace = "place";
    protected static String tagCountry = "country";
            
    /*<message type="userModifyRequest">
     <user><nick></nick>
           <name></name>
           <surname></surname>
           <birthday>YYYY-MM_DD</birthday>
           <place></place>
           <country></country>
     </user></message>
    */
    
    
    public UserModifyRequestWrapper(UserAccountDO userAccountDO) {
        
        super();
        this.nick = userAccountDO.getNick();
        this.name = userAccountDO.getName();
        this.surname = userAccountDO.getSurname();
        this.birthday = userAccountDO.getBirthday();
        this.place = userAccountDO.getPlace();
        this.country = userAccountDO.getCountry();        
    }

    
    @Override
    public String toXML()  {    
    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "userModifyRequest");

        
        Element userElement = xmlDocument.createElement(tagUser);       
        rootElement.appendChild(userElement);
        
        
        Element nickElement = xmlDocument.createElement(tagNick);
        nickElement.appendChild(xmlDocument.createTextNode(this.nick));

        Element nameElement = xmlDocument.createElement(tagName);
        nameElement.appendChild(xmlDocument.createTextNode(this.name));
        
        Element surnameElement = xmlDocument.createElement(tagSurname);
        surnameElement.appendChild(xmlDocument.createTextNode(this.surname));
        
        Element placeElement = xmlDocument.createElement(tagPlace);
        placeElement.appendChild(xmlDocument.createTextNode(this.place));
        
        Element countryElement = xmlDocument.createElement(tagCountry);
        countryElement.appendChild(xmlDocument.createTextNode(this.country));
        
        Element birthdayElement = xmlDocument.createElement(tagBirthday);
        birthdayElement.appendChild(xmlDocument.createTextNode(this.birthday));
                
        userElement.appendChild(nickElement);
        userElement.appendChild(nameElement);
        userElement.appendChild(surnameElement);
        userElement.appendChild(placeElement);
        userElement.appendChild(countryElement);
        userElement.appendChild(birthdayElement);
                
        return super.toXML();


    }

}
