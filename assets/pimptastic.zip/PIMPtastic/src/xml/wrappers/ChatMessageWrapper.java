/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import data_objects.ChatMessageDO;
import java.util.Vector;
import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class ChatMessageWrapper  extends ServerRequestWrapper implements IRequestWrapper {

    private long seq_num;
    private int sender_id;
    private String content;
    private Vector<Integer> rcptIdVct;
    
    private static String tagRcpt ="rcpt";
    private static String tagContent = "content";
    private static String attrSenderId = "sender_id";
    private static String attrId ="id";
    
    
    /* <message sender_id="" seq_num="" type="chat"><rcpt id=""/><rcpt id=""/><content></content></message> */       
    public ChatMessageWrapper(Vector rcptIdVct, long seq_num, int sender_id, String content) {
        super();
        this.rcptIdVct = rcptIdVct;
        this.seq_num = seq_num;
        this.sender_id = sender_id;
        this.content = content;        
    }
    
    public ChatMessageWrapper(ChatMessageDO chatMsgDO) {
        super();
        this.sender_id = chatMsgDO.getSenderId();
        this.seq_num = chatMsgDO.getSeqNum();
        this.content = chatMsgDO.getContent();
        this.rcptIdVct = chatMsgDO.getRcptIdList();
    }
    
    @Override
    public String toXML()  {    
    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "chat");
        rootElement.setAttribute(attrSenderId, String.valueOf(this.sender_id));
        rootElement.setAttribute(attrSeqNum, String.valueOf(this.seq_num));
        
 
        for (Integer rcpt_id: rcptIdVct) {
            Element rcptElement = xmlDocument.createElement(tagRcpt);
            rcptElement.setAttribute(attrId,String.valueOf(rcpt_id));
            rootElement.appendChild(rcptElement);
        }
        
        Element contentElement = xmlDocument.createElement(tagContent);
        contentElement.appendChild(xmlDocument.createTextNode(this.content));
        
        rootElement.appendChild(contentElement);
                
        return super.toXML();


    }
    
}
