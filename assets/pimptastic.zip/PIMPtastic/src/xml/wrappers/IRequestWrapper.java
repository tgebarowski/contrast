/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import javax.xml.parsers.ParserConfigurationException;

/**
 *
 * @author tomaszgebarowski
 */
public interface IRequestWrapper {

    public String toXML();
    
}
