/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml.wrappers;

import org.w3c.dom.Element;

/**
 *
 * @author tomaszgebarowski
 */
public class StatusChangeRequestWrapper extends ServerRequestWrapper implements IRequestWrapper   {
    
    private int rcpt_id;
    private long seq_num;
    private String status,content;
    
    private static String tagUser = "user";
    private static String tagStatus = "status";
    private static String tagId = "id";
    private static String tagContent = "content";
    
    /*
     * <message rcpt_id="" seq_num="" type="userStatusChangedRequest">
       <user><id></id>
       <status></status>
       <content></content></user>
       </message>
     */
    public StatusChangeRequestWrapper(int rcpt_id, long seq_num, String status, String content) {
        
        super();
        
        this.rcpt_id = rcpt_id;
        this.seq_num = seq_num;
        this.status = status;
        this.content = content;

    }
    
    @Override
    public String toXML()  {    

        Element rootElement = xmlDocument.getDocumentElement();
        rootElement.setAttribute(attrType, "userStatusChangedRequest");
        rootElement.setAttribute(attrRcpt, String.valueOf(this.rcpt_id));
        rootElement.setAttribute(attrSeqNum, String.valueOf(this.seq_num));

        
        Element userElement = xmlDocument.createElement(tagUser);
        rootElement.appendChild(userElement);
        
        Element idElement = xmlDocument.createElement(tagId);
        idElement.appendChild(xmlDocument.createTextNode(String.valueOf(this.rcpt_id)));
        userElement.appendChild(idElement);
        
        Element statusElement = xmlDocument.createElement(tagStatus);
        statusElement.appendChild(xmlDocument.createTextNode(this.status));
        userElement.appendChild(statusElement);
        
        if ( content.length() > 0 ) {
            Element contentElement = xmlDocument.createElement(tagContent);
            contentElement.appendChild(xmlDocument.createTextNode(this.content));        
            userElement.appendChild(contentElement);
        }
        
        return super.toXML();


    }
 
    
    

}
