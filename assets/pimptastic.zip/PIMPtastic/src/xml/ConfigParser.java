/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml;

import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import pimptastic.config.Appearance;
import pimptastic.config.PIMPConfig;

/**
 *
 * @author tomaszgebarowski
 */
public class ConfigParser {
    
    
    private final String typeIncomingMessage = "incomingMessage";
    private final String typeSentMessage = "sentMessage";
    private final String typeErrorMessage = "errorMessage";
    private final String typeBuddyItem = "buddyItem";
    private final String typeBuddyItemSel = "buddyItemSel";
    private final String typeForeground = "foreground";
    private final String typeBackground = "background";
    
    private final static String tagConfig = "config";
    private final static String tagHostname = "hostname";
    private final static String tagPort = "port";
    private final static String tagLanguage = "language";
    private final static String tagObject = "object";
    private final static String tagColor = "color";
    private final static String tagAppearance = "appearance";
    private final static String attrType = "type";
    
    private Document xmlDocument;
    private String fileName;

    public ConfigParser(String fileName) {
        try {
            
            this.fileName = fileName;

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);

            DocumentBuilder db = dbf.newDocumentBuilder();

            xmlDocument = db.parse(new File(fileName));
            
        } catch (SAXException ex) {
            Logger.getLogger(ConfigParser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ConfigParser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(ConfigParser.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void load() throws Exception {
        loadGeneralConfig();
        loadAppearanceConfig();
    }
    
    
    public void write() {
        writeGeneralConfig();
        writeAppearanceConfig();
        
        try {
            OutputStream stream = new java.io.FileOutputStream(new File(fileName));
            XMLSerializer serializer = new XMLSerializer();
            serializer.setOutputByteStream(stream);
            serializer.serialize(xmlDocument);
            stream.flush();
            
        } catch (Exception e ) {e.printStackTrace();}   
    }


    
    private void loadGeneralConfig() throws Exception {
        
        String hostname = null;
        int port = -1;
        String language = null;
        
        NodeList hostnameTagList = xmlDocument.getElementsByTagName(tagHostname);
        if ( hostnameTagList != null ) {
            hostname = hostnameTagList.item(0).getFirstChild().getNodeValue();
        }
        
        NodeList portTagList = xmlDocument.getElementsByTagName(tagPort);
        if ( portTagList != null ) {
            port = Integer.valueOf(portTagList.item(0).getFirstChild().getNodeValue());
        }
        
        NodeList languageTagList = xmlDocument.getElementsByTagName(tagLanguage);
        if ( languageTagList != null ) {
            language = languageTagList.item(0).getFirstChild().getNodeValue();
        }
        
        if (hostname == null || port == -1 || language == null ) {
            throw new Exception();
        }
        
        
        PIMPConfig.setHostname(hostname);
        PIMPConfig.setPort(port);
        PIMPConfig.setLanguage(language);
        
        Logger.getLogger("logger").info("Hostname:" + hostname + " port: " + port + " language:" + language);
    }
    
    private void loadAppearanceConfig() throws Exception {
        
        NodeList objectTagList = xmlDocument.getElementsByTagName(tagObject);
        for(int pos = 0; pos < objectTagList.getLength(); pos++) {
            Node nObject = objectTagList.item(pos);

            NamedNodeMap attrMap = nObject.getAttributes();

            Node attr = attrMap.getNamedItem(attrType);

            String typeValue = attr.getNodeValue();
            NodeList colorTagList = nObject.getChildNodes();
            processColors(colorTagList,typeValue);

        }
    }
    
    
    /**
     * 
     * Function parsing and processing color values from XML file
     * @param colorTagList
     * @param objType
     * @param saveMode Determines if functon is executed for the Save purpose or Load
     */
    private void processColors(NodeList colorTagList, String objType) {
        
        String typeValue = "";
        
        for(int pos = 0; pos < colorTagList.getLength(); pos++) {
            Node nColor = colorTagList.item(pos);
            if (nColor.hasAttributes() && nColor.hasChildNodes()) {
                NamedNodeMap attrMap = nColor.getAttributes();
                Node attr = attrMap.getNamedItem(attrType);
                typeValue = attr.getNodeValue();
                
                String colorValue = nColor.getTextContent();

                loadColors(objType, typeValue, colorValue);
            }
        }
  
    }
    
    private void loadColors(String objType, String colorType, String colorValue) {

        
        
        
        if (objType.equals(typeIncomingMessage)) {
            
            if (colorType.equals(typeForeground) && colorValue.length() > 0) {
                Appearance.setIncomingMsgForeColor(new Color(Integer.parseInt((colorValue))));
            } else if  (colorType.equals(typeBackground) && colorValue.length() > 0)  {
                Appearance.setIncomingMsgBackColor(new Color(Integer.parseInt((colorValue))));
            }
            
        }
        
        else if (objType.equals(typeSentMessage)) {
            
            if (colorType.equals(typeForeground) && colorValue.length() > 0) {
                Appearance.setSentMsgForeColor(new Color(Integer.parseInt((colorValue))));
            } else if  (colorType.equals(typeBackground) && colorValue.length() > 0)  {
                Appearance.setSentMsgBackColor(new Color(Integer.parseInt((colorValue))));
            }          
        }
        
        else if (objType.equals(typeBuddyItem)) {
            
            if (colorType.equals(typeForeground) && colorValue.length() > 0) {
                Appearance.setBuddyListForeColor(new Color(Integer.parseInt((colorValue))));
            } else if  (colorType.equals(typeBackground) && colorValue.length() > 0)  {
                Appearance.setBuddyListBackColor(new Color(Integer.parseInt((colorValue))));
            }            
        }
        
        else if (objType.equals(typeBuddyItemSel)) {
            
            if (colorType.equals(typeForeground) && colorValue.length() > 0) {
                Appearance.setBuddyListForeColorSel(new Color(Integer.parseInt((colorValue))));
            } else if  (colorType.equals(typeBackground) && colorValue.length() > 0)  {
                Appearance.setBuddyListBackColorSel(new Color(Integer.parseInt((colorValue))));
            }            
        }
        
        else if (objType.equals(typeErrorMessage)) {
            
            if (colorType.equals(typeForeground) && colorValue.length() > 0) {
                Appearance.setErrorMsgForeColor(new Color(Integer.parseInt((colorValue))));
            } else if  (colorType.equals(typeBackground) && colorValue.length() > 0)  {
                Appearance.setErrorMsgBackColor(new Color(Integer.parseInt((colorValue))));
            }          
        }
        
        
    }
    
    
    private void writeGeneralConfig() {
     
        
        NodeList hostnameTagList = xmlDocument.getElementsByTagName(tagHostname);
        if ( hostnameTagList != null ) {
            hostnameTagList.item(0).getFirstChild().setNodeValue(PIMPConfig.getHostname());
        }
        
        NodeList portTagList = xmlDocument.getElementsByTagName(tagPort);
        if ( portTagList != null ) {
            portTagList.item(0).getFirstChild().setNodeValue(String.valueOf(PIMPConfig.getPort()));
        }
        
        NodeList languageTagList = xmlDocument.getElementsByTagName(tagLanguage);
        if ( languageTagList != null ) {
            languageTagList.item(0).getFirstChild().setNodeValue(PIMPConfig.getLanguage());
        }   
    }
    
    private void writeAppearanceConfig() {

        //Remove All nodes
        Node nConfig = xmlDocument.getElementsByTagName(tagConfig).item(0);
        Node nAppearance = xmlDocument.getElementsByTagName(tagAppearance).item(0);
        
        nConfig.removeChild(nAppearance);
        
        Element rootElement = xmlDocument.getDocumentElement();       
        Element appearanceElement = xmlDocument.createElement(tagAppearance);       
        rootElement.appendChild(appearanceElement);
        
        //Create Object Elements
        Node nObject = createObjectTag(typeIncomingMessage, Appearance.getIncomingMsgForeColor(), Appearance.getIncomingMsgBackColor());
        appearanceElement.appendChild(nObject);
        
        nObject = createObjectTag(typeSentMessage, Appearance.getSentMsgForeColor(), Appearance.getSentMsgBackColor());
        appearanceElement.appendChild(nObject);
 
        nObject = createObjectTag(typeErrorMessage, Appearance.getErrorMsgForeColor(), Appearance.getErrorMsgBackColor());
        appearanceElement.appendChild(nObject);
        
        nObject = createObjectTag(typeBuddyItem, Appearance.getBuddyListForeColor(), Appearance.getBuddyListBackColor());
        appearanceElement.appendChild(nObject);
        
        nObject = createObjectTag(typeBuddyItemSel, Appearance.getBuddyListForeColorSel(), Appearance.getBuddyListBackColorSel());
        appearanceElement.appendChild(nObject);
    }

    
    private Node createObjectTag(String objectType, Color fgColorValue, Color bgColorValue) throws DOMException {

        Element objectElement = xmlDocument.createElement(tagObject);
        objectElement.setAttribute(attrType, objectType);

        Element colorElement = xmlDocument.createElement(tagColor);
        colorElement.setAttribute(attrType, typeForeground);
        colorElement.setTextContent(String.valueOf(fgColorValue.getRGB()));
        objectElement.appendChild(colorElement);

        colorElement = xmlDocument.createElement(tagColor);
        colorElement.setAttribute(attrType, typeBackground);
        colorElement.setTextContent(String.valueOf(bgColorValue.getRGB()));
        objectElement.appendChild(colorElement);
        
        return objectElement;
    }
    


}
