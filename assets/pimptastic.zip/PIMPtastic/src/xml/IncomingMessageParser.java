/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package xml;

import java.io.StringReader;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import data_objects.*;
import java.util.Vector;
import protocol.IncomingMessageHandler;
/**
 *
 * @author tomaszgebarowski
 */
public class IncomingMessageParser {

    private String xmlMessage;
    private Document xmlDocument;
    
    private long seq_num;
    private int rcpt_id;
    private int sender_id;
    private String attrType;
    
    private NamedNodeMap tagMessageAttrMap;
    private Node tagMessage;
    
    
    public IncomingMessageParser(String xmlMessage) {
        this.xmlMessage = xmlMessage;
        
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        // Turn on validation, and turn off namespaces
        factory.setValidating(false);
      
        factory.setNamespaceAware(false);
        

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            this.xmlDocument = builder.parse(new InputSource(new StringReader(xmlMessage)));
        } catch ( Exception e ) {
            Logger.getLogger("logger").warning("Exception in XML Parser: " + e.getMessage());
        }        
    }
    
    public DataObject process() {
     
        parseMessageHeader();
        
        DataObject resultDO = null;

        if ( attrType.equals("ack") ) {
            resultDO = processAck();
        } else if ( attrType.equals("failure")) {
            resultDO = processFailure();
        } else if ( attrType.equals("chat")) {
            resultDO = processChatMessage();
        } else if ( attrType.equals("buddyList")) {
            resultDO = processBuddyList();
        } else if ( attrType.equals("userinfo")) {
            resultDO = processUserInfo();
        } else if ( attrType.equals("userStatusChanged")) {
            resultDO = processUserStatusChanged();
        } else if ( attrType.equals("authorization" )) {
            resultDO = processAuthorization();
        } else if ( attrType.equals("userAccount")) {
            resultDO = processUserInfo();
        }
        
        if ( resultDO != null ) {
            IncomingMessageHandler imHandler = new IncomingMessageHandler(resultDO);
            imHandler.handle();
        }

        return resultDO;
    }
    
    public DataObject processAuthorization() {
        String state = tagMessage.getFirstChild().getNodeValue();
        return new AuthorizationDO(seq_num,rcpt_id,state);
        
    }
    

    public DataObject processUserStatusChanged() {
        
        int id = -1;
        String status = "";
        String content = "";
        
        Logger.getLogger("logger").info("User Status Changed Message processing");
        
        
        NodeList idTagList = xmlDocument.getElementsByTagName("id");
        if ( idTagList != null ) {
            id = Integer.parseInt(idTagList.item(0).getFirstChild().getNodeValue());
        }
        
        
        NodeList statusTagList = xmlDocument.getElementsByTagName("status");
        if ( statusTagList != null ) {
            status = statusTagList.item(0).getFirstChild().getNodeValue();
        }
              
        NodeList contentTagList = xmlDocument.getElementsByTagName("content");
        if ( contentTagList.getLength() != 0) {
            content = contentTagList.item(0).getFirstChild().getNodeValue();
        }

        
        /*TODO: Check what with <user> tag  - perhaps missing on a server side*/
        return new UserStatusDO(id,seq_num,status,content);
    }
    
    
    private DataObject processUserInfo() {
        
        int id = -1;
        String nick = "", name = "", surname = "", birthday = "", place = "", country = "";
        String privilage = null;
        
        
        NodeList idTagList = xmlDocument.getElementsByTagName("id");
        if ( idTagList.getLength() > 0 ) {
            id = Integer.parseInt(idTagList.item(0).getFirstChild().getNodeValue());
        }
        
        
        NodeList nickTagList = xmlDocument.getElementsByTagName("nick");
        if ( nickTagList.getLength() > 0 ) {
            nick = nickTagList.item(0).getFirstChild().getNodeValue();
        }
        
                
        NodeList nameTagList = xmlDocument.getElementsByTagName("name");
        if ( nameTagList.getLength() > 0) {
            name = nameTagList.item(0).getFirstChild().getNodeValue();
        }
        
                
        NodeList surnameTagList = xmlDocument.getElementsByTagName("surname");
        if ( surnameTagList.getLength() > 0 ) {
            surname = surnameTagList.item(0).getFirstChild().getNodeValue();
        }
        
                
        NodeList birthdayTagList = xmlDocument.getElementsByTagName("birthday");
        if ( birthdayTagList.getLength() > 0 ) {
            birthday = birthdayTagList.item(0).getFirstChild().getNodeValue();
        }
        
        NodeList yearTagList = xmlDocument.getElementsByTagName("year");
        if ( yearTagList.getLength() > 0 ) {
            birthday = yearTagList.item(0).getFirstChild().getNodeValue();
        }
        
                
        NodeList placeTagList = xmlDocument.getElementsByTagName("place");
        if ( placeTagList.getLength() > 0 ) {
            place = placeTagList.item(0).getFirstChild().getNodeValue();
        }
        
        NodeList countryTagList = xmlDocument.getElementsByTagName("country");
        if ( countryTagList.getLength() > 0 ) {
            country = countryTagList.item(0).getFirstChild().getNodeValue();
        }
        
        NodeList privilageTagList = xmlDocument.getElementsByTagName("privilage");
        if ( privilageTagList.getLength() > 0 ) {
            privilage = privilageTagList.item(0).getFirstChild().getNodeValue();  
        }
        
        
        if ( privilage != null )
            return new UserAccountDO(seq_num, rcpt_id, id, nick, name, surname, birthday, place, country,"", privilage);
        
        return new UserInfoDO(seq_num, rcpt_id, id, nick, name, surname, birthday, place, country);
        
        
        
    }
    
    private DataObject processBuddyList() {
        
        NodeList buddyTagList = xmlDocument.getElementsByTagName("buddy");
        
        if (buddyTagList == null)
                return null;
        
        int id = -1;
        String status = "";
        
        int sizeList = buddyTagList.getLength();
        
        BuddyListDO buddyListDO = new BuddyListDO(this.seq_num, this.rcpt_id);
        
        for( int i = 0; i < sizeList; i++) {
            Node buddyNode = buddyTagList.item(i);
            NamedNodeMap attrMap = buddyNode.getAttributes();
            Node idNode = attrMap.getNamedItem("id");
            Node statusNode = attrMap.getNamedItem("status");
            
            if (idNode != null) {
                id = Integer.parseInt(idNode.getNodeValue());
            }
            
            if (statusNode != null ) {
                status = statusNode.getNodeValue();
            }
            
            String nick = buddyNode.getFirstChild().getNodeValue();
            
            BuddyDO currentBuddy = new BuddyDO(id,nick,status, null);
            buddyListDO.addBuddyDO(currentBuddy);
        }
        return buddyListDO;        
    }
    
    private DataObject processFailure() {
        
        String content = tagMessage.getFirstChild().getNodeValue();
        
        return new ConfirmationMessageDO(this.seq_num, this.rcpt_id, content);
        
    }
    
    
    private DataObject processAck() {
            return new ConfirmationMessageDO(this.seq_num, this.rcpt_id);
    }

    private DataObject processChatMessage() {
        
        Vector<Integer> rcptVct = new Vector();

        String content = xmlDocument.getElementsByTagName("content").item(0).getFirstChild().getNodeValue();
        NodeList rcptTagList = xmlDocument.getElementsByTagName("rcpt");

        for (int i = 0; i < rcptTagList.getLength(); i++) {
            
            Node rcptTag = rcptTagList.item(i);
            
            if (rcptTag != null ) {
                NamedNodeMap map = rcptTag.getAttributes();
                Node idNode = map.getNamedItem("id");
                if ( idNode != null ) {
                    rcptVct.add(new Integer(idNode.getNodeValue()));
                }
            }
        }
        
        ChatMessageDO chDO = new ChatMessageDO(rcpt_id, rcptVct, sender_id, content, true);
        System.out.println(chDO);
        
        return chDO;
    }

    
    private void parseMessageHeader() {
        NodeList messageTagList = xmlDocument.getElementsByTagName("message");
        
        tagMessage = messageTagList.item(0);
        tagMessageAttrMap = tagMessage.getAttributes();
        
        
        attrType = tagMessageAttrMap.getNamedItem("type").getNodeValue();

        Node n = tagMessageAttrMap.getNamedItem("seq_num");
        
        if ( n != null ) {
            this.seq_num = Long.parseLong(n.getNodeValue());
        }
        
        n = tagMessageAttrMap.getNamedItem("rcpt_id");
        
        if ( n != null ) {
            this.rcpt_id = Integer.parseInt(n.getNodeValue());
        }
        
                
        n = tagMessageAttrMap.getNamedItem("sender_id");
        
        if ( n != null ) {
            this.sender_id = Integer.parseInt(n.getNodeValue());
        }
        
        
    }
    
}
