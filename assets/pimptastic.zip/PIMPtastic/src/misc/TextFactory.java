/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package misc;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import pimptastic.config.PIMPConfig;
/**
 *
 * @author tomaszgebarowski
 */
public class TextFactory {
    
    private static String baseName = "pimp";
    private static Pattern localePattern = Pattern.compile("(^[a-z]{2})(_([A-Z]{2})){0,1}$");    
    private static ResourceBundle resourceBundle = null;

    
    public static String getText(String name) {
        
        if (resourceBundle == null ) {
            Locale locale = getLocale(PIMPConfig.getLanguage());
            resourceBundle = ResourceBundle.getBundle(baseName,locale);

        }
        
        
        return resourceBundle.getString(name);
    }
    
    
    public static Locale getLocale(String ident) {
	Locale locale = null;
	Matcher m = localePattern.matcher(ident);
	if (m.find()) {
		locale = (m.group(3) == null)? new Locale(m.group(1)):new Locale(m.group(1),m.group(3));
	}
	return locale;
    }
    
    /**TODO: Reimplement me
     * Temporary solution - returns static available locales - predefined
     * @return
     */
    public static Vector<Locale> getAvailableLocales() {
        
        Vector<Locale> locales = new Vector<Locale>();
        locales.add(new Locale("en", "US"));
        locales.add(new Locale("pl", "PL"));
        
        return locales;
    }
    
    /*
    public static Vector<Locale> getAvailableLocales() {
	Pattern bundleFilePattern = Pattern.compile("^"+ baseName +"_([a-z]{2}(_([A-Z]{2})){0,1}).properties$");
	Vector<Locale> locales = new Vector<Locale>();
        String fPath = ResourceBundle.class.getClass().getResource("/").getPath();
        Logger.getLogger("logger").info(fPath);
	String[] bundles = new File(fPath).list();
	for (int i = 0; i < bundles.length; i++) {
		Matcher m = bundleFilePattern.matcher(bundles[i]);
		if (m.find()) {
			locales.add(getLocale(m.group(1)));
		}
	}
	return locales;
    }*/
    

}
