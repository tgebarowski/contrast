/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package misc;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author tomaszgebarowski
 */
public class Validators {
    
    private static Validators instance = null;
    
    
    private Validators() {
        
    }
    
    
    public static Validators getInstance() {
        
        if (instance == null ) {
            instance = new Validators();
        }
        
        return instance;
    }
    
    public boolean validateDate(String date) {

        String[] bits = date.split("-");

        if (bits.length != 3)
            return false;
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
        Calendar cal = Calendar.getInstance();
        cal.set(Integer.parseInt(bits[0]),Integer.parseInt(bits[1])-1,Integer.parseInt(bits[2]));
        
        if(sdf.format(cal.getTime()).equals(date))
            return true;
        
        return false;
    }
    
    
    
    
    
    
    

}
