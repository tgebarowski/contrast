/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package misc;

import java.awt.Dimension;
import java.awt.Image;
import java.util.HashMap;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

/**
 *
 * @author tomaszgebarowski
 */
public class ImageFactory extends Object {

    public static ImageIcon getImage(String imgName, JComponent parent ) {
        
        String imgPath = ResourceBundle.getBundle("img").getString(imgName);
        return getImageIconFromFile(imgPath,parent);
        
    }
    
    public static ImageIcon getImageIconFromFile(String imageFile, JComponent parent) {
        ImageIcon imageIcon = new ImageIcon(parent.getClass().getResource(imageFile));
	Image image = imageIcon.getImage();
	Dimension dimension = parent.getPreferredSize();
	double height = dimension.getHeight();
        double width = (height / imageIcon.getIconHeight()) * imageIcon.getIconWidth();
	image = image.getScaledInstance((int)width, (int)height, Image.SCALE_SMOOTH);
	ImageIcon finalIcon = new ImageIcon(image);
        
        return finalIcon;
    }
    

}
