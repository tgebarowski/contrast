/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 * Ack Data Object used for storing Ack messages in AckList
 * @author tomaszgebarowski
 */
public class ArbitraryDO extends DataObject {
    
    private long timeStamp;
    private DataObject sourceObject;
    
    public ArbitraryDO(long seq_num, DataObject sourceObject) {
        super(seq_num,-1);
        this.sourceObject = sourceObject;
        this.timeStamp = System.currentTimeMillis();       
    }

    public long getTimeStamp() {
        return timeStamp;
    }
    
    public DataObject getSourceObject() {
        return this.sourceObject;
    }
    
    

}
