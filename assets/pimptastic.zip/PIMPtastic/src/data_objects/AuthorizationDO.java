/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 *
 * @author tomaszgebarowski
 */
public class AuthorizationDO extends DataObject {
    
    private String state;
    
    public AuthorizationDO(long seq_num, int rcpt_id, String state) {
        super(seq_num, rcpt_id);
        this.state = state;
    }
    
    public boolean isAck() {        
        return state.equals("ok");
    }
    
    public boolean isFailure() {
        return state.equals("failure");
    }
    
    public boolean isAlreadyLogged() {
        return state.equals("already_logged");
    }

}
