/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

import javax.swing.ImageIcon;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyDO implements Comparable {
    
    private int buddyId;
    private String nick;
    private String status;
    private String content;

    
    
    public BuddyDO(int buddyId, String nick, String status, String content) {
        this.buddyId = buddyId;
        this.nick = nick;
        this.status = status;
        this.content = content;
    }

    
    public void setBuddyId(int buddyId) {
        this.buddyId = buddyId;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public void setContent(String content) {
        this.content = content;
    }

    public int getBuddyId() {
        return buddyId;
    }

    public String getNick() {
        return nick;
    }

    public String getStatus() {
        return status;
    }
    
    public String getContent() {
        return content;
    }
    
    public String toString() {
        return nick;
    }

    public int compareTo(Object o) {
	BuddyDO tmp = (BuddyDO) o;
	return Integer.valueOf(this.getBuddyId()).compareTo(tmp.getBuddyId());
    }     
    

}
