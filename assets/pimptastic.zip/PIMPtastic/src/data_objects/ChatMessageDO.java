/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

import java.util.Vector;
import pimptastic.PIMPtastic;

/**
 *
 * @author tomaszgebarowski
 */
public class ChatMessageDO  extends DataObject  {
    
    protected Vector<Integer> rcptIdList;
    protected  int sender_id;
    protected  String content;
    protected  String senderNick = "";
    private  boolean isIncoming;
    

    
    public ChatMessageDO(int rcpt_id, Vector<Integer> rcptIdList, int sender_id, String content, boolean isIncoming) {
        super(-1,rcpt_id);
        this.sender_id = sender_id;
        this.content = content;
        this.rcptIdList = rcptIdList;
        this.isIncoming = isIncoming;
        
        BuddyDO senderBuddyDO = PIMPtastic.getInstance().getMainWindow().getBuddyListBox().getBuddyDO(sender_id);
        
        this.senderNick = senderBuddyDO.getNick();
    }
    
    public ChatMessageDO(int rcpt_id, Vector<Integer> rcptIdList, int sender_id, String content) {
        super(-1,rcpt_id);
        this.sender_id = sender_id;
        this.content = content;
        this.rcptIdList = rcptIdList;
        this.isIncoming = false;       
        this.senderNick = PIMPtastic.getCommunicator().getLogin();
    }
    
    public void setContent(String content) {
        
        this.content = content;
    }
    
    public String getContent() {
        return this.content;
    }
    
    public int getSenderId() {
        return this.sender_id;
    }
    
    public Vector getRcptIdList() {
        return this.rcptIdList;
    }
    
    public long getSeqNum() {
        return this.seq_num;
    }
    
    public boolean isIncoming() {
        return this.isIncoming;
    }
    
    public String getSenderNick() {
        return this.senderNick;
    }
    
    @Override
    public String toString() {
        return getSeqNum() + " " + getSenderId() + " " + getRcptIdList() + " " + getContent();
    }


}
