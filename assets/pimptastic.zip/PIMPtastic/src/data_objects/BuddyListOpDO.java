/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyListOpDO extends DataObject {
    
    private int buddyId;
    private String mode;
    
    public BuddyListOpDO(long seq_num, int rcpt_id, int buddyId, String mode) {
        super(seq_num,rcpt_id);
        this.buddyId = buddyId;
        this.mode = mode;
    }

    public int getBuddyId() {
        return buddyId;
    }

    public void setBuddyId(int buddyId) {
        this.buddyId = buddyId;
    }


    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }
      
    
}
