/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 *
 * @author tomaszgebarowski
 */
public class ConfirmationMessageDO  extends DataObject  {
    
    private String state;
    private String content;
    
    public ConfirmationMessageDO(long seq_num, int rcpt_id, String content) {
        super(seq_num,rcpt_id);
        this.content = content;
        this.state = "Failure";
    }
    
    public ConfirmationMessageDO(long seq_num, int rcpt_id) {
        super(seq_num,rcpt_id);
        this.content = null;
        this.state = "Ack";
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    
    public boolean isAck() {
        return state.equals("Ack");
    }
    
    @Override
    public String toString() {
        return seq_num + " " + state + "  " + content;
    
    }

}
