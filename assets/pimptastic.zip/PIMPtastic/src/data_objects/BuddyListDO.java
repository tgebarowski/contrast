/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

import java.util.Vector;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyListDO  extends DataObject  {
    
    private Vector buddyVct;
    
    public BuddyListDO(long seq_num, int rcpt_id, Vector buddyVct) {
        super(seq_num,rcpt_id);
        this.buddyVct = buddyVct;
        this.seq_num = seq_num;
    }
    
    public BuddyListDO(long seq_num, int rcpt_id) {
        super(seq_num,rcpt_id);
        this.buddyVct = new Vector();
    }
    
    public void addBuddyDO(BuddyDO buddy) {
        if ( buddyVct != null )
        {
            buddyVct.add(buddy);
        }
    }

    public void removeBuddyDO(BuddyDO buddy) {
        if ( buddyVct != null )
        {
            buddyVct.remove(buddy);
        }    
    }
    
    public Vector<BuddyDO> getBuddyVct()
    {
        return buddyVct;        
    }
    
    @Override
    public String toString() 
    {
        return buddyVct.toString();
    
    }
    

}
