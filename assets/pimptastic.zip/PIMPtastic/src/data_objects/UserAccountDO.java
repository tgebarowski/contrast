/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 *
 * @author tomaszgebarowski
 */
public class UserAccountDO extends UserInfoDO {
    
    private String password;
    private String privilage;
    
    public UserAccountDO(long seq_num, int rcpt_id, int id, String nick, String name, String surname, String birthday, String place, String country, String password, String privilage)
    {
        super(seq_num, rcpt_id, id,nick,name,surname,birthday,place,country);
        this.password = password;
        this.privilage = privilage;
        
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPrivilage() {
        return privilage;
    }

    public void setPrivilage(String privilage) {
        this.privilage = privilage;
    }

}
