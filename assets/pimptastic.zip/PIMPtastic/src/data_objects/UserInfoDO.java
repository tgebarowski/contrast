/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 *
 * @author tomaszgebarowski
 */
public class UserInfoDO  extends DataObject  {
    
    private int id;
    private String nick;
    private String name;
    private String surname;
    private String birthday;
    private int yearOfBirth;
    private String place;
    private String country;

    public UserInfoDO(long seq_num, int rcpt_id, int id, String nick, String name, String surname, String birthday, String place, String country) {
        super(seq_num, rcpt_id);
        this.id = id;
        this.nick = nick;
        this.name = name;
        this.surname = surname;
        this.birthday = birthday;
        this.yearOfBirth = 0;
        this.place = place;
        this.country = country;
    }
    
    public UserInfoDO(long seq_num, int rcpt_id, int id, String nick, String name, String surname, int yearOfBirth, String place, String country) {
        super(seq_num, rcpt_id);
        this.id = id;
        this.nick = nick;
        this.name = name;
        this.surname = surname;
        this.birthday = "";
        this.yearOfBirth = yearOfBirth;
        this.place = place;
        this.country = country;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    @Override
    public String toString() {
       
        return this.id + " " + this.name + " " + this.surname + " " + this.nick + " " + this.place + " " + this.getCountry() + " " + this.birthday;
        
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }
    
    

}
