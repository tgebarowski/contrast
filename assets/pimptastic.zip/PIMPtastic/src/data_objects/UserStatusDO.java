/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 *
 * @author tomaszgebarowski
 */
public class UserStatusDO extends DataObject {
    
    private int userid;
    private String status;
    private String content;
    
    
    
    public UserStatusDO(int userid, long seq_num, String status, String content ) {
        super(seq_num, userid);
        this.userid = userid;
        this.status = status;
        this.content = content;
    }
    
    public int getUserid() {
        return this.userid;
    }
    
    public String getStatus() {
        return this.status;
    }
    

    
    public String getContent() {
        return this.content;
    }
    
    
    @Override
    public String toString() {
        return this.userid + " " + this.status + " " + this.seq_num + " " + this.content;
    }

}
