/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package data_objects;

/**
 *
 * @author tomaszgebarowski
 */
public class DataObject {
    
    protected long seq_num;
    protected int rcpt_id;
    
    public DataObject(long seq_num, int rcpt_id) {
        this.seq_num = seq_num;
        this.rcpt_id = rcpt_id;
    }
    
    public long getSeqNum() {
        return this.seq_num;
    }
    
    public int getRcptId() {
        return this.rcpt_id;    
    }
    
    public void setSeqNum(long seq_num) {
        this.seq_num = seq_num;
    }
    
    public void setRcptId(int rcpt_id) {
        this.rcpt_id = rcpt_id;
    }

}
