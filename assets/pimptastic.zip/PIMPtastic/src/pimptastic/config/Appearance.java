/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pimptastic.config;

import java.awt.Color;
import java.awt.Font;

/**
 *
 * @author tomaszgebarowski
 */
public class Appearance {

    private static Color incomingMsgBackColor = new Color(255,255,218);
    private static Color incomingMsgForeColor = new Color(0,0,0) ;
    private static Color sentMsgBackColor = new Color(188,207,231);
    private static Color sentMsgForeColor = new Color(62,62,57);
    private static Color errorMsgBackColor = new Color(188,111,23);
    private static Color errorMsgForeColor = new Color(0,0,0);
    
    private static Color buddyListForeColor = new Color(0,0,0);
    private static Color buddyListBackColor = new Color(233,240,244);
    private static Color buddyListForeColorSel = new Color(0,0,0);
    private static Color buddyListBackColorSel = new Color(253,252,216);
    
    private static String msgFieldSeparator = "#";
    
    private static Font  messageFont = new Font("Verdana", Font.PLAIN, 16);

    public static Color getBuddyListForeColor() {
        return buddyListForeColor;
    }

    public static void setBuddyListForeColor(Color aBuddyListForeColor) {
        buddyListForeColor = aBuddyListForeColor;
    }

    public static Color getBuddyListBackColor() {
        return buddyListBackColor;
    }

    public static void setBuddyListBackColor(Color aBuddyListBackColor) {
        buddyListBackColor = aBuddyListBackColor;
    }

    public static Color getBuddyListForeColorSel() {
        return buddyListForeColorSel;
    }

    public static void setBuddyListForeColorSel(Color aBuddyListForeColorSel) {
        buddyListForeColorSel = aBuddyListForeColorSel;
    }

    public static Color getBuddyListBackColorSel() {
        return buddyListBackColorSel;
    }

    public static void setBuddyListBackColorSel(Color aBuddyListBackColorSel) {
        buddyListBackColorSel = aBuddyListBackColorSel;
    }

    public static String getMsgFieldSeparator() {
        return msgFieldSeparator;
    }
    
    


    public static Color getIncomingMsgBackColor() {
        return incomingMsgBackColor;
    }

    public static void setIncomingMsgBackColor(Color incomingMsgBackColor) {
        Appearance.incomingMsgBackColor = incomingMsgBackColor;
    }

    public static Color getIncomingMsgForeColor() {
        return incomingMsgForeColor;
    }

    public static void setIncomingMsgForeColor(Color incomingMsgForeColor) {
        Appearance.incomingMsgForeColor = incomingMsgForeColor;
    }

    public static Color getSentMsgBackColor() {
        return sentMsgBackColor;
    }

    public static void setSentMsgBackColor(Color sentMsgBackColor) {
        Appearance.sentMsgBackColor = sentMsgBackColor;
    }

    public static Color getSentMsgForeColor() {
        return sentMsgForeColor;
    }

    public static void setSentMsgForeColor(Color sentMsgForeColor) {
        Appearance.sentMsgForeColor = sentMsgForeColor;
    }

    public static Font getMessageFont() {
        return messageFont;
    }

    public static void setMessageFont(Font messageFont) {
        Appearance.messageFont = messageFont;
    }
    
    
    public static String colorToString(Color c) {
		char[] buf = new char[7];
		buf[0] = '#';
		String s = Integer.toHexString(c.getRed());
		if (s.length() == 1) {
			buf[1] = '0';
			buf[2] = s.charAt(0);
		}
		else {
			buf[1] = s.charAt(0);
			buf[2] = s.charAt(1);
		}
		s = Integer.toHexString(c.getGreen());
		if (s.length() == 1) {
			buf[3] = '0';
			buf[4] = s.charAt(0);
		}
		else {
			buf[3] = s.charAt(0);
			buf[4] = s.charAt(1);
		}
		s = Integer.toHexString(c.getBlue());
		if (s.length() == 1) {
			buf[5] = '0';
			buf[6] = s.charAt(0);
		}
		else {
			buf[5] = s.charAt(0);
			buf[6] = s.charAt(1);
		}
	return String.valueOf(buf);
    }
    
    
    public static Color getErrorMsgBackColor() {
        return errorMsgBackColor;
    }

    public static void setErrorMsgBackColor(Color aErrorMsgBackColor) {
        errorMsgBackColor = aErrorMsgBackColor;
    }

    public static Color getErrorMsgForeColor() {
        return errorMsgForeColor;
    }

    public static void setErrorMsgForeColor(Color aErrorMsgForeColor) {
        errorMsgForeColor = aErrorMsgForeColor;
    }

}
