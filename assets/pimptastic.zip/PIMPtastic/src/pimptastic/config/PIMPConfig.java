/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pimptastic.config;

import java.util.logging.Level;
import java.util.logging.Logger;
import xml.ConfigParser;

/**
 *
 * @author tomaszgebarowski
 */
public class PIMPConfig {
    
    private static PIMPConfig instance = null;
    
    private static Appearance appearance;
    
    private static String hostname = "localhost";
    private static int port = 5041;
    private static String language = "";
    private static ConfigParser confParser;


    
    private PIMPConfig() {
        
    }
    
    public static PIMPConfig getInstance() {
     
        if (instance == null ) {
            try {
                instance = new PIMPConfig();
                appearance = new Appearance();
                confParser = new ConfigParser("src/config.xml");
                confParser.load();
            } catch (Exception ex) {
                Logger.getLogger(PIMPConfig.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        
        return instance;
    }
    
    public void saveConfig() {       
        confParser.write();
        
    }

    public Appearance getAppearance() {
        return appearance;
    }
    
    public static String getHostname() {
        return hostname;
    }

    public static void setHostname(String aHostname) {
        hostname = aHostname;
    }

    public static int getPort() {
        return port;
    }

    public static void setPort(int aPort) {
        port = aPort;
    }
    
    public static String getLanguage() {
        return language;
    }

    public static void setLanguage(String aLanguage) {
        language = aLanguage;
    }

    
            

}
