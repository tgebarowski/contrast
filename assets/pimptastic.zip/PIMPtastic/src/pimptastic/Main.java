/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pimptastic;

import xml.wrappers.*;
import protocol.*;

/**
 *
 * @author tomaszgebarowski
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        PIMPtastic appInstance = PIMPtastic.getInstance();
        appInstance.estabilishConnection();
        appInstance.run();
 
        /*
        InitRequestWrapper wrapper = new InitRequestWrapper("d0zer", "qwerty");
        BuddyListRequestWrapper wrapper2 = new BuddyListRequestWrapper(1,1);
        
        Vector v = new Vector();
        v.add(1);
        v.add(2);
        v.add(3);
        
        ChatMessageWrapper wrapper3 = new ChatMessageWrapper(v,1,1,"Testowa wiadomosc");
        
        StatusChangeRequestWrapper wrapper4 = new StatusChangeRequestWrapper(1, 2, "Available", "");
        
        UserAddRequestWrapper wrapper5 = new UserAddRequestWrapper("dzer", "Tomek" ,"Gebarowski", "Lodz", "Poland", "1985-05-07", "qwerty");
       
        ConfirmationMessageWrapper wrapper6 = new ConfirmationMessageWrapper(1, 2);
        
        ConfirmationMessageWrapper wrapper7 = new ConfirmationMessageWrapper(1, 2, "Not enough parameters");
        
        UserInfoRequestWrapper wrapper8 = new UserInfoRequestWrapper(1, 1, -1, "tgebarowski", null, null, null, "Poland", null);
        
        try {
            System.out.println(wrapper.toXML());
            System.out.println(wrapper2.toXML());
            //System.out.println(wrapper3.toXML());
            System.out.println(wrapper4.toXML());
            System.out.println(wrapper5.toXML());
            //System.out.println(wrapper6.toXML());
            //System.out.println(wrapper7.toXML());
            
            //String msg = wrapper7.toXML();
            String msg = "<?xml version=\"1.0\" ?><message rcpt_id=\"1\" seq_num=\"90\" type=\"userinfo\"><user><id>62</id><nick>jtravolta</nick><name>John</name><surname>Travolta</surname><birthday>1985-01-01</birthday><place>Zwolle</place><country>The Netherlands</country><privilage>user</privilage></user></message>"; 
            msg = "<?xml version=\"1.0\" ?><message rcpt_id=\"1\" seq_num=\"33\" type=\"userStatusChanged\"><status>Available</status><content>Opis</content></message>";
            System.out.println(msg);
            IncomingMessageParser imp = new IncomingMessageParser(msg);
            imp.process();
        } catch (Exception e ) { e.printStackTrace();}
        
        */
        
    }

}
