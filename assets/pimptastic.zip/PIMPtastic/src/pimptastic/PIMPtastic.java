/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pimptastic;

import gui.MainWindow;
import gui.dialogs.ConnectionDialog;
import gui.dialogs.LoginDialog;
import java.util.logging.Logger;
import javax.swing.JFrame;
import pimptastic.config.PIMPConfig;
import protocol.Communicator;

/**
 *
 * @author tomaszgebarowski
 */
public class PIMPtastic {
    
    private static PIMPtastic instance;
    private static Communicator imInstance;
    private static PIMPConfig config;
    private MainWindow mainWindow;
    
    
    private JFrame activeWindow;
    
    private PIMPtastic() {
   
        config = PIMPConfig.getInstance();
        imInstance = new Communicator();
        

   
    }
    
    public static PIMPtastic getInstance() {
    
        if ( instance == null )
            instance =  new PIMPtastic();

        
        return instance;
    
    }
    

    
    public void estabilishConnection() {
        
        if ( imInstance.connect() ) {
            Logger.getLogger("logger").info("Connected to server");            
            
        } else {
            ConnectionDialog cDialog = new ConnectionDialog(imInstance);
            cDialog.setVisible(true);

            while(!imInstance.isConnected() && cDialog.isVisible()) {

            }
        }       
    }
    
    public void run() {
     
        LoginDialog lDialog = new LoginDialog();
        lDialog.setVisible(true);
        activeWindow = lDialog;
        
    }
    
    
    public void createMainWindow() {
        
        if ( mainWindow == null )
            mainWindow = new MainWindow();
        
        activeWindow = mainWindow;
        
        mainWindow.setVisible(true);
        imInstance.sendBuddyListRequest();
    }
    
    public static Communicator getCommunicator() {
        return imInstance;
    }
    
    
    public MainWindow getMainWindow() {
        return this.mainWindow;
    }
    
    public JFrame getActiveWindow() {
        
        return activeWindow;
    }
    
    public void setActiveWindow(JFrame activeWindow) {
        this.activeWindow = activeWindow;
    }

    public PIMPConfig getConfig() {
        return config;
    }
    

}
