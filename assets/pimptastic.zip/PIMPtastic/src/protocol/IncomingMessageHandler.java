/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol;

import data_objects.AuthorizationDO;
import data_objects.BuddyListDO;
import data_objects.ChatMessageDO;
import data_objects.ConfirmationMessageDO;
import data_objects.DataObject;
import data_objects.UserAccountDO;
import data_objects.UserInfoDO;
import data_objects.UserStatusDO;
import java.util.logging.Logger;
import protocol.handlers.AuthorizationHandler;
import protocol.handlers.BuddyListHandler;
import protocol.handlers.BuddyStatusChangedHandler;
import protocol.handlers.ChatMessageHandler;
import protocol.handlers.ConfirmationMessageHandler;
import protocol.handlers.MessageHandler;
import protocol.handlers.UserAccountHandler;
import protocol.handlers.UserInfoHandler;

/**
 *
 * @author tomaszgebarowski
 */
public class IncomingMessageHandler {
    
    private DataObject dataO;
    
    public IncomingMessageHandler(DataObject dataO) {
        this.dataO = dataO;
        
    }
    
    public void handle() {
   
        MessageHandler mHandler = null;
        
        if (dataO != null )
            Logger.getLogger("logger").info("Received incoming message: " + dataO);
        
        if ( dataO instanceof ChatMessageDO) {
            mHandler = new ChatMessageHandler((ChatMessageDO)dataO);
     
        } else if ( dataO instanceof BuddyListDO ) {
            /*TODO: Implement a handler*/         
            mHandler = new BuddyListHandler((BuddyListDO)dataO);
                        
        } else if ( dataO instanceof ConfirmationMessageDO ) {
            /*TODO: Implement a handler*/
            System.out.println(dataO);
            mHandler = new ConfirmationMessageHandler((ConfirmationMessageDO)dataO);
        } else if ( dataO instanceof UserAccountDO ) {
            /*TODO: Implement a handler*/
            mHandler = new UserAccountHandler((UserAccountDO)dataO);
            System.out.println(dataO);
        } else if ( dataO instanceof UserInfoDO ) {
            mHandler = new UserInfoHandler((UserInfoDO)dataO);
            System.out.println(dataO);
        } else if ( dataO instanceof UserStatusDO ) {
            mHandler = new BuddyStatusChangedHandler((UserStatusDO)dataO);
        } else if ( dataO instanceof AuthorizationDO) {
            mHandler = new AuthorizationHandler((AuthorizationDO)dataO);
        }
        
        if ( mHandler != null ) {
            mHandler.handle();
        }
        
    }

}
