/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol;

import data_objects.BuddyListOpDO;
import data_objects.ChatMessageDO;
import data_objects.DataObject;
import data_objects.UserAccountDO;
import data_objects.UserInfoDO;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import xml.wrappers.*;
import gui.dialogs.*;
import java.io.IOException;
import java.util.Vector;
import java.util.logging.Logger;
import pimptastic.PIMPtastic;
import pimptastic.config.PIMPConfig;

/**
 * Pimp Comunicator Class responsible for handling communication with server
 * @author Tomasz Gebarowski
 */
public class Communicator {
    
    
    // Determines if connected to server
    private boolean connected;
    // Determines if user is authorized
    private boolean authorized;    
    
    // Socket
    private Socket socket;
    // Server host address
   
    private AckValidator ackValidator;
    //User ID
    private int rcpt_id;
    
    // Input/Output Buffers
    public BufferedReader input;
    private PrintWriter output;
    
    //Currently loged user
    private String login;
    
    private IncomingMessageListener incomingMessageListener;
    
    /** Creates a new instance of Communicator */
    public Communicator() {               
            this.connected = false; 
            this.ackValidator = new AckValidator();
    }
    
    public boolean connect() {
        
        try {
            if ( !isConnected() ) {
                socket = new Socket(PIMPConfig.getHostname(), PIMPConfig.getPort());
                output = new PrintWriter(socket.getOutputStream(), true);
                input = new  BufferedReader(new InputStreamReader(socket.getInputStream()));
                
                //Run Incoming Message Listener in a new thread
                incomingMessageListener = new IncomingMessageListener(input);            
                Thread t = new Thread(incomingMessageListener);
                t.start();
                
                connected = socket.isConnected();
            }
        } catch (Exception e ) {
            Logger.getLogger("logger").throwing("Communicator", "connect", e);
            connected = false;
            return false;
        }
        
        return true;
    }
    
    /**
     * Send Authorization ( INIT ) request to a server 
     * @param login String User login
     * @param password String User password
     * @throws RequestException On connection failure
     */
    public void sendInitRequest(String login, String password) {
    
        try {   
            /* TODO: Improve behaviour of reconnect so that server disconnection is detected */
            reconnect();
            
            InitRequestWrapper initRequestWrapper = new InitRequestWrapper(login, password);
            String message = initRequestWrapper.toXML();
            Logger.getLogger("logger").info("Sending INIT:" + message);
            output.println(message);            
            this.login = login;
        } catch ( Exception e ) {            
            InfoDialog infoDialog = new InfoDialog("Cannot send authorization message");
            infoDialog.setVisible(true);
        }       
    }
    
    
    public void sendCreateAccountRequest(UserAccountDO userAccountDO) {

        try {

            reconnect();
            
            UserAddRequestWrapper userAddRequestWrapper = new UserAddRequestWrapper(userAccountDO);
            
            String message = userAddRequestWrapper.toXML();
            Logger.getLogger("logger").info("Sending create account request:" + message);
            output.println(message);  
            
        } catch ( Exception e ) {            
            InfoDialog infoDialog = new InfoDialog("Cannot send  user create request!");
            infoDialog.setVisible(true);
        }    
    }
    
    
    public void sendModifyAccountRequest(UserAccountDO userAccountDO) {
        UserModifyRequestWrapper userModifyRequestWrapper = new UserModifyRequestWrapper(userAccountDO);    
        String message = userModifyRequestWrapper.toXML();
        Logger.getLogger("logger").info("Sending account modify request:" + message);
        output.println(message);   
    }
    
    
    public void sendChangePasswordRequest(String oldPassword,String newPassword) {
        UserChangePasswordRequestWrapper changePasswordWrapper = new UserChangePasswordRequestWrapper(rcpt_id, 1, oldPassword, newPassword);
        String message = changePasswordWrapper.toXML();
        Logger.getLogger("logger").info("Sending change password request:" + message);
        output.println(message);   
    }
    
    public void sendBuddyListRequest() {
        
        BuddyListRequestWrapper buddyListRequestWrapper = new BuddyListRequestWrapper(this.rcpt_id,1);
        String message = buddyListRequestWrapper.toXML();
        Logger.getLogger("logger").info("Sending buddy list request" + message);
        output.println(message);
  
    }
    
    
    public void sendMyAccountRequest() {
        
        MyAccountRequestWrapper myAccountRequestWrapper = new MyAccountRequestWrapper(this.rcpt_id,1);
        String message = myAccountRequestWrapper.toXML();
        Logger.getLogger("logger").info("Sending MyAccount request" + message);
        output.println(message);
  
    }
    
    
    public void sendBuddyListOpRequest(DataObject buddyListOpDO) {
        buddyListOpDO = ackValidator.addDO(buddyListOpDO);
        BuddyListOpRequestWrapper buddyListOpRequestWrapper = new BuddyListOpRequestWrapper((BuddyListOpDO)buddyListOpDO);
       
        
        String message = buddyListOpRequestWrapper.toXML();
        Logger.getLogger("logger").info("Sending buddy list operation request:" + ((BuddyListOpDO)buddyListOpDO).getMode());
        output.println(message);
    }
    
    public void sendBuddySearchRequest(UserInfoDO userDO) {
    
        UserInfoRequestWrapper userInfoRequestWrapper = new UserInfoRequestWrapper(userDO);
        String message = userInfoRequestWrapper.toXML();
        Logger.getLogger("logger").info("Sending Search Buddy Request" + message);
        output.println(message);
    }
    
    
    public ChatMessageDO sendChatMessage(Vector<Integer> recipients, String message ) {
        
        DataObject chatDO = new ChatMessageDO(rcpt_id, recipients, rcpt_id, message);
        chatDO = ackValidator.addDO(chatDO);
        
        
        ChatMessageWrapper chatMessageWrapper = new ChatMessageWrapper((ChatMessageDO)chatDO);
        String xmlMessage = chatMessageWrapper.toXML();
        Logger.getLogger("logger").info("Sending message to : " + recipients);
        output.println(xmlMessage);
           
        return (ChatMessageDO)chatDO;
               
    }
    
    public void sendUserStatusChangedRequest(String status, String content) {
        
        if ( !connected ) {
            PIMPtastic.getInstance().estabilishConnection();
            PIMPtastic.getInstance().run();
        }
        
        StatusChangeRequestWrapper statusChangeRequestWrapper = new StatusChangeRequestWrapper(this.rcpt_id, 1, status, content);
        String message = statusChangeRequestWrapper.toXML();
        Logger.getLogger("logger").info("Sending status change request" + message);
        output.println(message);
        
        if ( status.equals("Unavailable") ) {
            this.connected = false;
            this.authorized = false;
        }
                    
    }
    
    public void reconnect() {
        
        disconnect();
        if ( socket.isClosed()) {
            Logger.getLogger("logger").info("Reconnecting...");
            //this.connect();
            PIMPtastic.getInstance().estabilishConnection();
        }
        
    }
    
    public void disconnect() {
        
        try {
            socket.close();
            this.connected = false;
        } catch( Exception e) {
            this.connected = socket.isConnected();
        } 
               
    }
    
    
    public String getServerResponse() throws IOException {    
            return input.readLine();

    }

    
   /** Get curently loged user's login
    *  @return String
    */
    public String getLogin() {
        return this.login;
    }
    
    
   /** Get socket associated with server
    *  @return Socket
    */
    public Socket getSocket() {
        return this.socket;
    }
    
   /** Check if connected to server
    *  @return boolean True if connected, otherwise false
    */
    public boolean isConnected() {
        return this.connected;
    }
    
   /** Check if user is authorized
    *  @return boolean True if connected, otherwise false
    */
    public boolean isAuthorized() {
        return this.authorized;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public void setAuthorized(boolean authorized) {
        this.authorized = authorized;
    }
    
    public void setCurrentSeqNum(long seq_num) {
        this.ackValidator.setCurrentSeqNum(seq_num);
    }
    
    public long getCurrentSeqNum() {
        return this.ackValidator.getCurrentSeqNum();
    }

    public int getRcptId() {
        return rcpt_id;
    }

    public void setRcptId(int rcpt_id) {
        this.rcpt_id = rcpt_id;
    }

    public AckValidator getAckValidator() {
        return this.ackValidator;
    }
    
    

}
