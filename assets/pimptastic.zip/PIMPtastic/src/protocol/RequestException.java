/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol;

/**
 * RequestException thrown when errors with server connection or error server message sent
 * @author Tomasz Gebarowski
 */
public class RequestException extends Exception {
    
    private String msg;
    
    /** Creates a new instance of RequestException 
     *  @param msg String Error description
     */
    public RequestException(String msg ) {
        this.msg = msg;
    }
    
    /** Get message content
     *  @return String Error description 
     */
    public String getMsg() {
        return this.msg;
    }
    
}
