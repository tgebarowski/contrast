/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol.handlers;

import data_objects.ArbitraryDO;
import data_objects.BuddyListOpDO;
import data_objects.ChatMessageDO;
import data_objects.ConfirmationMessageDO;
import data_objects.DataObject;
import data_objects.ErrorMessageDO;
import gui.ChatMessageWindow;
import gui.MainWindow;
import gui.dialogs.CreateAccountDialog;
import gui.dialogs.InfoDialog;
import pimptastic.PIMPtastic;
import protocol.Communicator;

/**
 *
 * @author tomaszgebarowski
 */
public class ConfirmationMessageHandler implements MessageHandler {

    
    private MainWindow mainWindow;
    private Communicator imInstance;
    private ConfirmationMessageDO confMsgDO;
    
    public ConfirmationMessageHandler(ConfirmationMessageDO confMsgDO) {
        imInstance = PIMPtastic.getCommunicator();
        mainWindow = PIMPtastic.getInstance().getMainWindow();
        this.confMsgDO = confMsgDO;
    }
    
    public void handle() {
        
        
        //Handlling Ack with Sequence Numbers
        long seqNum = confMsgDO.getSeqNum();
        ArbitraryDO arbitraryDO = imInstance.getAckValidator().popDO(seqNum);
        
        if ( arbitraryDO != null )
        {
            DataObject dataO = arbitraryDO.getSourceObject();
            
            if (dataO instanceof BuddyListOpDO) {
                handleBuddyListOpConfirmation();
            } else if ( dataO instanceof ChatMessageDO ) {
                handleChatMessageConfirmation((ChatMessageDO)dataO);
            }
            
        }
        
        //Handling Acknowledgement coming from CreateAccountRequest
        if ( PIMPtastic.getInstance().getActiveWindow() instanceof CreateAccountDialog )
            handleCreateAccountConfirmation();

        
    }
    
    public void handleChatMessageConfirmation(ChatMessageDO chatMessageDO) {
        
        ChatMessageWindow chatMessageWindow = mainWindow.getChatMessageWindow();
        
        if (!confMsgDO.isAck()) {
            if (chatMessageWindow != null ) {                
                ErrorMessageDO errorMessageDO = new ErrorMessageDO(chatMessageDO, confMsgDO.getContent());
                chatMessageWindow.showIncomingMessage(errorMessageDO);
            }
        } else {
            //Display sent message only if acknowledgement was received
            chatMessageWindow.showIncomingMessage(chatMessageDO);
        } 
    }
    
    public void handleBuddyListOpConfirmation() {
        
        if (confMsgDO.isAck()) {
            PIMPtastic.getCommunicator().sendBuddyListRequest();
        } else {
            InfoDialog infoDialog = new InfoDialog(confMsgDO.getContent());
            infoDialog.setVisible(true);
        }
    }
    
    
    public void handleCreateAccountConfirmation() {
     
        CreateAccountDialog caDialog = (CreateAccountDialog)PIMPtastic.getInstance().getActiveWindow();
        
        if ( confMsgDO.isAck() )
            caDialog.accountCreatedAction();
        else
            caDialog.accountNotCreatedAction(confMsgDO.getContent());

    }
    
}
