/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol.handlers;

import data_objects.ChatMessageDO;
import gui.ChatMessageWindow;
import pimptastic.PIMPtastic;

/**
 *
 * @author tomaszgebarowski
 */
public class ChatMessageHandler implements MessageHandler {

    private ChatMessageDO chatDO;
    
    public ChatMessageHandler(ChatMessageDO chatDO) {
        this.chatDO = chatDO;
    }
    
    public void handle() {
        PIMPtastic appInstance = PIMPtastic.getInstance();
        ChatMessageWindow chatWindow = appInstance.getMainWindow().getChatMessageWindow();
        chatWindow.showIncomingMessage(chatDO);
        
    }
    
    
}
