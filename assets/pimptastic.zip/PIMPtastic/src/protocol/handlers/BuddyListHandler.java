/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol.handlers;

import data_objects.BuddyListDO;
import gui.MainWindow;
import pimptastic.PIMPtastic;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyListHandler implements MessageHandler {
    
    private BuddyListDO buddyListDO;
    
    
    public BuddyListHandler(BuddyListDO buddyListDO) {
        this.buddyListDO = buddyListDO;
    }

    public void handle() {
        
        MainWindow mainWindow = PIMPtastic.getInstance().getMainWindow();
        
        if ( mainWindow  != null ) {
            mainWindow.setBuddyListContent(buddyListDO);
        }
    }

}
