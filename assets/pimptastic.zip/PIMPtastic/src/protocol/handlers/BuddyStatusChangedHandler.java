/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol.handlers;

import data_objects.UserStatusDO;
import gui.MainWindow;
import pimptastic.PIMPtastic;

/**
 *
 * @author tomaszgebarowski
 */
public class BuddyStatusChangedHandler implements MessageHandler {
    
    private UserStatusDO userStatusDO;
    
    public BuddyStatusChangedHandler(UserStatusDO userStatusDO) {
        this.userStatusDO = userStatusDO;
    }
    
    public void handle() {
        
        MainWindow mainWindow = PIMPtastic.getInstance().getMainWindow();
        
        if ( mainWindow  != null ) {
            mainWindow.updateBuddyStatus(userStatusDO);
        }
        
    }

}
