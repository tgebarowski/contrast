/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol.handlers;

import data_objects.UserInfoDO;
import gui.dialogs.SearchBuddyDialog;
import java.util.logging.Logger;
import javax.swing.JFrame;
import pimptastic.PIMPtastic;

/**
 *
 * @author tomaszgebarowski
 */
public class UserInfoHandler implements MessageHandler {
    
    private UserInfoDO userInfoDO;
    
    public UserInfoHandler(UserInfoDO userInfoDO) {
        this.userInfoDO = userInfoDO;
    }
    
    public void handle() {
        
        
        Logger.getLogger("logger").info("UserInfoDO received");
        
        PIMPtastic appInstance = PIMPtastic.getInstance();
        JFrame activeWindow = appInstance.getActiveWindow();
        
        if ( activeWindow instanceof SearchBuddyDialog) {
            
            SearchBuddyDialog searchBuddyDialog = (SearchBuddyDialog)activeWindow;
            searchBuddyDialog.addNewResult(userInfoDO);
            
        }
        
    }

}
