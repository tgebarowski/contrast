/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol.handlers;

import data_objects.AuthorizationDO;
import gui.dialogs.LoginDialog;
import java.util.logging.Logger;
import javax.swing.JFrame;
import pimptastic.PIMPtastic;
import protocol.Communicator;

/**
 *
 * @author tomaszgebarowski
 */
public class AuthorizationHandler implements MessageHandler {
    
    private AuthorizationDO authDO;
    private PIMPtastic appInstance;
    private Communicator imInstance;
    
    public AuthorizationHandler(AuthorizationDO authDO) {
        this.authDO = authDO;
    }
    
    public void handle() {
        
        Logger.getLogger("logger").info("Authorization message received");
        
        appInstance = PIMPtastic.getInstance();
        imInstance = appInstance.getCommunicator();
        
        if ( !imInstance.isAuthorized() ) {
            if ( authDO.isAck() ) {
                imInstance.setAuthorized(true);
                imInstance.setCurrentSeqNum(authDO.getSeqNum());
                imInstance.setRcptId(authDO.getRcptId());                  
                appInstance.createMainWindow();;
            } else {
                JFrame activeWindow = PIMPtastic.getInstance().getActiveWindow();
                if ( activeWindow instanceof LoginDialog ) {
                    if (authDO.isAlreadyLogged() )
                        ((LoginDialog)activeWindow).alreadyLoggedIn();
                    else 
                        ((LoginDialog)activeWindow).accessNotGranted();
                }
            }
        }
    }

}
