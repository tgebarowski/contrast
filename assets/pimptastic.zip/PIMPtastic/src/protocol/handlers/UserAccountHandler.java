/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol.handlers;

import data_objects.UserAccountDO;
import gui.dialogs.MyAccountDialog;
import java.util.logging.Logger;
import javax.swing.JFrame;
import pimptastic.PIMPtastic;

/**
 *
 * @author tomaszgebarowski
 */
public class UserAccountHandler implements MessageHandler {
    
    private UserAccountDO userAccountDO;
    
    public UserAccountHandler(UserAccountDO userAccountDO) {
        this.userAccountDO = userAccountDO;
    }
    
    public void handle() {
        
        Logger.getLogger("logger").info("UserAccountDO received");
        
        PIMPtastic appInstance = PIMPtastic.getInstance();
        JFrame activeWindow = appInstance.getActiveWindow();
        
        if ( activeWindow instanceof MyAccountDialog) {
            
            MyAccountDialog myAccountDialog = (MyAccountDialog)activeWindow;
            myAccountDialog.setUserAccountDO(userAccountDO);
        }
    }

}
