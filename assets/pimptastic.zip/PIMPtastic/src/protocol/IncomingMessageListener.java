/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Logger;
import pimptastic.PIMPtastic;
import xml.IncomingMessageParser;

/**
 *
 * @author tomaszgebarowski
 */
public class IncomingMessageListener implements Runnable {
    
    
    //Buffered Reader used for reading data from server
    private BufferedReader messageReader;

    
    /** Creates a new instance of IncomingMessagesListener */
    public IncomingMessageListener(BufferedReader messageReader) { 
       this.messageReader = messageReader;
    }
    
    /** Start message listener in new thread */
    public void run() {
        try {
            messageProcessLoop();
        }
        catch(Exception e) {
            Logger.getLogger("logger").info("Exception in run() of IncomingMessageListener: " + e.getMessage());
        }
    }
    
    public void messageProcessLoop() throws IOException {
     
        while(true) {
            if ( messageReader.ready() ) {                
                String message = messageReader.readLine();
                Logger.getLogger("logger").info("Received incoming message, parsing:" + message);
                IncomingMessageParser imp = new IncomingMessageParser(message);
                imp.process();
            }
        }   
    }

}
