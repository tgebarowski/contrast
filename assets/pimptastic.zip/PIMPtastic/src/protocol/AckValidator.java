/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package protocol;

import data_objects.ArbitraryDO;
import data_objects.DataObject;
import java.util.ArrayList;
import java.util.logging.Logger;

/**
 *
 * @author tomaszgebarowski
 */
public class AckValidator {
    
    private long currentSeqNum = 1;
    private ArrayList<ArbitraryDO> ackList;
    
    
    public AckValidator() {
        this.ackList = new ArrayList();
    }
    
    public DataObject addDO(DataObject dataO) {
        dataO.setSeqNum(currentSeqNum++);
        ackList.add(new ArbitraryDO(dataO.getSeqNum(), dataO));
        
        return dataO;
    }
    
    public ArbitraryDO popDO(long seq_num) {
        
        Logger.getLogger("logger").info("Removing confirmation message with SeqNum: " + seq_num);
        
        for(ArbitraryDO item: ackList) {
            if ( item.getSeqNum() == seq_num ) {
                ArbitraryDO ret = item;
                ackList.remove(item);
                return ret;
            }
        }
        return null;       
    }

    public long getCurrentSeqNum() {
        return currentSeqNum;
    }
    
    
    public void setCurrentSeqNum(long currentSeqNum) {
        this.currentSeqNum = currentSeqNum;
        
    }
}
